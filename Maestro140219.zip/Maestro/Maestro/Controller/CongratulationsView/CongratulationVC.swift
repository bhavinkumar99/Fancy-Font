//
//  CongratulationVC.swift
//  Maestro
//
//  Created by Setblue on 19/12/18.
//  Copyright © 2018 Setblue. All rights reserved.
//

import UIKit
import Cosmos
import FCAlertView

class CongratulationVC: BaseVC,JDAlertViewDelegate {

    //MARK: PROPERTIES
    @IBOutlet var lblTopTitleBG: UILabel!
    @IBOutlet var imageViewBG: UIImageView!
    @IBOutlet var lblAssignmentAddressBG: UILabel!
    @IBOutlet var viewMaestroDetailBG: UIView!
    @IBOutlet var lblMaestroName: UILabel!
    @IBOutlet var viewMaestroRatingBG: CosmosView!
    @IBOutlet var lblTotalAssignment: UILabel!
    @IBOutlet var btnNextBG: UIButton!
    @IBOutlet var btnCancelBG: UIButton!
    
    //MARk: VARIBALES
    internal var isTeacher : Bool = false
    internal var dictInfo : typeAliasDictionary = typeAliasDictionary()
    var timerMaqLable : Timer!
    var timeOff = 60
    fileprivate var _JD_AlertView = JD_AlertView()

    override func viewDidLoad() {
        super.viewDidLoad()

        if isTeacher {
            lblTopTitleBG.text = "Congrats! We’ve found you a sub for an assignment! Meet your maestro."
            lblAssignmentAddressBG.isHidden = true
            viewMaestroDetailBG.isHidden = false
            btnNextBG.setTitle("Next", for: .normal)
            btnCancelBG.setTitle("Cancel", for: .normal)
//            btnNextBG.isSelected = false
//            btnCancelBG.isSelected = false
            imageViewBG.sd_setImage(with: URL(string: dictInfo[RES_Profile]! as! String), completed: nil)
            lblMaestroName.text = (dictInfo[RES_Fullname] as! String)
            viewMaestroRatingBG.rating = dictInfo[RES_User_rate] as! Double
            viewMaestroRatingBG.text = "( \(dictInfo[RES_User_rate]!) )"
            lblTotalAssignment.text = "Total Assignment Completed : \(dictInfo[RES_Total_assignment_completed]!)"
            
        }
        else {
            timerMaqLable = Timer.scheduledTimer(timeInterval: TimeInterval(1), target: self, selector: #selector(countDownForClaim), userInfo: nil, repeats: true)
            lblTopTitleBG.text = (dictInfo[RES_Message] as! String)
            lblAssignmentAddressBG.isHidden = false
            viewMaestroDetailBG.isHidden = true
            btnNextBG.setTitle("Claim", for: .normal)
            btnCancelBG.setTitle("Skip Assignment", for: .normal)
//            btnNextBG.isSelected = true
//            btnCancelBG.isSelected = true
            imageViewBG.sd_setImage(with: URL(string: dictInfo[RES_Thumbnail]! as! String), completed: nil)
            lblAssignmentAddressBG.text = "\(dictInfo[RES_Address]!)"
        }

    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationItem.hidesBackButton = true
        setMenuNavigation(left_imagename: "", left_action: #selector(doNOthing), right_imagename: "", right_action: #selector(doNOthing), title: "Congratulation", isCenterLogo: false)
    }
    
    //MARK: CUTOME METHOD
    @objc func countDownForClaim() {
        timeOff -= 1
        if timeOff == 0 {
            timerMaqLable.invalidate()
            self.callUserClaimAssignment(false)
        }
        else {
            btnNextBG.setTitle("Claim (In \(timeOff) Second)", for: .normal)
        }
    }
    func callTeacherCancelUser() {
        if isConnectedToNetwork(){
            let param = [REQ_teacher_id : APP_DELEGATE.USER_INFO.teacherId as Any,REQ_user_id : dictInfo["User_id"]! as Any] as typeAliasDictionary
            APP_DELEGATE.showAppLoader()
            ServiceCollection.sharedInstance.postTeacherCancelUser(param: param) { (resData, rstatus, message) in
                APP_DELEGATE.removeAppLoader()
                if rstatus == 1 {
                    self.navigationController?.popViewController(animated: false)
                    APP_DELEGATE.removeAppLoader()
                }
                else{
                    showAlertWithTitleWithMessage(message: message)
                    APP_DELEGATE.removeAppLoader()
                }
            }
        }
        else {
            showNoInternetAlert()
        }
    }
    func callUserClaimAssignment(_ isClaim : Bool) {
        if isConnectedToNetwork(){
            let param = [REQ_user_id : APP_DELEGATE.USER_INFO.userId as Any] as typeAliasDictionary
            APP_DELEGATE.showAppLoader()
            ServiceCollection.sharedInstance.postClaimAssignment(param: param, isCliam: isClaim) { (resData, rstatus, message) in
                APP_DELEGATE.removeAppLoader()
                if rstatus == 1 {
                    self.navigationController?.popViewController(animated: false)
                    APP_DELEGATE.removeAppLoader()
                }
                else{
                    showAlertWithTitleWithMessage(message: message)
                    APP_DELEGATE.removeAppLoader()
                }
            }
        }
        else {
            showNoInternetAlert()
        }
    }
    
    //MARK: BUTTON ACTION
    @IBAction func btnNextAction() {
        if isTeacher {
            let notes = loadVC(SB_MAIN, strVCId: VC_NOTES) as! NotesVC
            notes.isTeacher = isTeacher
            notes.dictInfo = dictInfo
            self.navigationController?.pushViewController(notes, animated: true)
        }
        else
        {
            if timerMaqLable != nil {
                timerMaqLable.invalidate()
                timerMaqLable = Timer()
            }
            self.callUserClaimAssignment(true)
        }
    }
    @IBAction func btnCancelAction() {
        if isTeacher {
            self.callTeacherCancelUser()
        }
        else {
            _JD_AlertView.showAlertView(["Yes"], message: MSG_QUE_SKIP_ASSIGNMENT, isIncludeCancelButton: true, alertType: .SKIP_ASSIGNMENT, object: "")
            _JD_AlertView.delegate = self
        }
    }
    
    //MARK: JD ALERT DELEGATE
    func jdAlertViewAction(_ alertType: ALERT_TYPE, buttonIndex: Int, buttonTitle: String, object: String) {
        if buttonIndex == 0 {
            if timerMaqLable != nil {
                timerMaqLable.invalidate()
                timerMaqLable = Timer()
            }
            self.callUserClaimAssignment(false)
        }
        
    }
    
    func jdActionSheetAction(_ actionSheetType: ACTION_SHEET_TYPE, buttonIndex: Int, buttonTitle: String, object: String) {
    }
}

//
//  NotesVC.swift
//  Maestro
//
//  Created by Setblue on 19/12/18.
//  Copyright © 2018 Setblue. All rights reserved.
//

import UIKit
import Photos

class NotesVC: BaseVC,UITextViewDelegate {

    //MARK: PROPERTIES
    @IBOutlet var viewNoteBG: UIView!
    @IBOutlet var txtViewNotesBG: UITextView!
    @IBOutlet var lblSendNoteToTitle: UILabel!
    @IBOutlet var lblNotePH: UILabel!
    @IBOutlet var btnSkipBG: UIButton!
    
    
    @IBOutlet var viewJobDoneBG: UIView!
    @IBOutlet var btnMaestroOnWayTitle: UILabel!
    
    //MARK: VARIBALES
    internal var isTeacher : Bool = false
    internal var dictInfo : typeAliasDictionary = typeAliasDictionary()
    fileprivate var imgURL : URL!
    var imagePickedBlock: ((UIImage) -> Void)?


    override func viewDidLoad() {
        super.viewDidLoad()
        viewJobDoneBG.isHidden = true
        viewNoteBG.isHidden = false
        if isTeacher {
            btnSkipBG.isHidden = false
            viewNoteBG.isHidden = false
            lblSendNoteToTitle.text = "Send a note to your maestro."
        }
        else {
            btnSkipBG.isHidden = true
            viewNoteBG.isHidden = false
            lblSendNoteToTitle.text = "Send a note to to the teacher and students."
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setMenuNavigation(left_imagename: ICON_BACK, left_action: #selector(backToPreview), right_imagename: "", right_action: #selector(doNOthing), title: "Notes", isCenterLogo: false)
    }
    
    //MARK: CUSTOM METHODS
    @objc func backToPreview() {
        hideKeyboard()
        if viewJobDoneBG.isHidden {
            self.navigationController?.popViewController(animated: true) }
        else {
            viewJobDoneBG.isHidden = true
            viewNoteBG.isHidden = false
            UIView.animate(withDuration: 0.3) {
                self.view.layoutIfNeeded()
            }
        }
    }
    
    func callCompleteAssignmentNotes() {
        if isConnectedToNetwork(){
            let param = [REQ_user_id : APP_DELEGATE.USER_INFO.userId,REQ_notes : txtViewNotesBG.text!,] as typeAliasDictionary
            APP_DELEGATE.showAppLoader()
            hideKeyboard()
            ServiceCollection.sharedInstance.userCompleteAssignmentWithNotes(param: param, imageURL: imgURL != nil ? [imgURL] : [], isTeacher: isTeacher, response: {(respDic,rstatus,message) in
                APP_DELEGATE.removeAppLoader()
                if rstatus == 1 {
                    showAlertWithTitleWithMessage(message: message)
                    let mainTab = self.storyboard?.instantiateViewController(withIdentifier: TAB_MAIN) as! MainTabBarVC
                    mainTab.selectedViewController = mainTab.viewControllers![1]
                    APP_DELEGATE.window?.rootViewController = mainTab
                }else{
                    showAlertWithTitleWithMessage(message: message)
                }
            })
        }
        else {
            showNoInternetAlert()
        }
    }
    func callTeacherAssignmentComplete(_ strNotes : String) {
        if isConnectedToNetwork(){
            let param = [REQ_teacher_id : APP_DELEGATE.USER_INFO.teacherId as Any,REQ_user_id : dictInfo["User_id"]! as Any,REQ_notes : strNotes] as typeAliasDictionary
            APP_DELEGATE.showAppLoader()
            ServiceCollection.sharedInstance.postTeacherAssignmentComplete(param: param) { (resData, rstatus, message) in
                APP_DELEGATE.removeAppLoader()
                if rstatus == 1 || rstatus == 2 {
                    if rstatus == 2 { showAlertWithTitleWithMessage(message: message) }
                    let mainTab = self.storyboard?.instantiateViewController(withIdentifier: TAB_MAIN) as! MainTabBarVC
                    mainTab.selectedViewController = mainTab.viewControllers![1]
                    APP_DELEGATE.window?.rootViewController = mainTab
                    APP_DELEGATE.removeAppLoader()
                }
                else{
                    showAlertWithTitleWithMessage(message: message)
                    APP_DELEGATE.removeAppLoader()
                }
            }
        }
        else {
            showNoInternetAlert()
        }
    }
    //MARK: BUTTON ACTION
    @IBAction func btnSubmitNoteAction() {
        hideKeyboard()
        if txtViewNotesBG.text == "" {
            showAlertWithTitleWithMessage(message: "Enter Notes First!!!")
            return
        }
        self.btnSkipAction()
    }
    @IBAction func btnSkipAction() {
        hideKeyboard()
        viewJobDoneBG.isHidden = false
        viewNoteBG.isHidden = true
        btnMaestroOnWayTitle.isHidden = !isTeacher
        UIView.animate(withDuration: 0.3) {
            self.view.layoutIfNeeded()
        }
    }
    @IBAction func btnCompleteAction() {
        hideKeyboard()
        if isTeacher {
            self.callTeacherAssignmentComplete(txtViewNotesBG.text!)
        }
        else {
            self.callCompleteAssignmentNotes()
        }
    }
    
    //MARK: UITEXTVIEW DELEGATE
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        let currentText = textView.text!
        guard let stringRange = Range(range, in: currentText) else { return false }
        let changedText = currentText.replacingCharacters(in: stringRange, with: text)
        lblNotePH.isHidden = changedText == "" ? false : true
        return true
    }
}
extension NotesVC: UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let image = info["UIImagePickerControllerOriginalImage"] as? UIImage
        {
            self.imagePickedBlock?(image)
//            self.imageViewProfilePic.image = image
            self.imgURL = URL(string: "\(info["UIImagePickerControllerImageURL"]!)")
        }
        else{ print("Something went wrong in  image") }
        self.dismiss(animated: true, completion: nil)
    }
    @objc func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        if let error = error {
            print(error.localizedDescription)
            //            let alert = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
            //            alert.addAction(UIAlertAction(title: "OK", style: .default))
            //            present(alert, animated: true)
        } else {
            print("Image saved successfully")
            //            let alert = UIAlertController(title: "Saved!", message: "Image saved successfully", preferredStyle: .alert)
            //            alert.addAction(UIAlertAction(title: "OK", style: .default))
            //            present(alert, animated: true)
        }
    }
}


//
//  SettingVC.swift
//  Maestro
//
//  Created by Setblue on 08/12/18.
//  Copyright © 2018 Setblue. All rights reserved.
//

import UIKit

class SettingVC: BaseVC,JDAlertViewDelegate {
    
    //MARK: PROPERTIES
    @IBOutlet var imageViewProfilePic: UIImageView!
    @IBOutlet var lblUserName: UILabel!
    @IBOutlet var lblCurrentRadius: UILabel!
    @IBOutlet var sliderRadiusBG: UISlider!
    @IBOutlet var constraintViewRadiusHeight: NSLayoutConstraint!
    @IBOutlet var viewRadiusBG: UIView!
    
    //MARK: VARIABLES
    internal var userDetail : UserDetailClass!
    internal var teacherDetail : TeacherDetailClass!
    internal var isTeacher : Bool = false
    fileprivate var _JD_AlertView = JD_AlertView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if isTeacher {
            lblUserName.text = teacherDetail.fullname!
            self.imageViewProfilePic.sd_setImage(with: URL(string: teacherDetail.thumbnail!), completed: { (img, error, type, url) in            })
            self.constraintViewRadiusHeight.constant = 0
            self.viewRadiusBG.isHidden = true
        }
        else {
            self.imageViewProfilePic.sd_setImage(with: URL(string: userDetail.profile!), completed: { (img, error, type, url) in            })
            self.constraintViewRadiusHeight.constant = 120
            self.viewRadiusBG.isHidden = false
            lblUserName.text = userDetail.fullname
            lblCurrentRadius.text = "Maestro Search radius : \(userDetail.radius!)"
            sliderRadiusBG.value = Float(userDetail.radius!)!

        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setMenuNavigation(left_imagename: ICON_BACK, left_action: #selector(navigateToPreviousView), right_imagename: "", right_action: #selector(doNOthing), title: "Settings", isCenterLogo: false)
    }
    
    //MARK: BUTTON ACTION
    @IBAction func btnSettingSubOptionAction(_ sender: UIButton) {
        if sender.tag == 1 {
            //Past Invoices
        }
        else if sender.tag == 2 {
            //Rate App
            let openAppStoreForRating = String(format:"itms-apps://itunes.apple.com/us/app/id%@?action=write-review&mt=8", APP_STOREID)
            if  UIApplication.shared.canOpenURL(URL(string: openAppStoreForRating)!) {
                UIApplication.shared.open(URL(string: openAppStoreForRating)!, options: [:], completionHandler: nil)
            }
            else {
                showAlertWithTitleWithMessage(message: "Please select our app from the AppStore and write a review for us. Thanks!!")
            }
        }
            
        else {
            //T & C
        }
    }
    
    @IBAction func btnSliderRadiusAction(_ sender: UISlider, forEvent event: UIEvent) {
        lblCurrentRadius.text = "Maestro Search radius : \(Int(sender.value))"
        if let touchEvent = event.allTouches?.first {
            switch touchEvent.phase {
            case .began: break
            // handle drag began
            case .moved: break
            // handle drag moved
            case .ended:
            // handle drag ended
                self.setRadiusData(Int(sender.value))
                break
            default:
                break
            }
        }
    }
    
    @IBAction func btnLogoutAction() {
        _JD_AlertView.showAlertView(["Yea,Sure","No"], message: MSG_QUE_LOGOUT, isIncludeCancelButton: false, alertType: .LOGOUT, object: "")
        _JD_AlertView.delegate = self
    }
    
    //MARK : CUSTOM METHOD
    func setRadiusData(_ value : Int){
        if isConnectedToNetwork(){
            let param = [REQ_user_id : APP_DELEGATE.USER_INFO.userId as Any,REQ_radius : value] as typeAliasDictionary
            APP_DELEGATE.showAppLoader()
            hideKeyboard()
            ServiceCollection.sharedInstance.postSetRadiusData(param: param, response: {(respDic,rstatus,message) in
                APP_DELEGATE.removeAppLoader()
                if rstatus == 1 {
                   
                }else {
                    showAlertWithTitleWithMessage(message: message)
                }
            })
        }
        else {
            showNoInternetAlert()
        }
    }
    func jdAlertViewAction(_ alertType: ALERT_TYPE, buttonIndex: Int, buttonTitle: String, object: String) {
        switch buttonIndex {
        case 0:
            GetSetModel.removeObjectForKey(objectKey: UD_KEY_APPUSER_INFO)
            GetSetModel.setStringValueToUserDefaults(strValue: STATUS_PAGE_VIEW_TYPE.DUMMY.rawValue, ForKey: UD_STATUS_CURRENT_VIEW)
            APP_DELEGATE.setLoginVC()
            break
        default:
            break
        }
    }
    
    func jdActionSheetAction(_ actionSheetType: ACTION_SHEET_TYPE, buttonIndex: Int, buttonTitle: String, object: String) {
    }
}


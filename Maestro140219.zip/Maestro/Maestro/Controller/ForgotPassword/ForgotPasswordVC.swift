//
//  ForgotPasswordVC.swift
//  Maestro
//
//  Created by Setblue on 06/12/18.
//  Copyright © 2018 Setblue. All rights reserved.
//

import UIKit

class ForgotPasswordVC: BaseVC {

    //MARK: PROPERTIES
    @IBOutlet var txtEmail: UITextField!
    @IBOutlet var viewEmailSendSucessBG: UIView!
    
    //MARK:  VARIBALES
    internal var strEmail : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = false
        txtEmail.text = strEmail

    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setMenuNavigation(left_imagename: ICON_BACK, left_action: #selector(btnLeftAction), right_imagename: "", right_action: nil, title: "Forgot Password", isCenterLogo: false)
    }
    
    //MARK: CUSTOM METHOD
    @objc func btnLeftAction() { navigateToPreviousView() }
    
    //MARK: UIBUTTON ACTION
    @IBAction func btnSendAction() {
        hideKeyboard()
        let strEmail : String = txtEmail.text!
        if strEmail.isEmpty {
            showAlertWithTitleWithMessage(message: MSG_TXT_EMAIL)
            return
        }
        if isConnectedToNetwork(){
            let param = [REQ_email : strEmail] as typeAliasDictionary
            APP_DELEGATE.showAppLoader()
            ServiceCollection.sharedInstance.postForgotPassword(param: param, response: {(respDic,rstatus,message) in
                APP_DELEGATE.removeAppLoader()
                
                if rstatus == 1 {
                    self.viewEmailSendSucessBG.isHidden = false
                    UIView.animate(withDuration: 0.3) { self.view.layoutIfNeeded() }
                }else{
                    showAlertWithTitleWithMessage(message: message)
                }
            })
        }
        else {
            showNoInternetAlert()
        }
    }
}

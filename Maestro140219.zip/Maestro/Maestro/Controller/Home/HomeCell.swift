//
//  HomeCell.swift
//  Maestro
//
//  Created by Setblue on 07/12/18.
//  Copyright © 2018 Setblue. All rights reserved.
//

import UIKit
import Cosmos

protocol HomeCellDelegate {
    func btnViewCloseAction_HomeCell(sender : UIButton)
    func btnHireAgainAction_HomeCell(sender : UIButton)
}

class HomeCell: UITableViewCell {

    //MARK: VARIBALES
    var delegate : HomeCellDelegate! = nil
    
    //MARK: PROPERTIES
    @IBOutlet var imageViewSchoolSubtituteBG: UIImageView!
    @IBOutlet var lblSchoolLocation: UILabel!
    @IBOutlet var viewSubtituteDetail: UIView!
    @IBOutlet var lblSubtituteName: UILabel!
    @IBOutlet var lblRatingValue: UILabel!
    @IBOutlet var lblTotolAssignment: UILabel!
    @IBOutlet var viewDetailInnerBG: UIView!
    @IBOutlet var lblTeacherName: UILabel!
    @IBOutlet var viewDetailImageBG: UIView!
    @IBOutlet var lblNotesValue: UILabel!
    @IBOutlet var btnHireAgain: UIButton!
    @IBOutlet var lblTotalTime: UILabel!
    @IBOutlet var btnViewClose: UIButton!
    @IBOutlet var constrintViewButtonViewTopToDetailview: NSLayoutConstraint!
    @IBOutlet var constraintViewButtonViewTopToDirect: NSLayoutConstraint!
    @IBOutlet var constraintViewTeacherNameHeight: NSLayoutConstraint!
    @IBOutlet var constraintViewDetailImagHeight: NSLayoutConstraint!
    @IBOutlet var imageViewDetailBG: UIImageView!
    @IBOutlet var viewStarRatingBG: CosmosView!
    
    //MARK: BUTTON ACTION
    @IBAction func btnViewCloseAction(_ sender: UIButton) {
        self.delegate.btnViewCloseAction_HomeCell(sender: sender)
    }
    @IBAction func btnHireAgainAction(_ sender: UIButton) {
        self.delegate.btnHireAgainAction_HomeCell(sender: sender)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

//
//  HomeVC.swift
//  BaseProjectSB
//
//  Created by Setblue on 24/11/18.
//  Copyright © 2018 Setblue. All rights reserved.
//
import UIKit
import Cosmos
import SwiftyJSON
//import Crashlytics

class HomeVC: BaseVC {
    
    //MARK: PROPERTIES
    @IBOutlet var viewNoData: UIView!
    @IBOutlet var tableViewBG: UITableView!
    
    //MARK: VARIABLES
    fileprivate var isTeacher : Bool = false
    fileprivate var arrListData : NSMutableArray = NSMutableArray()

    override func viewDidLoad() {
        super.viewDidLoad()
        APP_DELEGATE.navigationController = self.navigationController
        tableViewBG.estimatedRowHeight = 398
        tableViewBG.rowHeight = UITableView.automaticDimension
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //    fileprivate var isTeacher : Bool = GetSetModel.iskeyAlreadyExist(key: UD_KEY_APPUSER_INFO) ? (APP_DELEGATE.USER_INFO.loginType! == "teacher" ? true : false) : false

        isTeacher = APP_DELEGATE.USER_INFO.loginType! == "teacher" ? true : false
        setMenuNavigation(left_imagename: "", left_action: #selector(appNavigationController_LeftSideAction), right_imagename: "", right_action: #selector(doNOthing), title: "Past Assignment", isCenterLogo: false)
        self.callPastAssignmnetData(isTeacher)
    }
    //MARK: CUTOME METHOD
    @objc func appNavigationController_LeftSideAction() {
    }
    func callPastAssignmnetData(_ isTeacher : Bool) {
        if !isTeacher {
            if isConnectedToNetwork(){
                let param = [REQ_user_id : APP_DELEGATE.USER_INFO.userId] as typeAliasDictionary
                APP_DELEGATE.showAppLoader()
                hideKeyboard()
                ServiceCollection.sharedInstance.PostUserPastAssignmentData(param: param, response: {(respDic,rstatus,message) in
                    APP_DELEGATE.removeAppLoader()
                    if rstatus == 1 {
                        self.arrListData.removeAllObjects()
                        self.arrListData.addObjects(from: respDic as! [Any])
                        self.tableViewBG.reloadData()
                    }else {
                        showAlertWithTitleWithMessage(message: message)
                    }
                })
            }
            else {
                showNoInternetAlert()
            }
        }
        else {
            if isConnectedToNetwork(){
                let param = [REQ_teacher_id : APP_DELEGATE.USER_INFO.teacherId] as typeAliasDictionary
                APP_DELEGATE.showAppLoader()
                hideKeyboard()
                ServiceCollection.sharedInstance.PostTeacherPastAssignmentData(param: param, response: {(respDic,rstatus,message) in
                    APP_DELEGATE.removeAppLoader()
                    if rstatus == 1 {
                        self.arrListData.removeAllObjects()
                        self.arrListData.addObjects(from: respDic as! [Any])
                        self.tableViewBG.reloadData()
                    }else {
                        showAlertWithTitleWithMessage(message: message)
                    }
                })
            }
            else {
                showNoInternetAlert()
            }
        }
    }
    
    
    //MARK: UIBUTTON ACTION

}
extension HomeVC : UITableViewDelegate,UITableViewDataSource,HomeCellDelegate {

    func numberOfSections(in tableView: UITableView) -> Int { return 1 }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrListData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableViewBG.dequeueReusableCell(withIdentifier: "idHomeCell", for: indexPath) as! HomeCell
        cell.btnViewClose.accessibilityIdentifier = String(indexPath.row)
        cell.btnHireAgain.accessibilityIdentifier = String(indexPath.row)
        cell.delegate = self
        if isTeacher {
            
            cell.viewSubtituteDetail.isHidden = false
            cell.constraintViewTeacherNameHeight.constant = 0
            cell.btnHireAgain.isHidden = false
            cell.lblSchoolLocation.isHidden = true
            
            let strValue = "Total Assignment Completed : "
            let myAttributesR: [NSAttributedString.Key : Any] = [
                NSAttributedString.Key.font: UIFont.init(name: FONT_SAN_FRANCISCO_REGULAR, size: 12) as Any]
            let myString = NSMutableAttributedString(string: strValue, attributes: myAttributesR)
            let dictTeacher : CompletedAssignmentTeacherClass = self.arrListData[indexPath.row] as! CompletedAssignmentTeacherClass

                cell.imageViewSchoolSubtituteBG.sd_setImage(with: URL(string: dictTeacher.profile!), completed: nil)
                cell.lblSubtituteName.text = dictTeacher.userFullname!
                cell.lblNotesValue.text = dictTeacher.userNotes! == "" ? "" : "“\(dictTeacher.userNotes!)”"
                cell.lblTotalTime.text = dictTeacher.totalSpentTime!
                cell.viewStarRatingBG.rating = Double(Int(dictTeacher.userRate!))
                cell.viewStarRatingBG.text = "\(Double(Int(dictTeacher.userRate!)))"
                
                let myAttributesB: [NSAttributedString.Key : Any] = [
                    NSAttributedString.Key.font: UIFont.init(name: FONT_SAN_FRANCISCO_BOLD, size: 12) as Any]
                let strCount = NSMutableAttributedString(string:
                    "\(dictTeacher.totalAssignmentCompleted!)", attributes: myAttributesB)
                myString.append(strCount)
                if dictTeacher.userNotesPhoto!.isEmpty {
                    cell.constraintViewDetailImagHeight.constant = 0
                    cell.viewDetailImageBG.isHidden = true
                    cell.imageViewDetailBG.image = nil
                }
                else {
                    cell.constraintViewDetailImagHeight.constant = 75
                    cell.viewDetailImageBG.isHidden = false
                    cell.imageViewDetailBG.sd_setImage(with: URL(string: dictTeacher.userNotesPhoto!), completed: nil)
                }
                cell.lblTotolAssignment.attributedText = myString
            
            if dictTeacher.isExpanded == "1" {
                cell.btnViewClose.setTitle("Close", for: .normal)
                cell.constraintViewButtonViewTopToDirect.priority = .defaultLow
                cell.constrintViewButtonViewTopToDetailview.priority = .defaultHigh
                cell.viewDetailInnerBG.isHidden = false
            }
            else {
                cell.btnViewClose.setTitle("View", for: .normal)
                cell.constraintViewButtonViewTopToDirect.priority = .defaultHigh
                cell.constrintViewButtonViewTopToDetailview.priority = .defaultLow
                cell.viewDetailInnerBG.isHidden = true
            }
        }
        else {
            
            let dictUser : CompletedAssignmentUserClass = self.arrListData[indexPath.row] as! CompletedAssignmentUserClass
            cell.lblSchoolLocation.isHidden = false
            cell.btnHireAgain.isHidden = true
            cell.viewSubtituteDetail.isHidden = true
            cell.constraintViewTeacherNameHeight.constant = 25
            cell.constraintViewDetailImagHeight.constant = 0
            cell.viewDetailImageBG.isHidden = true
            
            cell.lblSchoolLocation.text = dictUser.address!
            cell.imageViewSchoolSubtituteBG.sd_setImage(with: URL.init(string: dictUser.thumbnail!), completed: nil)
            cell.lblTeacherName.text = dictUser.teacherFullname!
            cell.lblNotesValue.text = dictUser.assignmentNotes! == "" ? "" : "“\(dictUser.assignmentNotes!)”"
            cell.lblTotalTime.text = "\(dictUser.totalSpentTime!)"
            
            if dictUser.isExpanded == "1" {
                cell.btnViewClose.setTitle("Close", for: .normal)
                cell.constraintViewButtonViewTopToDirect.priority = .defaultLow
                cell.constrintViewButtonViewTopToDetailview.priority = .defaultHigh
                cell.viewDetailInnerBG.isHidden = false
            }
            else {
                cell.btnViewClose.setTitle("View", for: .normal)
                cell.constraintViewButtonViewTopToDirect.priority = .defaultHigh
                cell.constrintViewButtonViewTopToDetailview.priority = .defaultLow
                cell.viewDetailInnerBG.isHidden = true
            }
        }
        UIView.animate(withDuration: 0.3) { self.view.layoutIfNeeded() }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
        
    }
    
    //MARK: CELL DELEGATE
    func btnViewCloseAction_HomeCell(sender: UIButton) {
        let intIndex : Int = Int(sender.accessibilityIdentifier!)!
        if isTeacher {
            let dictUser : CompletedAssignmentTeacherClass = self.arrListData[intIndex] as! CompletedAssignmentTeacherClass
            if dictUser.isExpanded == "0" { dictUser.isExpanded = "1" }
            else { dictUser.isExpanded = "0" }
            self.arrListData[intIndex] = dictUser
        }
        else {
            let dictUser : CompletedAssignmentUserClass = self.arrListData[intIndex] as! CompletedAssignmentUserClass
            if dictUser.isExpanded == "0" { dictUser.isExpanded = "1" }
            else { dictUser.isExpanded = "0" }
            self.arrListData[intIndex] = dictUser
        }
        tableViewBG.reloadRows(at: [IndexPath.init(row: intIndex, section: 0)], with: .automatic)
    }
    
    func btnHireAgainAction_HomeCell(sender: UIButton) {
        let intIndex : Int = Int(sender.accessibilityIdentifier!)!
        print(intIndex)
    }
}


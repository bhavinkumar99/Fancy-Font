//
//  EditProfileVC.swift
//  Maestro
//
//  Created by Setblue on 08/12/18.
//  Copyright © 2018 Setblue. All rights reserved.
//

import UIKit
import Photos

class EditProfileVC: BaseVC,JDAlertViewDelegate {

    //MARK: PROPERTIES
    @IBOutlet var imageViewProfilePic: UIImageView!
    @IBOutlet var lblUserName: UILabel!
    @IBOutlet var txtEmail: UITextField!
    @IBOutlet var txtOldPassword: UITextField!
    @IBOutlet var txtNewPassword: UITextField!
    @IBOutlet var txtConfirmPassword: UITextField!
    
    //MARK: VARIABLES
    var imagePickedBlock: ((UIImage) -> Void)?
    internal var userDetail : UserDetailClass!
    internal var teacherDetail : TeacherDetailClass!
    internal var isTeacher : Bool = false
    fileprivate var imgURL : URL!
    fileprivate var _JD_AlertView = JD_AlertView()

    override func viewDidLoad() {
        super.viewDidLoad()
        if isTeacher {
            lblUserName.text = teacherDetail.fullname!
            txtEmail.text = teacherDetail.email!
            self.imageViewProfilePic.sd_setImage(with: URL(string: teacherDetail.thumbnail!), completed: { (img, error, type, url) in            })
        }
        else {
            self.imageViewProfilePic.sd_setImage(with: URL(string: userDetail.profile!), completed: { (img, error, type, url) in            })
            txtEmail.text = userDetail.email!
            lblUserName.text = userDetail.fullname
        }

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setMenuNavigation(left_imagename: ICON_BACK, left_action: #selector(navigateToPreviousView), right_imagename: "", right_action: #selector(doNOthing), title: "Edit Profile", isCenterLogo: false)
    }

    //MARK: BUTTON ACTION
    @IBAction func btnEditPhotoAction() {
        _JD_AlertView.showAlertView(["Gallery","Camera"], message: "Image select from", isIncludeCancelButton: false, alertType: .SKIP_ASSIGNMENT, object: "")
        _JD_AlertView.delegate = self
    }
    
    @IBAction func btnSaveAction() {
        hideKeyboard()
        let strEmail : String = txtEmail.text!
        let strOldPassword : String = txtOldPassword.text!
        let strNewPassword : String = txtNewPassword.text!
        let strConfirmPassword : String = txtConfirmPassword.text!
        
        if strEmail.isEmpty {
            showAlertWithTitleWithMessage(message: MSG_TXT_EMAIL)
            return
        }
        if !strEmail.isEmail() {
            showAlertWithTitleWithMessage(message: MSG_TXT_EMAIL_VALID)
            return
        }
        if strOldPassword.isEmpty {
            showAlertWithTitleWithMessage(message: MSG_TXT_PASSCODE_OLD)
            return
        }
        if strNewPassword.isEmpty {
            showAlertWithTitleWithMessage(message: MSG_TXT_PASSCODE_NEW)
            return
        }
        if strConfirmPassword.isEmpty {
            showAlertWithTitleWithMessage(message: MSG_TXT_PASSCODE_CONFIRM)
            return
        }
        if strNewPassword != strConfirmPassword {
            showAlertWithTitleWithMessage(message: MSG_TXT_NEW_CONFIRM_PASSWORD_SAME)
            return
        }
        if isConnectedToNetwork(){
            let param = [(isTeacher ? REQ_teacher_id : REQ_user_id) : (isTeacher ? APP_DELEGATE.USER_INFO.teacherId : APP_DELEGATE.USER_INFO.userId),REQ_new_password : strNewPassword,REQ_retype_new_password :strNewPassword,REQ_email :APP_DELEGATE.USER_INFO.email,REQ_current_password :strOldPassword] as typeAliasDictionary
            APP_DELEGATE.showAppLoader()
            hideKeyboard()
            ServiceCollection.sharedInstance.editUserDetail(param: param, imageURL: imgURL != nil ? [imgURL] : [], isTeacher: isTeacher, response: {(respDic,rstatus,message) in
                  APP_DELEGATE.removeAppLoader()
                
                if rstatus == 1 {
                    showAlertWithTitleWithMessage(message: "Data saved sucessfully")
                    self.txtConfirmPassword.text = ""
                    self.txtNewPassword.text = ""
                    self.txtOldPassword.text = ""
                }else{
                    showAlertWithTitleWithMessage(message: message)
                }
            })
        }
        else {
            showNoInternetAlert()
        }
    }
    
    //MARK: CUSTOM METHOD
    
    //MARK: JD ALERT DELEGATE
    func jdAlertViewAction(_ alertType: ALERT_TYPE, buttonIndex: Int, buttonTitle: String, object: String) {
        self.authorisationStatus(attachmentTypeEnum: buttonIndex == 0 ? .photoLibrary : .camera)
    }
    
    func jdActionSheetAction(_ actionSheetType: ACTION_SHEET_TYPE, buttonIndex: Int, buttonTitle: String, object: String) {
    }
    
    func authorisationStatus(attachmentTypeEnum: AttachmentType){
        let status = PHPhotoLibrary.authorizationStatus()
        switch status {
        case .authorized:
            if attachmentTypeEnum == AttachmentType.camera{
                openCamera()
            }
            if attachmentTypeEnum == AttachmentType.photoLibrary{
                photoLibrary()
            }
        case .denied:
            print("permission denied")
            self.addAlertForSettings(attachmentTypeEnum)
        case .notDetermined:
            print("Permission Not Determined")
            PHPhotoLibrary.requestAuthorization({ (status) in
                if status == PHAuthorizationStatus.authorized{
                    // photo library access given
                    print("access given")
                    if attachmentTypeEnum == AttachmentType.camera{
                        self.openCamera()
                    }
                    if attachmentTypeEnum == AttachmentType.photoLibrary{
                        self.photoLibrary()
                    }
                }else{
                    print("restriced manually")
                    self.addAlertForSettings(attachmentTypeEnum)
                }
            })
        case .restricted:
            print("permission restricted")
            self.addAlertForSettings(attachmentTypeEnum)
        }
    }
    //MARK: - SETTINGS ALERT
    func addAlertForSettings(_ attachmentTypeEnum: AttachmentType){
        var alertTitle: String = ""
        if attachmentTypeEnum == AttachmentType.camera{
            alertTitle = App_Constants.alertForCameraAccessMessage
        }
        if attachmentTypeEnum == AttachmentType.photoLibrary{
            alertTitle = App_Constants.alertForPhotoLibraryMessage
        }
        if attachmentTypeEnum == AttachmentType.video{
            alertTitle = App_Constants.alertForVideoLibraryMessage
        }
        
        let cameraUnavailableAlertController = UIAlertController (title: alertTitle , message: nil, preferredStyle: .alert)
        
        let settingsAction = UIAlertAction(title: App_Constants.settingsBtnTitle, style: .destructive) { (_) -> Void in
            let settingsUrl = NSURL(string:UIApplication.openSettingsURLString)
            if let url = settingsUrl {
                if #available(iOS 10.0, *) {
                    UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
                } else {
                    // Fallback on earlier versions
                }
            }
        }
        let cancelAction = UIAlertAction(title: App_Constants.cancelBtnTitle, style: .default, handler: nil)
        cameraUnavailableAlertController .addAction(cancelAction)
        cameraUnavailableAlertController .addAction(settingsAction)
        self.present(cameraUnavailableAlertController , animated: true, completion: nil)
    }
    
    //MARK: - CAMERA PICKER
    func openCamera(){
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            let myPickerController = UIImagePickerController()
            myPickerController.delegate = self
            myPickerController.sourceType = .camera
            self.present(myPickerController, animated: true, completion: nil)
        }
    }
    func photoLibrary(){
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
            let myPickerController = UIImagePickerController()
            myPickerController.delegate = self
            myPickerController.sourceType = .photoLibrary
            self.present(myPickerController, animated: true, completion: nil)
        }
    }
    
}
extension EditProfileVC : UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == txtEmail { txtOldPassword.becomeFirstResponder() }
        else if textField == txtOldPassword { txtNewPassword.becomeFirstResponder() }
        else if textField == txtNewPassword { txtConfirmPassword.becomeFirstResponder() }
        else if textField == txtConfirmPassword { txtConfirmPassword.resignFirstResponder() }
        return true
    }
}

extension EditProfileVC: UIImagePickerControllerDelegate,UINavigationControllerDelegate {
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            self.dismiss(animated: true, completion: nil)
        }
        
        @objc func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
            if let image = info["UIImagePickerControllerOriginalImage"] as? UIImage
            {
                self.imagePickedBlock?(image)
                self.imageViewProfilePic.image = image
                self.imgURL = URL(string: "\(info["UIImagePickerControllerImageURL"]!)")
            }
            else{ print("Something went wrong in  image") }
            self.dismiss(animated: true, completion: nil)
        }
        @objc func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
            if let error = error {
                print(error.localizedDescription)
                //            let alert = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
                //            alert.addAction(UIAlertAction(title: "OK", style: .default))
                //            present(alert, animated: true)
            } else {
                print("Image saved successfully")
                //            let alert = UIAlertController(title: "Saved!", message: "Image saved successfully", preferredStyle: .alert)
                //            alert.addAction(UIAlertAction(title: "OK", style: .default))
                //            present(alert, animated: true)
            }
}
}

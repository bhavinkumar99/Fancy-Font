//
//  RatesVC.swift
//  Maestro
//
//  Created by Setblue on 21/12/18.
//  Copyright © 2018 Setblue. All rights reserved.
//

import UIKit
import Cosmos

class RatesVC: BaseVC,UITextViewDelegate {

    //MARK: PROPERTIES
    @IBOutlet var imageViewSubstituteBG: UIImageView!
    @IBOutlet var lblSubName: UILabel!
    @IBOutlet var viewRating: CosmosView!
    @IBOutlet var txtViewReview: UITextView!
    @IBOutlet var lblReviewPH: UILabel!
    @IBOutlet var constraintViewTextViewHeight: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewRating.didFinishTouchingCosmos = { rating in
            if rating < 5 {
                self.constraintViewTextViewHeight.constant = 75
                self.lblReviewPH.isHidden = false
                UIView.animate(withDuration: 0.3, animations: {
                    self.view.layoutIfNeeded()
                })
            }
            else {
                self.constraintViewTextViewHeight.constant = 0
                self.lblReviewPH.isHidden = true
                UIView.animate(withDuration: 0.3, animations: {
                    self.view.layoutIfNeeded()
                })
            }
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setMenuNavigation(left_imagename: ICON_BACK, left_action: #selector(backToPreview), right_imagename: "", right_action: #selector(doNOthing), title: "Rate To Substitute", isCenterLogo: false)
    }
    
    //MARK: CUSTOM METHODS
    @objc func backToPreview() {
            hideKeyboard()
            self.navigationController?.popViewController(animated: false) }
    
    func callTeacherGiveRates() {
        if isConnectedToNetwork(){
            let param = [REQ_teacher_id : APP_DELEGATE.USER_INFO.teacherId as Any,REQ_rate :viewRating.rating,REQ_rate_comments: txtViewReview.text!] as typeAliasDictionary
            APP_DELEGATE.showAppLoader()
            ServiceCollection.sharedInstance.postTeacherGiveRates(param: param) { (resData, rstatus, message) in
                APP_DELEGATE.removeAppLoader()
                if rstatus == 1 {
                    self.navigationController?.popViewController(animated: false)
                    APP_DELEGATE.removeAppLoader()
                }
                else{
                    showAlertWithTitleWithMessage(message: message)
                    APP_DELEGATE.removeAppLoader()
                }
            }
        }
        else {
            showNoInternetAlert()
        }
    }
    //MARK: BUTTON ACTION
    @IBAction func btnCompleteAction() {
        hideKeyboard()
        if viewRating.rating < 5 {
            if txtViewReview.text == "" {
                showAlertWithTitleWithMessage(message: "Enter Review First!")
                return
            }
        }
        self.callTeacherGiveRates()
    }

    //MARK: UITEXTVIEW DELEGATE
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        let currentText = textView.text!
        guard let stringRange = Range(range, in: currentText) else { return false }
        let changedText = currentText.replacingCharacters(in: stringRange, with: text)
        lblReviewPH.isHidden = changedText == "" ? false : true
        return true
    }
}

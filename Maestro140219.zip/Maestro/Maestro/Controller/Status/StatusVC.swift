//
//  StatusVC.swift
//  Maestro
//
//  Created by Setblue on 06/12/18.
//  Copyright © 2018 Setblue. All rights reserved.
//

import UIKit
import Cosmos
import CoreLocation
import SwiftyJSON

class StatusVC: BaseVC,JDAlertViewDelegate,CLLocationManagerDelegate {

    //MARK: PROPERTIES
    @IBOutlet var viewBG: UIView!
    
    //View Initial
    @IBOutlet var imageViewStartScreenBG: UIImageView!
    @IBOutlet var viewStartScreenBG: UIView!
    @IBOutlet var viewInnerStartScreenBG: UIView!
    @IBOutlet var lblAvailbleTitle: UILabel!
    @IBOutlet var btnAvailableRequest: UIButton!
    
    //View Search
    @IBOutlet var viewSearchBG: UIView!
    @IBOutlet var viewSearchRoundViewBG: UIView!
    @IBOutlet var lblSearchingTitle: UILabel!
    @IBOutlet var lblSearchHangTightTitle: UILabel!
    @IBOutlet var btnGoOffline: UIButton!
    
    //View Assignment Check In
    @IBOutlet var viewAssignmentCheckInBG: UIView!
    @IBOutlet var imageViewAssignmentCheckInBG: UIImageView!
    @IBOutlet var lblAssignmentCheckInAddress: UILabel!
    
    //View Assignmmnet Check out
    @IBOutlet var viewAssignmentCheckOutBG: UIView!
    @IBOutlet var imageViewAssignmentCheckoutBG: UIImageView!
    @IBOutlet var lblAssignmentCheckOutAddress: UILabel!
    @IBOutlet var lblAssignmentCheckOutDetails: UILabel!
    @IBOutlet var lblAssignmentCheckOutTotalTimeSpent: UILabel!
    
    //View Follow Up
    @IBOutlet var viewFollowUpBG: UIView!
    @IBOutlet var imageViewFollowUpBG: UIImageView!
    @IBOutlet var lblSubstituteNameFollowup: UILabel!
    @IBOutlet var viewRatingsFollowUp: CosmosView!
    @IBOutlet var lblTotalAssignmentFollowup: UILabel!
    @IBOutlet var lblNotesFollowup: UILabel!
    @IBOutlet var lblTotalTimeSpentFollowup: UILabel!
    @IBOutlet var btnFollowUpBG: UIButton!
    @IBOutlet var btnCancelSubFollowUp: UIButton!
    
    //View Cancel
    @IBOutlet var viewCancelBG: UIView!
    @IBOutlet var lblViewCancelTitle: UILabel!
    @IBOutlet var btnComplateCancelView: UIButton!
    @IBOutlet var lblOppsCancelView: UILabel!
    
    
    //MARK: VARIABLES
    fileprivate var _Status_View_Type : STATUS_PAGE_VIEW_TYPE = .I_AM_AVAILABLE
    fileprivate var _JDDatePopover = JD_DatePopover()
   
    let locationMgr = CLLocationManager()
    var timerMaqLable : Timer!
    var timerShowCongratulation : Timer!
    var timerSearchData : Timer!
    var timeOfbutton = 10
    fileprivate var isTeacher : Bool = false
    fileprivate var startDate : Date!
    fileprivate var endDate : Date!
    fileprivate var _JD_AlertView = JD_AlertView()
    fileprivate var dictDataInfo : typeAliasDictionary = typeAliasDictionary()
    
//    fileprivate var isTeacher : Bool = GetSetModel.iskeyAlreadyExist(key: UD_KEY_APPUSER_INFO) ? (APP_DELEGATE.USER_INFO.loginType! == "teacher" ? true : false) : false

//    fileprivate var isTeacher : Bool = GetSetModel.iskeyAlreadyExist(key: UD_KEY_APPUSER_INFO) ? (APP_DELEGATE.USER_INFO.loginType! == "teacher" ? true : false) :  ((GetSetModel.getObjectFromUserDefaults(UD_KEY_APPUSER_INFO) as! UserClass).loginType == "teacher" ? true : false)


    override func viewDidLoad() {
        super.viewDidLoad()
        APP_DELEGATE.navigationController = self.navigationController
    }
    override func viewWillAppear(_ animated: Bool) {
        isTeacher = APP_DELEGATE.USER_INFO.loginType! == "teacher" ? true : false
        if !isTeacher { self.getLocationPermission() }
        self.getCurrentStatus()
        UIView.animate(withDuration: 0.3) { self.view.layoutIfNeeded() }
        super.viewWillAppear(animated)
        setMenuNavigation(left_imagename: "", left_action: #selector(doNOthing), right_imagename: "", right_action: #selector(doNOthing), title: "", isCenterLogo: true)
    }
    
    //MARK: CUSTOM METHODS
    func timerContinue(_ isStart : Bool) {
        runOnMainThread {
            if isStart {
                self.timerSearchData = Timer.scheduledTimer(timeInterval: TimeInterval(15), target: self, selector: #selector(self.getCurrentStatus), userInfo: nil, repeats: true)
            }
            else {
                if self.timerSearchData != nil {
                    self.timerSearchData.invalidate()
                    self.timerSearchData = Timer()
                }
            }
        }
    }
    
    func showCurrentView() {
        switch _Status_View_Type {
        case .I_AM_AVAILABLE:
            lblAvailbleTitle.text = "Mark yourself available. Maestro will alert its partners that you are available."
            btnAvailableRequest.setTitle("I'm Available", for: .normal)
//            btnAvailableRequest.isSelected = false
            viewSearchBG.isHidden = true
            viewAssignmentCheckInBG.isHidden = true
            viewAssignmentCheckOutBG.isHidden = true
            viewFollowUpBG.isHidden = true
            viewStartScreenBG.isHidden = false
            viewInnerStartScreenBG.isHidden = false
            imageViewStartScreenBG.isHidden = false
            viewCancelBG.isHidden = true
            GetSetModel.setStringValueToUserDefaults(strValue: _Status_View_Type.rawValue, ForKey: UD_STATUS_CURRENT_VIEW)
            break
        case .REQ_SUBSTITUTE:
            lblAvailbleTitle.text = "Things happen! Request a substitute by selecting the button below."
            btnAvailableRequest.setTitle("Request Substitute", for: .normal)
//            btnAvailableRequest.isSelected = true
            viewSearchBG.isHidden = true
            viewAssignmentCheckInBG.isHidden = true
            viewAssignmentCheckOutBG.isHidden = true
            viewFollowUpBG.isHidden = true
            viewCancelBG.isHidden = true
            viewStartScreenBG.isHidden = false
            viewInnerStartScreenBG.isHidden = false
            imageViewStartScreenBG.isHidden = false
            GetSetModel.setStringValueToUserDefaults(strValue: _Status_View_Type.rawValue, ForKey: UD_STATUS_CURRENT_VIEW)
            
            break
        case .SEARCH_ASSIGNMENT:
            //Hang tight! You will be alerted once you have been placed with an assignment!
            viewSearchBG.isHidden = false
            viewAssignmentCheckInBG.isHidden = true
            viewAssignmentCheckOutBG.isHidden = true
            viewFollowUpBG.isHidden = true
            viewCancelBG.isHidden = true
            viewStartScreenBG.isHidden = true
            GetSetModel.setStringValueToUserDefaults(strValue: _Status_View_Type.rawValue, ForKey: UD_STATUS_CURRENT_VIEW)

            self.viewSearchRoundViewBG.layoutIfNeeded()
            viewSearchRoundViewBG.cornerRadius = viewSearchRoundViewBG.frame.height / 2
            let viewIn2 : UIView = viewSearchRoundViewBG.subviews.first!
            let viewIn3 : UIView = viewIn2.subviews.first!
            let viewIn4 : UIView = viewIn3.subviews.first!
            let viewIn5 : UIView = viewIn4.subviews.first!
            viewIn2.cornerRadius = (viewIn2.frame.width / 2)
            viewIn3.cornerRadius = (viewIn3.frame.width / 2)
            viewIn4.cornerRadius = (viewIn4.frame.width / 2)
            viewIn5.cornerRadius = (viewIn5.frame.width / 2)
            
            
            lblSearchHangTightTitle.text = "Hang tight! You will be alerted once you have been placed with an assignment!"
//            lblSearchingTitle.text = "Searching..."
//            btnGoOffline.isSelected = false
            btnGoOffline.setTitle("Go Offline", for: .normal)

            timerMaqLable = Timer.scheduledTimer(timeInterval: TimeInterval(1), target: self, selector: #selector(setMaqLable), userInfo: nil, repeats: true)
            
            break
        case .SEARCH_SUBSTITUTE:
            //Hang tight! Maestro is searching for substitutes in your area. You will be notified once a substitute has accepted the assignment.
            viewSearchBG.isHidden = false
            viewAssignmentCheckInBG.isHidden = true
            viewAssignmentCheckOutBG.isHidden = true
            viewFollowUpBG.isHidden = true
            viewCancelBG.isHidden = true
            viewStartScreenBG.isHidden = true
            GetSetModel.setStringValueToUserDefaults(strValue: _Status_View_Type.rawValue, ForKey: UD_STATUS_CURRENT_VIEW)

            self.viewSearchRoundViewBG.layoutIfNeeded()
            viewSearchRoundViewBG.cornerRadius = viewSearchRoundViewBG.frame.height / 2
            let viewIn2 : UIView = viewSearchRoundViewBG.subviews.first!
            let viewIn3 : UIView = viewIn2.subviews.first!
            let viewIn4 : UIView = viewIn3.subviews.first!
            let viewIn5 : UIView = viewIn4.subviews.first!
            viewIn2.cornerRadius = (viewIn2.frame.width / 2)
            viewIn3.cornerRadius = (viewIn3.frame.width / 2)
            viewIn4.cornerRadius = (viewIn4.frame.width / 2)
            viewIn5.cornerRadius = (viewIn5.frame.width / 2)

            lblSearchHangTightTitle.text = "Hang tight! Maestro is searching for substitutes in your area. You will be notified once a substitute has accepted the assignment."
            btnGoOffline.setTitle("Stop Searching", for: .normal)
            timerMaqLable = Timer.scheduledTimer(timeInterval: TimeInterval(1), target: self, selector: #selector(setMaqLable), userInfo: nil, repeats: true)
            break
        case .CURRENT_ASS_CHECKIN:
            viewSearchBG.isHidden = true
            viewAssignmentCheckInBG.isHidden = false
            viewAssignmentCheckOutBG.isHidden = true
            viewFollowUpBG.isHidden = true
            viewCancelBG.isHidden = true
            viewStartScreenBG.isHidden = true
            imageViewAssignmentCheckInBG.sd_setImage(with: URL(string: dictDataInfo[RES_Thumbnail]! as! String), completed: nil)
            lblAssignmentCheckInAddress.text = (dictDataInfo[RES_Address] as! String)
            
            break
        case .CURRENT_ASS_CHECKOUT:
            viewSearchBG.isHidden = true
            viewAssignmentCheckInBG.isHidden = true
            viewAssignmentCheckOutBG.isHidden = false
            viewFollowUpBG.isHidden = true
            viewCancelBG.isHidden = true
            viewStartScreenBG.isHidden = true
            self.setCheckOutInfo()
            break
        case .CURRENT_ASS_FOLLOWUP_DISABLE:
            viewSearchBG.isHidden = true
            viewAssignmentCheckInBG.isHidden = true
            viewAssignmentCheckOutBG.isHidden = true
            viewFollowUpBG.isHidden = false
            viewStartScreenBG.isHidden = true
            viewCancelBG.isHidden = true
            btnCancelSubFollowUp.isHidden = dictDataInfo[RES_Cancel_button]as! Int == 1 ? false : true
            btnFollowUpBG.backgroundColor = UIColor.gray
            imageViewFollowUpBG.sd_setImage(with: URL(string: dictDataInfo[RES_Profile]! as! String), completed: nil)
            lblSubstituteNameFollowup.text = "\(dictDataInfo[RES_Fullname]!)"
            viewRatingsFollowUp.rating = dictDataInfo[RES_User_rate] as! Double
            viewRatingsFollowUp.text = "( \(dictDataInfo[RES_User_rate]!) )"
            lblTotalTimeSpentFollowup.text = "Total Assignment Completed : \(dictDataInfo[RES_Total_assignment_completed]!)"
            lblNotesFollowup.text = "Notes:\n \(dictDataInfo[RES_Assignment_notes]!)"
            lblTotalTimeSpentFollowup.text = "Total time spent : \(dictDataInfo[RES_Total_spent_time]!)"
            
            break
        case .CURRENT_ASS_FOLLOWUP_ENABLE:
            viewSearchBG.isHidden = true
            viewAssignmentCheckInBG.isHidden = true
            viewAssignmentCheckOutBG.isHidden = true
            viewFollowUpBG.isHidden = false
            viewStartScreenBG.isHidden = true
            viewCancelBG.isHidden = true
            btnFollowUpBG.backgroundColor = COLOR_NAV
            btnCancelSubFollowUp.isHidden = true
            imageViewFollowUpBG.sd_setImage(with: URL(string: dictDataInfo[RES_Profile]! as! String), completed: nil)
            lblSubstituteNameFollowup.text = "\(dictDataInfo[RES_Fullname]!)"
            viewRatingsFollowUp.rating = dictDataInfo[RES_User_rate] as! Double
            viewRatingsFollowUp.text = "( \(dictDataInfo[RES_User_rate]!) )"
            lblTotalTimeSpentFollowup.text = "Total Assignment Completed : \(dictDataInfo[RES_Total_assignment_completed]!)"
            lblNotesFollowup.text = "Notes:\n \(dictDataInfo[RES_Assignment_notes]!)"
            lblTotalTimeSpentFollowup.text = "Total time spent : \(dictDataInfo[RES_Total_spent_time]!)"
            break
            
        case .CANCEL_VIEW:
            viewSearchBG.isHidden = true
            viewAssignmentCheckInBG.isHidden = true
            viewAssignmentCheckOutBG.isHidden = true
            viewFollowUpBG.isHidden = true
            viewStartScreenBG.isHidden = true
            viewCancelBG.isHidden = false
            lblOppsCancelView.text = "Opps!"
            btnComplateCancelView.setTitle("Complete", for: .normal)
            lblViewCancelTitle.text = isTeacher ? "The substitute has cancelled assignment. Don’t worry we will find another substitute for you." : "The teacher has cancelled the request. Don’t worry we will find another assignment for you."
            break
        case .USER_RESPONCE_PENDING :
            viewSearchBG.isHidden = true
            viewAssignmentCheckInBG.isHidden = true
            viewAssignmentCheckOutBG.isHidden = true
            viewFollowUpBG.isHidden = true
            viewStartScreenBG.isHidden = true
            viewCancelBG.isHidden = false
            lblOppsCancelView.text = "Substitute Response Pending"
            btnComplateCancelView.setTitle("Cancel Substitute", for: .normal)
            lblViewCancelTitle.text = "Substitute is think about your assignment wait for moment\nHe will respond within two minutes."
            break
            
        default :
            break
        }
        UIView.animate(withDuration: 0.3) {
            self.view.layoutIfNeeded()
        }
    }
    func getLocationPermission() {
        
        let status  = CLLocationManager.authorizationStatus()
        if status == .notDetermined {
            locationMgr.requestWhenInUseAuthorization()
            return
        }
        if status == .denied || status == .restricted {
            let alert = UIAlertController(title: "Location Services Disabled", message: "Location Services must be turned on for Assignment searching.", preferredStyle: .alert)
            
            let okAction = UIAlertAction(title: "OK", style: .default, handler: { (alertAction) in
                    let settingsUrl = NSURL(string:UIApplication.openSettingsURLString)
                    if let url = settingsUrl {
                        if #available(iOS 10.0, *) {
                            UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
                        } else {
                            // Fallback on earlier versions
                        }
                    }
            })
            alert.addAction(okAction)
            
            present(alert, animated: true, completion: nil)
            
            return
        }
        locationMgr.delegate = self
        locationMgr.startUpdatingLocation()

    }

    @objc func showCongratulationView(_ dict : typeAliasDictionary){
        let congratulation = loadVC(SB_MAIN, strVCId: VC_CONGRATULATION) as! CongratulationVC
        congratulation.isTeacher = isTeacher
        congratulation.dictInfo = dict
        self.navigationController?.pushViewController(congratulation, animated: true)
    }
    
    @objc func setMaqLable() {
        timeOfbutton -= 1
        if timeOfbutton == 0 {
            timerMaqLable.invalidate()
            timeOfbutton = 15
            return
        }
        lblSearchingTitle.text = "\((timeOfbutton % 3 == 0) ? "Searching.." : "\((timeOfbutton % 3 == 1) ? "Searching." : "Searching... " )")"
    }
    
    func setCheckOutInfo() {
        let myAttributesR: [NSAttributedString.Key : Any] = [
            NSAttributedString.Key.font: UIFont.init(name: FONT_SAN_FRANCISCO_REGULAR, size: 15) as Any]
        let myAttributesB: [NSAttributedString.Key : Any] = [
            NSAttributedString.Key.font: UIFont.init(name: FONT_SAN_FRANCISCO_BOLD, size: 15) as Any]
        let myString = NSMutableAttributedString(string: "Teacher :", attributes: myAttributesB)
        let strValue = NSMutableAttributedString(string: " \(dictDataInfo[RES_Fullname]!)\n", attributes: myAttributesR)
        myString.append(strValue)

        let myStringGrade = NSMutableAttributedString(string: "Grade :", attributes: myAttributesB)
        myString.append(myStringGrade)
        let strValueGrade = NSMutableAttributedString(string: " \(dictDataInfo[RES_Grade]!)\n", attributes: myAttributesR)
        myString.append(strValueGrade)
        
        let myStringClass = NSMutableAttributedString(string: "Class Room Number :", attributes: myAttributesB)
        myString.append(myStringClass)
        let strValueClass = NSMutableAttributedString(string: " \(dictDataInfo[RES_Class_room_no]!)\n", attributes: myAttributesR)
        myString.append(strValueClass)
        
        let myStringTime = NSMutableAttributedString(string: "Assignment Start Time :", attributes: myAttributesB)
        myString.append(myStringTime)
        let strValueTime = NSMutableAttributedString(string: " \(dictDataInfo[RES_Assignment_time]!)\n\n", attributes: myAttributesR)
        myString.append(strValueTime)
        
        let myStringNote = NSMutableAttributedString(string: "Notes :\n", attributes: myAttributesB)
        myString.append(myStringNote)
        let strValueNote = NSMutableAttributedString(string: " \(dictDataInfo[RES_Assignment_notes]!)\n", attributes: myAttributesR)
        myString.append(strValueNote)
        
        lblAssignmentCheckOutDetails.attributedText = myString

        let myTotalTime = NSMutableAttributedString(string: "Total time spent :", attributes: myAttributesR)
//        let strTotalTimeValue = NSMutableAttributedString(string: " 8:45", attributes: myAttributesB)
        let strTotalTimeValue = NSMutableAttributedString(string: " \(dictDataInfo[RES_Total_spent_time]!)", attributes: myAttributesB)

        myTotalTime.append(strTotalTimeValue)
        
        lblAssignmentCheckOutTotalTimeSpent.attributedText = myTotalTime
        lblAssignmentCheckOutAddress.text = "\(dictDataInfo[RES_Address]!)"
        imageViewAssignmentCheckoutBG.sd_setImage(with: URL(string: dictDataInfo[RES_Thumbnail]! as! String), completed: nil)
    }

    @objc func getCurrentStatus() {
        if isConnectedToNetwork(){
            let param = [(isTeacher ? REQ_teacher_id : REQ_user_id) : isTeacher ?  APP_DELEGATE.USER_INFO.teacherId :  APP_DELEGATE.USER_INFO.userId] as typeAliasDictionary
            APP_DELEGATE.showAppLoader()
            ServiceCollection.sharedInstance.postGetCurrentStatus(param: param, isTeacher: isTeacher, response: { ( resData, rstatus, message) in
                APP_DELEGATE.removeAppLoader()
                if rstatus == 1 {
                    switch resData[RES_Screen_name] as! String {
                    //User
                    case "I_AM_AVAILABLE" :
                        self._Status_View_Type = .I_AM_AVAILABLE
                        self.timerContinue(false)
                        break
                    case "SEARCH_ASSIGNMENT" :
                        self._Status_View_Type = .SEARCH_ASSIGNMENT
                        if resData[RES_Search] as! Int == 0
                        {
                            self.timerContinue(false)
                            if self.timerMaqLable != nil {
                                self.timerMaqLable.invalidate()
                                self.timerMaqLable = Timer()
                            }
                            self.timerContinue(true)
                        }
                        else {
                            self.timerContinue(false)
                            var resData1 : typeAliasDictionary = resData[RES_Data] as! typeAliasDictionary
                            resData1[RES_Message] = message as AnyObject
                            self.showCongratulationView(resData1)
                        }
                        break
                    case "CURRENT_ASS_CHECKIN" :
                        self._Status_View_Type = .CURRENT_ASS_CHECKIN
                        self.dictDataInfo = resData[RES_Data] as! typeAliasDictionary
                        break
                    case "CURRENT_ASS_CHECKOUT" :
                        self._Status_View_Type = .CURRENT_ASS_CHECKOUT
                        self.dictDataInfo = resData[RES_Data] as! typeAliasDictionary

                        break
                    // Teacher
                    case "REQ_SUBSTITUTE" :
                        self._Status_View_Type = .REQ_SUBSTITUTE
                        self.timerContinue(false)
                        break
                    case "SEARCH_SUBSTITUTE" :
                        self._Status_View_Type = .SEARCH_SUBSTITUTE
                        if resData[RES_Search] as! Int == 0
                        {
                            self.timerContinue(false)
                            if self.timerMaqLable != nil {
                                self.timerMaqLable.invalidate()
                                self.timerMaqLable = Timer()
                            }
                            self.timerContinue(true)
                        }
                        else {
                            self.timerContinue(false)
                            self.showCongratulationView(resData[RES_Data] as! typeAliasDictionary)
                        }
                        break
                    case "CURRENT_ASS_FOLLOWUP_DISABLE" :
                        self._Status_View_Type = .CURRENT_ASS_FOLLOWUP_DISABLE
                        self.dictDataInfo = resData[RES_Data] as! typeAliasDictionary
                        self.timerContinue(false)
                        self.timerContinue(true)
                        break
                    case "CURRENT_ASS_FOLLOWUP_ENABLE" :
                        self._Status_View_Type = .CURRENT_ASS_FOLLOWUP_ENABLE
                        self.dictDataInfo = resData[RES_Data] as! typeAliasDictionary
                        self.timerContinue(false)
                        self.timerContinue(true)
                        break
                    case "CANCEL_VIEW" :
                        self._Status_View_Type = .CANCEL_VIEW
                        break
                    case "USER_RESPONCE_PENDING" :
                        self._Status_View_Type = .USER_RESPONCE_PENDING
                        self.timerContinue(false)
                        self.timerContinue(true)
                        break
                        
                    default :
                        break
                    }
                    self.showCurrentView()
                    UIView.animate(withDuration: 0.3) { self.view.layoutIfNeeded() }
                    APP_DELEGATE.removeAppLoader()
                }
                else{
                    showAlertWithTitleWithMessage(message: message)
                    APP_DELEGATE.removeAppLoader()
                }
            })
        }
        else {
            showNoInternetAlert()
        }
    }
    func callTeacherCancelSubstitute() {
        if isConnectedToNetwork(){
            let param = [REQ_teacher_id : APP_DELEGATE.USER_INFO.teacherId as Any,REQ_user_id : dictDataInfo["User_id"]! as Any] as typeAliasDictionary
            APP_DELEGATE.showAppLoader()
            ServiceCollection.sharedInstance.postTeacherCancelUser(param: param) { (resData, rstatus, message) in
                APP_DELEGATE.removeAppLoader()
                if rstatus == 1 {
                    self.navigationController?.popViewController(animated: false)
                    APP_DELEGATE.removeAppLoader()
                }
                else{
                    showAlertWithTitleWithMessage(message: message)
                    APP_DELEGATE.removeAppLoader()
                }
            }
        }
        else {
            showNoInternetAlert()
        }
    }
    
    func callCreateAssignment(_ time : String,duration : String) {
        if isConnectedToNetwork(){
            let param = [REQ_teacher_id : APP_DELEGATE.USER_INFO.teacherId,REQ_start_datetime :time,REQ_duration : duration] as typeAliasDictionary
            APP_DELEGATE.showAppLoader()
            ServiceCollection.sharedInstance.postCreateAssignment(param: param) { (resData, rstatus, message) in
                APP_DELEGATE.removeAppLoader()
                if rstatus == 1 {
                    self._Status_View_Type = .SEARCH_SUBSTITUTE
                    self.showCurrentView()
                    UIView.animate(withDuration: 0.3) { self.view.layoutIfNeeded() }
                    APP_DELEGATE.removeAppLoader()
                }
                else{
                    showAlertWithTitleWithMessage(message: message)
                    APP_DELEGATE.removeAppLoader()
                }
            }
        }
        else {
            showNoInternetAlert()
        }
    }
    func callIAmAvailable(_ lat : String,long : String) {
        if isConnectedToNetwork(){
            let param = [REQ_user_id : APP_DELEGATE.USER_INFO.userId,REQ_latitude :lat,REQ_longitude : long] as typeAliasDictionary
            APP_DELEGATE.showAppLoader()
            ServiceCollection.sharedInstance.postIAmAvailable(param: param) { (resData, rstatus, message) in
                APP_DELEGATE.removeAppLoader()
                if rstatus == 1 {
                    self._Status_View_Type = .SEARCH_ASSIGNMENT
                    self.showCurrentView()
                    self.timerContinue(true)
                    UIView.animate(withDuration: 0.3) { self.view.layoutIfNeeded() }
                    APP_DELEGATE.removeAppLoader()
                }
                else{
                    showAlertWithTitleWithMessage(message: message)
                    APP_DELEGATE.removeAppLoader()
                }
            }
        }
        else {
            showNoInternetAlert()
        }
    }
    func callCheckInAsssignment(_ isCheckIn : Bool) {
        if isConnectedToNetwork(){
            let param = [REQ_user_id : APP_DELEGATE.USER_INFO.userId] as typeAliasDictionary
            APP_DELEGATE.showAppLoader()
            ServiceCollection.sharedInstance.postCheckInOutAssignment(param: param, isCheckIn: isCheckIn) { (resData, rstatus, message) in
                APP_DELEGATE.removeAppLoader()
                if rstatus == 1 {
                    if !isCheckIn {
                        let notes = loadVC(SB_MAIN, strVCId: VC_NOTES) as! NotesVC
                        notes.isTeacher = self.isTeacher
                        self.navigationController?.pushViewController(notes, animated: true)
                    }
                    else {
                    self.getCurrentStatus()
                }
                }
                else{
                    showAlertWithTitleWithMessage(message: message)
                    APP_DELEGATE.removeAppLoader()
                }
            }
        }
        else {
            showNoInternetAlert()
        }
    }
    func callGoOffline(_ isteacher : Bool) {
        if isConnectedToNetwork(){
            let param = [(isTeacher ? REQ_teacher_id : REQ_user_id) : isTeacher ?  APP_DELEGATE.USER_INFO.teacherId :  APP_DELEGATE.USER_INFO.userId] as typeAliasDictionary
            APP_DELEGATE.showAppLoader()
            ServiceCollection.sharedInstance.postGoOffline(param: param, isTeacher: isTeacher) { (resData, rstatus, message) in
                APP_DELEGATE.removeAppLoader()
                if rstatus == 1 {
                    self._Status_View_Type = self.isTeacher ? .REQ_SUBSTITUTE : .I_AM_AVAILABLE
                    self.showCurrentView()
                    UIView.animate(withDuration: 0.3) { self.view.layoutIfNeeded() }
                    APP_DELEGATE.removeAppLoader()
                }
                else{
                    showAlertWithTitleWithMessage(message: message)
                    APP_DELEGATE.removeAppLoader()
                }
            }
        }
        else {
            showNoInternetAlert()
        }
    }

    func callUserCancelAssignment() {
        if isConnectedToNetwork(){
            let param = [REQ_user_id : APP_DELEGATE.USER_INFO.userId as Any] as typeAliasDictionary
            APP_DELEGATE.showAppLoader()
            ServiceCollection.sharedInstance.postClaimAssignment(param: param, isCliam: false) { (resData, rstatus, message) in
                APP_DELEGATE.removeAppLoader()
                if rstatus == 1 {
                    self.getCurrentStatus()
                    APP_DELEGATE.removeAppLoader()
                }
                else{
                    showAlertWithTitleWithMessage(message: message)
                    APP_DELEGATE.removeAppLoader()
                }
            }
        }
        else {
            showNoInternetAlert()
        }
    }
    
    func callCancelAssignmentOk() {
        if isConnectedToNetwork(){
            let param = [(isTeacher ? REQ_teacher_id : REQ_user_id) : isTeacher ?  APP_DELEGATE.USER_INFO.teacherId :  APP_DELEGATE.USER_INFO.userId] as typeAliasDictionary
            APP_DELEGATE.showAppLoader()
            ServiceCollection.sharedInstance.postCancelComplateOK(param: param, isTeacher: isTeacher) { (resData, rstatus, message) in
                APP_DELEGATE.removeAppLoader()
                if rstatus == 1 {
                    self.getCurrentStatus()
                    APP_DELEGATE.removeAppLoader()
                }
                else{
                    showAlertWithTitleWithMessage(message: message)
                    APP_DELEGATE.removeAppLoader()
                }
            }
        }
        else {
            showNoInternetAlert()
        }
    }
    
    //JD ALERTVIEW DELEGATE
    func jdAlertViewAction(_ alertType: ALERT_TYPE, buttonIndex: Int, buttonTitle: String, object: String) {
        if buttonIndex == 0 {
        switch alertType {
        case .CANCEL_ASSIGNMENT:
            self.callUserCancelAssignment()
            break
        case.CHECKOUT:
            self.callCheckInAsssignment(false)
            break
        case.CANCEL_SUBSTITUTE:
            self.callTeacherCancelSubstitute()
            break
        default:
            break
        }
        }
    }
    
    func jdActionSheetAction(_ actionSheetType: ACTION_SHEET_TYPE, buttonIndex: Int, buttonTitle: String, object: String) {
    }
    
    func showDateSelectionPopover(_ date_Type : DATE_TYPE,isDuration : Bool,startDate : String) {
        let date = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy hh:mm a"
        let currentDate = formatter.string(from: date)
        let sDate: String = ""
        if isDuration {
             _JDDatePopover = JD_DatePopover.init(currentDate, minimumDate: startDate, maximumDate: currentDate, dateFormat: .DDMMYYYY, dateType: date_Type, isOutSideClickedHidden: false, pickerFormat: .Picker_DateAndTime,title: "Select End Time")
        }
        else {
             _JDDatePopover = JD_DatePopover.init(sDate, minimumDate: currentDate, maximumDate: "", dateFormat: .DDMMYYYY, dateType: date_Type, isOutSideClickedHidden: false, pickerFormat: .Picker_DateAndTime,title: "Select Start Time")
        }
        _JDDatePopover.delegate = self
        self.tabBarController?.viewControllers![1].view.addSubview(_JDDatePopover)
    }
    //MARK: BUTTON ACTION
    @IBAction func btnAvailbaleRequestAction(_ sender: UIButton) {
        if isTeacher {
            self.showDateSelectionPopover (.DUMMY, isDuration: false, startDate: "")
            return
        }
        else {
            self.callIAmAvailable("\(locationMgr.location!.coordinate.latitude)", long: "\(locationMgr.location!.coordinate.longitude)")
        }
    }

    //View Search
    @IBAction func btnGoOfflineViewSearch_Action() {
        self.timerContinue(false)
        self.callGoOffline(isTeacher)
    }
    
    //View Assignment Check In
    @IBAction func btnAssignmentCheckInAction() {
        self.callCheckInAsssignment(true)

    }
    @IBAction func btnAssignmentCheckInCancelAction() {
        _JD_AlertView.showAlertView(["Yes"], message: MSG_QUE_CANCEL_ASIGNMENT, isIncludeCancelButton: true, alertType: .CANCEL_ASSIGNMENT, object: "")
        _JD_AlertView.delegate = self
    }
    //View Assignment Check Out
    @IBAction func btnAssignmentCheckOutAction() {
        _JD_AlertView.showAlertView(["Yes"], message: MSG_QUE_CHECKOUT, isIncludeCancelButton: true, alertType: .CHECKOUT, object: "")
        _JD_AlertView.delegate = self
    }
    //ViewFollowUp
    @IBAction func btnFollowUpAction() {
        if _Status_View_Type == .CURRENT_ASS_FOLLOWUP_DISABLE {
            return
        }
        else {
            let notes = loadVC(SB_MAIN, strVCId: VC_RATES) as! RatesVC
            self.navigationController?.pushViewController(notes, animated: true)
            
//        GetSetModel.setStringValueToUserDefaults(strValue: STATUS_PAGE_VIEW_TYPE.REQ_SUBSTITUTE.rawValue, ForKey: UD_STATUS_CURRENT_VIEW)
//            APP_DELEGATE.setHomeVC()
        }
    }
    @IBAction func btnCancelSubFollowupAction() {
        _JD_AlertView.showAlertView(["Yes"], message: MSG_QUE_CANCEL_SUBSTITUTE, isIncludeCancelButton: true, alertType: .CANCEL_SUBSTITUTE, object: "")
        _JD_AlertView.delegate = self
       
    }
    //View Cancel
    @IBAction func btnCompleteCancelViewAction() {
        self.getCurrentStatus()
//        self.callCancelAssignmentOk()
    }
}
extension StatusVC : JD_DatePopoverDelegate {
    
    func jdDatePopoverSelectedDate(_ jdDate: Date, strDate: String, dateType: DATE_TYPE, dateFormat: DateFormatter) {
       
    }
    
    func jdDatePopoverClearDate(_ dateType: DATE_TYPE) {
        
    }
    
    func jdDatePopoverSelectedDate(_ jdDate: Date, strDate: String, dateType: DATE_TYPE) {
        switch dateType {
        case .DUMMY:
            if strDate != "" {
                startDate = jdDate
                self.showDateSelectionPopover (.DUARTION, isDuration: true, startDate: strDate)
            }
            break
        case .DUARTION:
            if strDate != "" {
                let interval : TimeInterval = TimeInterval(jdDate.seconds(from: startDate))
                let daysRemainder = interval.truncatingRemainder(dividingBy: 60*60*24)
                let hours = (daysRemainder / (60 * 60)).rounded(.down)
                let hoursRemainder = daysRemainder.truncatingRemainder(dividingBy: 60 * 60).rounded(.down)
                let minites  = (hoursRemainder / 60).rounded(.down)
                
                let df:DateFormatter = DateFormatter()
                df.dateFormat = "yyyy-MM-dd hh:mm a"
                let stSelectedDate = df.string(from: startDate)
                self.callCreateAssignment(stSelectedDate, duration: "\(Int(hours)):\(Int(minites))")

            }
            break
        default:
            break
        }
    }
    
    
}

//
//  LoginVC.swift
//  Maestro
//
//  Created by Setblue on 06/12/18.
//  Copyright © 2018 Setblue. All rights reserved.
//

import UIKit
import SwiftyJSON

class LoginVC: BaseVC {

    //MARK: PROPERTIES
    @IBOutlet var txtEmail: UITextField!
    @IBOutlet var txtPassword: UITextField!
    
    override var prefersStatusBarHidden: Bool { return true }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        APP_DELEGATE.navigationController = self.navigationController
        self.navigationController?.navigationBar.isHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
    }
    
    //MARK: UIBUTTON ACTION
    @IBAction func btnLoginAction() {
        let strEmail : String = txtEmail.text!
        let strPassword : String = txtPassword.text!

        if strEmail.isEmpty {
            showAlertWithTitleWithMessage(message: MSG_TXT_EMAIL)
            return
        }
        if strPassword.isEmpty {
            showAlertWithTitleWithMessage(message: MSG_TXT_PASSCODE)
            return
        }
        if isConnectedToNetwork(){
            let param = [REQ_email : strEmail,REQ_password : strPassword,REQ_device_token:getUDID()] as typeAliasDictionary
            APP_DELEGATE.showAppLoader()
            hideKeyboard()

            ServiceCollection.sharedInstance.postLogin(param: param, response: {(respDic,rstatus,message) in
                APP_DELEGATE.removeAppLoader()
                
                if rstatus == 1 {
                    let json = JSON(respDic)
                    let user : UserClass = UserClass.init(json : json)
                    APP_DELEGATE.USER_INFO = user
                    GetSetModel.setObjectToUserDefaults(objValue: removeNullFromDictionary(respDic), ForKey: UD_KEY_APPUSER_INFO)
                    APP_DELEGATE.setHomeVC()
                }else{
                    showAlertWithTitleWithMessage(message: message)
                }
            })
        }
        else {
            showNoInternetAlert()
        }
    }
    
    @IBAction func btnForgotPasswordAction() {
        let forgotVC = loadVC(SB_MAIN, strVCId: VC_FORGOTPASSWORD) as! ForgotPasswordVC
        forgotVC.strEmail = txtEmail.text!
        self.navigationController?.pushViewController(forgotVC, animated: true)
    }
    
}
extension LoginVC : UITextFieldDelegate {

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == txtEmail { txtPassword.becomeFirstResponder() }
        else { txtPassword.resignFirstResponder() }
        return true
    }
}

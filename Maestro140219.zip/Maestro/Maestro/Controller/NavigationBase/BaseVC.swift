//
//  BaseVC.swift
//
//  Created by Devang Tandel on 23/03/17.
//  Copyright © 2017 Setblue. All rights reserved.
//

import UIKit
import StoreKit

class BaseVC: UIViewController, UITabBarControllerDelegate {
    
    var btnleft: UIButton!
    var btnright : UIButton!
    var rightBarItem : UIBarButtonItem!
    var cartBarItem : UIBarButtonItem!
    var saveCartItem : UIBarButtonItem!
    
    //MARK: - LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //MARK: - SET NAVIGATION BAR    
    func setMenuNavigation(left_imagename: String,left_action: Selector?,right_imagename: String,right_action: Selector?,title: String, isCenterLogo : Bool) {
        
        let negativeSpacer:UIBarButtonItem = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.fixedSpace, target: nil, action: nil)
        negativeSpacer.width = -10
        self.navigationItem.leftBarButtonItem = nil
        self.navigationItem.rightBarButtonItem = nil
        self.navigationController?.navigationBar.layer.masksToBounds = false
        self.navigationController?.navigationBar.isTranslucent = false
        
        if !(left_imagename.count == 0 ) {
            self.navigationItem.hidesBackButton = false
            btnleft = UIButton(frame: CGRect(x:0, y:0, width:25, height:25))
            btnleft.setTitleColor(UIColor.white, for: .normal)
            btnleft.contentMode = .left
            btnleft.setImage(UIImage.init(named: "\(left_imagename)"), for: .normal)
            btnleft.addTarget(self, action: left_action!, for: .touchDown)
            let backBarButon: UIBarButtonItem = UIBarButtonItem(customView: btnleft)
            self.navigationItem.setLeftBarButtonItems([negativeSpacer,backBarButon], animated: false)
        }

        if isCenterLogo {
            let img_Logo: UIImageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 100, height: 30))
            img_Logo.contentMode = .scaleAspectFit
            img_Logo.clipsToBounds = true
            img_Logo.image = #imageLiteral(resourceName: "image_maestro_logo_C")
            self.navigationItem.titleView = img_Logo
            
        } else if title.count > 0 {
            let lblValues: UILabel = UILabel()
            lblValues.text = title
            lblValues.clipsToBounds = false
            lblValues.backgroundColor = .clear
            lblValues.textColor = COLOR_NAV
            lblValues.font = UIFont.init(name: FONT_SAN_FRANCISCO_BOLD, size: 23)
            lblValues.sizeToFit()
            self.navigationItem.titleView = lblValues
        }
        
        if !(right_imagename.count == 0){
            btnright = UIButton(frame: CGRect(x:0, y:0, width:25, height:25))
            btnright.layer.cornerRadius = btnright.frame.width/2
            btnright.setImage(UIImage.init(named: "\(right_imagename)"), for: .normal)
            btnright.addTarget(self, action: right_action!, for: .touchDown)
            rightBarItem = UIBarButtonItem(customView: btnright)
            self.navigationItem.setRightBarButtonItems([negativeSpacer, rightBarItem], animated: false)
            
            //Set Empty view
            self.navigationItem.hidesBackButton = false
            btnleft = UIButton(frame: CGRect(x:0, y:0, width:25, height:25))
            btnleft.setTitleColor(UIColor.white, for: .normal)
            btnleft.contentMode = .left
            btnleft.isUserInteractionEnabled = false
            let backBarButon: UIBarButtonItem = UIBarButtonItem(customView: btnleft)
            self.navigationItem.setLeftBarButtonItems([negativeSpacer,backBarButon], animated: false)
        }
    }
    
    @objc func dismissController()  {
        self.dismiss(animated:true , completion: nil)
    }
    
    //MARK: - POP TO VIEW
    @objc func navigateToPreviousView()  {
        if let navController = self.navigationController {
            navController.popViewController(animated: true)
        }
    }
    @objc func doNOthing() { }

}


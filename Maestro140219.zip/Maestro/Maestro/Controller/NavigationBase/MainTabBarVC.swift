//
//  MainTabBarVC.swift
//  Maestro
//
//  Created by Setblue on 20/12/18.
//  Copyright © 2018 Setblue. All rights reserved.
//

import UIKit

class MainTabBarVC: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.selectedIndex = 1
//        let mainTab = self.storyboard?.instantiateViewController(withIdentifier: TAB_MAIN) as! MainTabBarVC
//        mainTab.selectedViewController = mainTab.viewControllers![1]
//        APP_DELEGATE.window?.rootViewController = mainTab
    }
}

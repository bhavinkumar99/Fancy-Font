//
//  ProfileVC.swift
//  Maestro
//
//  Created by Setblue on 06/12/18.
//  Copyright © 2018 Setblue. All rights reserved.
//

import UIKit
import Cosmos
import SDWebImage
import SwiftyJSON

class ProfileVC: BaseVC {

    //MARK: PROPERTIES
    @IBOutlet var imageViewProfilPic: UIImageView!
    @IBOutlet var lblUserName: UILabel!
    @IBOutlet var viewRatingBG: CosmosView!
    @IBOutlet var lblTotalAssignment: UILabel!
    @IBOutlet var activityIndicatorProfilePic: UIActivityIndicatorView!
    @IBOutlet var constraintViewRatingHeight: NSLayoutConstraint!
    
    //MARK: VARIABLES
    fileprivate var isTeacher : Bool = false
    internal var userDetail : UserDetailClass!
    internal var teacherDetail : TeacherDetailClass!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setMenuNavigation(left_imagename: "", left_action: #selector(doNOthing), right_imagename: "", right_action: #selector(doNOthing), title: "", isCenterLogo: true)
        APP_DELEGATE.navigationController = (self.navigationController)
        isTeacher = APP_DELEGATE.USER_INFO.loginType! == "teacher" ? true : false
        lblUserName.text = APP_DELEGATE.USER_INFO.fullname!
        
        if isTeacher {
            self.getTeacherData()
            self.constraintViewRatingHeight.constant = 80
        }
        else {
            //Meastro
            self.constraintViewRatingHeight.constant = 140
            self.getUserData()
        }
    }
    
    //MARK: CUSTOM METHOD

    func getUserData(){
        if isConnectedToNetwork(){
            let param = [REQ_user_id : APP_DELEGATE.USER_INFO.userId] as typeAliasDictionary
            APP_DELEGATE.showAppLoader()
            hideKeyboard()
            ServiceCollection.sharedInstance.postUserDetail(param: param) { (resData, rstatus, message) in
                 APP_DELEGATE.removeAppLoader()
                    if rstatus == 1 {
                    let json = JSON(resData)
                    let user : UserDetailClass = UserDetailClass.init(json : json)
                    self.lblUserName.text = user.fullname!
                    self.userDetail = user
                    let strValue = "Total Assignment Completed : "
                    let myAttributesR: [NSAttributedString.Key : Any] = [
                        NSAttributedString.Key.font: UIFont.init(name: FONT_SAN_FRANCISCO_REGULAR, size: 17) as Any]
                    let myString = NSMutableAttributedString(string: strValue, attributes: myAttributesR)
                    
                    let myAttributesB: [NSAttributedString.Key : Any] = [
                        NSAttributedString.Key.font: UIFont.init(name: FONT_SAN_FRANCISCO_BOLD, size: 17) as Any]
                    let strCount = NSMutableAttributedString(string: "\(String(describing: user.totalAssignmentCompleted!))", attributes: myAttributesB)
                    myString.append(strCount)
                    self.lblTotalAssignment.attributedText = myString
                    self.viewRatingBG.rating = Double(Int(user.userRate!))
                    self.viewRatingBG.text = "(\(Double(Int(user.userRate!))))"
                        self.activityIndicatorProfilePic.startAnimating()
                        self.imageViewProfilPic.sd_setImage(with: URL(string: user.profile!), completed: { (img, error, type, url) in
                        self.activityIndicatorProfilePic.stopAnimating()
                        })
                }else{
                    showAlertWithTitleWithMessage(message: message)
                }
            }
        }
        else {
            showNoInternetAlert()
        }
    }
    func getTeacherData(){
        if isConnectedToNetwork(){
            let param = [REQ_teacher_id : APP_DELEGATE.USER_INFO.teacherId] as typeAliasDictionary
            APP_DELEGATE.showAppLoader()
            hideKeyboard()
            ServiceCollection.sharedInstance.postTeacherDetail(param: param, response: {(respDic,rstatus,message) in
                APP_DELEGATE.removeAppLoader()
                if rstatus == 1 {
                    let json = JSON(respDic)
                    let user : TeacherDetailClass = TeacherDetailClass.init(json : json)
                    self.teacherDetail = user
                    self.lblUserName.text = user.fullname!
                    let strValue = "Total Assignment Assigned : "
                    let myAttributesR: [NSAttributedString.Key : Any] = [
                        NSAttributedString.Key.font: UIFont.init(name: FONT_SAN_FRANCISCO_REGULAR, size: 17) as Any]
                    let myString = NSMutableAttributedString(string: strValue, attributes: myAttributesR)
                    
                    let myAttributesB: [NSAttributedString.Key : Any] = [
                        NSAttributedString.Key.font: UIFont.init(name: FONT_SAN_FRANCISCO_BOLD, size: 17) as Any]
                    let strCount = NSMutableAttributedString(string: "\(String(describing: user.totalAssignmentAssigned!))", attributes: myAttributesB)
                    myString.append(strCount)
                    self.activityIndicatorProfilePic.startAnimating()
                    self.imageViewProfilPic.sd_setImage(with: URL(string: user.thumbnail!), completed: { (img, error, type, url) in
                        self.activityIndicatorProfilePic.stopAnimating()
                    })
                    self.lblTotalAssignment.attributedText = myString
                }else {
                    showAlertWithTitleWithMessage(message: message)
                }
            })
        }
        else {
            showNoInternetAlert()
        }
    }
    //MARK: BUTTION ACTION
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "idPushToSettings") {
            // pass data to next view
            let viewController:SettingVC = segue.destination as! SettingVC
            viewController.isTeacher = self.isTeacher
            if isTeacher {
                    viewController.teacherDetail = self.teacherDetail
            }
            else {
                viewController.userDetail = self.userDetail
            }
        }
        else if (segue.identifier == "idPushToEditProfile") {
            // pass data to next view
            let viewController:EditProfileVC = segue.destination as! EditProfileVC
            viewController.isTeacher = self.isTeacher
            if isTeacher {
                viewController.teacherDetail = self.teacherDetail
            }
            else {
                viewController.userDetail = self.userDetail
            }
        }
    }
}

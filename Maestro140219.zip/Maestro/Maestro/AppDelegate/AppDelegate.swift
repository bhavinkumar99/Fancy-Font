//
//  AppDelegate.swift
//  Maestro
//
//  Created by Setblue on 06/12/18.
//  Copyright © 2018 Setblue. All rights reserved.
//

import UIKit
import UserNotifications
import Firebase
import FirebaseInstanceID
import FirebaseMessaging
import SwiftyJSON

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate,MessagingDelegate {

    var window: UIWindow?
    var navigationController: UINavigationController!
    var loaderView :UIView!
    var imglogoBG :UIView!
    var imglogo:UIImageView!
    var USER_INFO : UserClass!

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
      
        FirebaseApp.configure()
        Messaging.messaging().delegate = self
        
        if !GetSetModel.iskeyAlreadyExist(key: UD_KEY_APPUSER_INFO)
        { setLoginVC() }
        else {
            let json = JSON(GetSetModel.getObjectFromUserDefaults(UD_KEY_APPUSER_INFO))
            let user : UserClass = UserClass.init(json : json)
            self.USER_INFO = user
        }
        
        if !GetSetModel.iskeyAlreadyExist(key: UD_STATUS_CURRENT_VIEW) {
            GetSetModel.setStringValueToUserDefaults(strValue: "\(STATUS_PAGE_VIEW_TYPE.DUMMY.rawValue)", ForKey: UD_STATUS_CURRENT_VIEW)
        }
        
        //PUSH NOTIFICATION
        if #available(iOS 10.0, *) {
            UNUserNotificationCenter.current().delegate = self
            let authOptions: UNAuthorizationOptions = [.alert, .badge, .sound]
            UNUserNotificationCenter.current().requestAuthorization(
                options: authOptions,
                completionHandler: {_, _ in })
        } else {
            let settings: UIUserNotificationSettings =
                UIUserNotificationSettings(types: [.alert, .badge, .sound], categories: nil)
            application.registerUserNotificationSettings(settings)
        }
        application.registerForRemoteNotifications()
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
    }

    func applicationWillTerminate(_ application: UIApplication) {
    }
    
    //MARK: - FIREBASE METHODS
    func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String) {
        print("Firebase registration token: \(fcmToken)")
        GetSetModel.setStringValueToUserDefaults(strValue: fcmToken, ForKey: UD_KEY_UDID)
    }
    func messaging(_ messaging: Messaging, didReceive remoteMessage: MessagingRemoteMessage) {
        print("Received data message: \(remoteMessage.appData)")
    }
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("Unable to register for remote notifications: \(error.localizedDescription)")
    }
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        Messaging.messaging().apnsToken = deviceToken
    }
    
    //MARK: -  SHOW APP LOADER
    func showAppLoader() {
        
        if loaderView != nil{
            loaderView.removeFromSuperview()
        }
        loaderView = UIView(frame: CGRect(x: 0,y: 0,width: SCREENWIDTH(),height: SCREENHEIGHT()))
        loaderView.backgroundColor = COLOR_CUSTOM(0, 0, 0, 0.3)
        imglogoBG = UIView(frame: CGRect(x: 0,y: 0,width: 110,height: 110))
        imglogoBG.backgroundColor = .white
        imglogoBG.setCornerRadius(radius: 8)
        imglogo = UIImageView(frame: CGRect(x: 0,y: 0,width: 100,height: 100))
        imglogo.createBordersWithColor(color: UIColor.clear, radius:20, width: 0.0)
        imglogo.backgroundColor = .clear
        imglogo.image = #imageLiteral(resourceName: "image_maestro_logo")
        imglogoBG.center = loaderView.center
        imglogo.center = loaderView.center
        imglogo.contentMode = .scaleAspectFit
        loaderView.addSubview(imglogoBG)
        loaderView.addSubview(imglogo)
        let rotation = CABasicAnimation(keyPath: "transform.rotation")
        rotation.fromValue = 0
        rotation.toValue =  2 * Double.pi
        rotation.duration = 1.5
        rotation.repeatCount = Float.infinity
        imglogo.layer.add(rotation, forKey: "Spin")
        self.window?.addSubview(loaderView)
    }
    
    //MARK: -  REMOVE LOADER
    func removeAppLoader() {
        if loaderView != nil {
            loaderView.removeFromSuperview()
        }
    }
    //MARK: CUSTOM METHODS
    func setLoginVC(){
        let centerVC = loadVC(SB_MAIN, strVCId: NC_LOGIN )
        self.window?.rootViewController = centerVC
    }
    func setHomeVC(){
        let centerVC = loadVC(SB_MAIN, strVCId: TAB_MAIN )
        self.window?.rootViewController = centerVC
    }
    
}


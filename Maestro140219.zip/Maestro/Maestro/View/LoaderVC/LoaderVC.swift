//
//  LoaderVC.swift
//
//  Created by Setblue on 03/08/17.
//  Copyright © 2017 V2ideas. All rights reserved.
//

import UIKit

class LoaderVC: UIViewController {

    @IBOutlet var activity: UIActivityIndicatorView!
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - Show Picker
    func showLoaderInAppWindow() {
        
        self.view.frame = CGRect(x:0 ,y:0, width:SCREENWIDTH(), height:SCREENHEIGHT())
        self.view.transform = CGAffineTransform(scaleX:0, y:0)
        activity.startAnimating()
        
        APP_DELEGATE.window! .addSubview(self.view!)
        UIView.animate(withDuration: 0.10 ,delay: 0.0, options: .transitionCurlUp, animations: {
            self.activity.transform = CGAffineTransform(scaleX:2, y:2)
            self.view.transform = CGAffineTransform(scaleX:1, y:1)
        }, completion: nil)
        
    }
    
    //MARK: - Show Picker
    func showLoaderInView(myView : UIView) {
        
        self.view.frame = CGRect(x:0 ,y:0, width:SCREENWIDTH(), height:myView.frame.height)
        self.view.transform = CGAffineTransform(scaleX:0, y:0)
        activity.startAnimating()
        myView.addSubview(self.view!)
        UIView.animate(withDuration: 0.10 ,delay: 0.0, options: .transitionCurlUp, animations: {
            self.activity.transform = CGAffineTransform(scaleX:2, y:2)
            self.view.transform = CGAffineTransform(scaleX:1, y:1)
        }, completion: nil)
        
    }
    
    //MARK: - Hide Picker
    func hideLoader() {
        
        runOnMainThread {
            
            UIView.animate(withDuration: 0.10, delay: 0.0, options: .transitionCurlDown, animations: {
                self.view.transform = CGAffineTransform(scaleX:0,y:0)
            }) { (isFinished) in
                self.view!.removeFromSuperview()
            }
            
            UIView.animate(withDuration: 0.10 ,delay: 0.0, options: .transitionCurlUp, animations: {
            }, completion: nil)
        }
    }
}

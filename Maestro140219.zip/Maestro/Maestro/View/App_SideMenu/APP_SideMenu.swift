//
//  APP_SideMenu.swift
//  CalcVault
//
//  Created by Setblue on 24/07/18.
//  Copyright © 2018 Setblue. All rights reserved.
//

import UIKit

class APP_SideMenu: UIView,UIGestureRecognizerDelegate,UITableViewDelegate,UITableViewDataSource {
    
    //MARK: CONSTANT
    internal let TAG_SUPPER: Int = 10000
    let SELECTION_SUPER_VIEW_TAG            = 10001
    let SELECTION_SUB_VIEW_TAG              = 110001
    
    let COLOUR_BG                           = COLOR_CUSTOM(255, 255, 255, 1)
    let COLOUR_WHITE_TRANSPARENT            = COLOR_CUSTOM(255, 255, 255, 0.4)
    let COLOUR_BLACK_TRANSPARENT            = COLOR_CUSTOM(0, 0, 0, 0.4)

    let TAG_TITLE                           = 1001
    let TAG_IMAGE                           = 1000
    let TAG_SUB_TITLE                       = 1003
    let TAG_SUB_IMAGE                       = 1004
    
    let TAG_ICON                             = 100
    let TEXT_SUB: CGFloat                    = 14
    let TEXT_MAIN: CGFloat                   = 14
    
    //MARK: PROPERTIES
    @IBOutlet var ViewBG: UIView!
    @IBOutlet var tableViewList: UITableView!
    
    //MARK: VARIABLES
    let obj_AppDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    var width:CGFloat = 0
    var arrList = [String]()
    var arrSections = NSIndexSet()
    var constrintLeading:NSLayoutConstraint!
    var selectedSection:Int = -1
    var selectedRow:Int = -1
    var isSubChild:Bool = false
    var SubCount:Int = 0
    var counter:Int = 0
    
    required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
    }
    
    private func loadXIB(){
        let view = Bundle.main.loadNibNamed(String(describing: type (of: self)), owner: self, options: nil)?[0] as! UIView
        view.translatesAutoresizingMaskIntoConstraints = false
        self.tableViewList.tableFooterView = UIView(frame: CGRect.zero)
        self.addSubview(view)
        self.layoutIfNeeded()
    }
    
    override init(frame :CGRect){
        super.init(frame: frame)
        self.loadXIB()
        let frame:CGRect = UIScreen.main.bounds
        self.frame = frame
        self.backgroundColor = COLOUR_BLACK_TRANSPARENT
        self.loadData()
        let gestureTap : UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(hideMenuAction))
        self.isUserInteractionEnabled = true
        self.isMultipleTouchEnabled = true
        self.tag = SELECTION_SUPER_VIEW_TAG
        gestureTap.delegate = self
        self.addGestureRecognizer(gestureTap)
        width = frame.width * 0.73
        
        let dict:typeAliasDictionary = DesignModel.setConstraint_Leading_Top_ConWidth_ConHeight(subView: ViewBG, superView: self, leading: -width, top: 0, width: width, height: self.frame.height)
        constrintLeading = (dict[CONSTRAINT_LEADING] as! NSLayoutConstraint)
        self.alpha = 1
        UIView.animate(withDuration: 0.3, delay: 0.0, options: UIView.AnimationOptions.beginFromCurrentState, animations: {() -> Void in
            self.alpha = 1
        }, completion: {(finished: Bool) -> Void in
            self.constrintLeading.constant = 0
            UIView.animate(withDuration: 0.3, delay: 0.0, options: UIView.AnimationOptions.beginFromCurrentState, animations: {() -> Void in
                self.layoutIfNeeded()
            }, completion: nil)
        })
    }
    internal func loadData()
    {
        if isAdRemoved() {
            arrList = ["HOME","IMAGE LOCKER","VIDEO LOCKER","NOTES LOCKER","CREDENTIAL LOCKER","SHARE","RATE US","SETTING"]
        }
        else {
            arrList = ["HOME","IMAGE LOCKER","VIDEO LOCKER","NOTES LOCKER","CREDENTIAL LOCKER","SHARE","RATE US","REMOVE ADS","RESTORE PURCHASE","SETTING"]

        }
        tableViewList.register(UINib.init(nibName: CELL_IDENTIFIER_SIDE_MENU, bundle: nil), forCellReuseIdentifier: CELL_IDENTIFIER_SIDE_MENU)
        tableViewList.tableFooterView = UIView(frame: CGRect.zero)
        tableViewList.rowHeight = HEIGHT_SIDE_MENU
        tableViewList.bounces = false
        tableViewList.reloadData()
        tableViewList.allowsSelection = true
    }
    
    @objc internal func hideMenuAction() {
        constrintLeading.constant = -width
        UIView.animate(withDuration: 0.3, delay: 0.0, options:UIView.AnimationOptions.beginFromCurrentState, animations: {() -> Void in
            self.layoutIfNeeded()
        }, completion: {(finished: Bool) -> Void in
            UIView.animate(withDuration: 0.3, delay: 0.0, options:UIView.AnimationOptions.beginFromCurrentState, animations: {() -> Void in
                self.alpha = 0
            }, completion: {(finished: Bool) -> Void in
                self.removeFromSuperview()
                self.layer.removeAllAnimations()
            })
        })
    }
    
    //MARK: UI GESTURE RRECOGNIZER
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        let view: UIView = touch.view!
        let viewTag: Int = Int(view.tag)
        print("Touch View Tag : \(viewTag)")
        if viewTag != SELECTION_SUPER_VIEW_TAG { return false }
        return true
    }
    
    //MARK: TABLE VIEW DATA SOURCE
    func numberOfSections(in tableView: UITableView) -> Int { return 1 }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { return arrList.count }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        /*
        let cell: SideMenuCell = tableView.dequeueReusableCell(withIdentifier: CELL_IDENTIFIER_SIDE_MENU) as! SideMenuCell
        let str : String = self.arrList[indexPath.row]
        cell.lblTittle.text = str
        if str == "HOME" { cell.imageView?.image = #imageLiteral(resourceName: "icon_Calculator(R)")}
        else if str == "IMAGE LOCKER" { cell.imageView?.image = #imageLiteral(resourceName: "icon_Photo(R)")}
        else if str == "VIDEO LOCKER" { cell.imageView?.image = #imageLiteral(resourceName: "icon_Video(R)")}
        else if str == "NOTES LOCKER" { cell.imageView?.image = #imageLiteral(resourceName: "icon_Notes(R)")}
        else if str == "CREDENTIAL LOCKER" { cell.imageView?.image = #imageLiteral(resourceName: "icon_Credential(R)")}
        else if str == "SETTING" { cell.imageView?.image = #imageLiteral(resourceName: "icon_Setting(R)")}
        else if str == "SHARE" { cell.imageView?.image = #imageLiteral(resourceName: "icon_Share(R)")}
        else if str == "RATE US" { cell.imageView?.image = #imageLiteral(resourceName: "icon_Rate(R)")}
        else if str == "REMOVE ADS" { cell.imageView?.image = #imageLiteral(resourceName: "icon_Advertise(R)")}
        else if str == "RESTORE PURCHASE" { cell.imageView?.image = #imageLiteral(resourceName: "icon_RestorePurchase")}
        cell.selectionStyle = .none
        return cell
 */ return UITableViewCell()
    }
    //MARK: TABLE VIEW DELEGATE
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        /*
        let str : String = self.arrList[indexPath.row]
        self.hideMenuAction()
        if str == "HOME" { APP_DELEGATE.showDashboardView() }
        else if str == "IMAGE LOCKER" { APP_DELEGATE.showMediaPage(.IMAGE) }
        else if str == "VIDEO LOCKER" { APP_DELEGATE.showMediaPage(.VIDEO) }
        else if str == "NOTES LOCKER" { APP_DELEGATE.showTextListPage(.NOTE) }
        else if str == "CREDENTIAL LOCKER" { APP_DELEGATE.showTextListPage(.CREDENTIAL) }
        else if str == "SETTING" { APP_DELEGATE.showSettingPage() }
        else if str == "SHARE" { APP_DELEGATE.ShareApp() }
        else if str == "RATE US" { APP_DELEGATE.openRateUs() }
        else if str == "REMOVE ADS" { APP_DELEGATE.showSettingPage() }
        else if str == "RESTORE PURCHASE" { APP_DELEGATE.showSettingPage() }
 */
    }
    
}

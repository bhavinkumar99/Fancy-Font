//
//  UserClass.swift
//
//  Created by Setblue on 01/01/19
//  Copyright (c) . All rights reserved.
//

import Foundation
import SwiftyJSON

public final class UserClass {

  // MARK: Declaration for string constants to be used to decode and also serialize.
  private struct SerializationKeys {
    static let status = "Status"
    static let email = "Email"
    static let created = "Created"
    static let appRate = "App_rate"
    static let password = "Password"
    static let loginType = "Login_type"
    static let userId = "User_id"
    static let fullname = "Fullname"
    static let profile = "Profile"
    static let grade = "Grade"
    static let latitude = "Latitude"
    static let classRoomNo = "Class_room_no"
    static let address = "Address"
    static let longitude = "Longitude"
    static let thumbnail = "Thumbnail"
    static let teacherId = "Teacher_id"
    static let ownRates = "Own_rates"
    static let radius = "Radius"
  }
    
  // MARK: Properties
  public var status: String?
  public var email: String?
  public var created: String?
  public var appRate: String?
  public var password: String?
  public var loginType: String?
  public var userId: String?
  public var fullname: String?
  public var profile: String?
  public var grade: String?
  public var latitude: String?
  public var classRoomNo: String?
  public var address: String?
  public var longitude: String?
  public var thumbnail: String?
  public var teacherId: String?
    public var ownRates: String?
    public var radius: String?
  // MARK: SwiftyJSON Initializers
  /// Initiates the instance based on the object.
  ///
  /// - parameter object: The object of either Dictionary or Array kind that was passed.
  /// - returns: An initialized instance of the class.
  public convenience init(object: Any) {
    self.init(json: JSON(object))
  }

  /// Initiates the instance based on the JSON that was passed.
  ///
  /// - parameter json: JSON object from SwiftyJSON.
  public required init(json: JSON) {
    status = json[SerializationKeys.status].string
    email = json[SerializationKeys.email].string
    created = json[SerializationKeys.created].string
    appRate = json[SerializationKeys.appRate].string
    password = json[SerializationKeys.password].string
    loginType = json[SerializationKeys.loginType].string
    userId = json[SerializationKeys.userId].string
    fullname = json[SerializationKeys.fullname].string
    profile = json[SerializationKeys.profile].string
    thumbnail = json[SerializationKeys.thumbnail].string
    grade = json[SerializationKeys.grade].string
    latitude = json[SerializationKeys.latitude].string
    classRoomNo = json[SerializationKeys.classRoomNo].string
    address = json[SerializationKeys.address].string
    longitude = json[SerializationKeys.longitude].string
    teacherId = json[SerializationKeys.teacherId].string
    ownRates = json[SerializationKeys.ownRates].string
    radius = json[SerializationKeys.radius].string
  }

  /// Generates description of the object in the form of a NSDictionary.
  ///
  /// - returns: A Key value pair containing all valid values in the object.
  public func dictionaryRepresentation() -> [String: Any] {
    var dictionary: [String: Any] = [:]
    if let value = status { dictionary[SerializationKeys.status] = value }
    if let value = email { dictionary[SerializationKeys.email] = value }
    if let value = created { dictionary[SerializationKeys.created] = value }
    if let value = appRate { dictionary[SerializationKeys.appRate] = value }
    if let value = password { dictionary[SerializationKeys.password] = value }
    if let value = loginType { dictionary[SerializationKeys.loginType] = value }
    if let value = userId { dictionary[SerializationKeys.userId] = value }
    if let value = fullname { dictionary[SerializationKeys.fullname] = value }
    if let value = profile { dictionary[SerializationKeys.profile] = value }
    if let value = grade { dictionary[SerializationKeys.grade] = value }
    if let value = latitude { dictionary[SerializationKeys.latitude] = value }
    if let value = classRoomNo { dictionary[SerializationKeys.classRoomNo] = value }
    if let value = address { dictionary[SerializationKeys.address] = value }
    if let value = longitude { dictionary[SerializationKeys.longitude] = value }
    if let value = thumbnail { dictionary[SerializationKeys.thumbnail] = value }
    if let value = teacherId { dictionary[SerializationKeys.teacherId] = value }
    if let value = thumbnail { dictionary[SerializationKeys.ownRates] = value }
    if let value = teacherId { dictionary[SerializationKeys.radius] = value }
    return dictionary
  }

}

//
//  AboutUsContentListClass.swift
//
//  Created by Setblue on 09/10/18
//  Copyright (c) . All rights reserved.
//

import Foundation
import SwiftyJSON

public class AboutUsContentListClass {

  // MARK: Declaration for string constants to be used to decode and also serialize.
  private struct SerializationKeys {
    static let textContent = "TextContent"
    static let videoContent = "VideoContent"
    static let imageContent = "ImageContent"
    static let categoryId = "CategoryId"
    static let contentType = "ContentType"
  }

  // MARK: Properties
  public var textContent: String?
  public var videoContent: String?
  public var imageContent: String?
  public var categoryId: Int?
  public var contentType: Int?

  // MARK: SwiftyJSON Initializers
  /// Initiates the instance based on the object.
  ///
  /// - parameter object: The object of either Dictionary or Array kind that was passed.
  /// - returns: An initialized instance of the class.
  public convenience init(object: Any) {
    self.init(json: JSON(object))
  }

  /// Initiates the instance based on the JSON that was passed.
  ///
  /// - parameter json: JSON object from SwiftyJSON.
  public required init(json: JSON) {
    textContent = json[SerializationKeys.textContent].string
    videoContent = json[SerializationKeys.videoContent].string
    imageContent = json[SerializationKeys.imageContent].string
    categoryId = json[SerializationKeys.categoryId].int
    contentType = json[SerializationKeys.contentType].int
  }

  /// Generates description of the object in the form of a NSDictionary.
  ///
  /// - returns: A Key value pair containing all valid values in the object.
  public func dictionaryRepresentation() -> [String: Any] {
    var dictionary: [String: Any] = [:]
    if let value = textContent { dictionary[SerializationKeys.textContent] = value }
    if let value = videoContent { dictionary[SerializationKeys.videoContent] = value }
    if let value = imageContent { dictionary[SerializationKeys.imageContent] = value }
    if let value = categoryId { dictionary[SerializationKeys.categoryId] = value }
    if let value = contentType { dictionary[SerializationKeys.contentType] = value }
    return dictionary
  }

}

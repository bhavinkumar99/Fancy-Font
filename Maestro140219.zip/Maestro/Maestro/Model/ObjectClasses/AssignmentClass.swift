//
//  AssignmentClass.swift
//
//  Created by Setblue on 11/02/19
//  Copyright (c) . All rights reserved.
//

import Foundation
import SwiftyJSON

public final class AssignmentClass {

  // MARK: Declaration for string constants to be used to decode and also serialize.
  private struct SerializationKeys {
    static let rate = "Rate"
    static let checkinTime = "Checkin_time"
    static let assignmentTime = "Assignment_time"
    static let userNotes = "User_notes"
    static let userNotesPhoto = "User_notes_photo"
    static let created = "Created"
    static let teacherId = "Teacher_id"
    static let assignmentId = "Assignment_id"
    static let assignmentNotes = "Assignment_notes"
    static let assignmentDate = "Assignment_date"
    static let rateComments = "Rate_comments"
    static let status = "Status"
    static let checkoutTime = "Checkout_time"
    static let userId = "User_id"
    static let duration = "Duration"
    static let totalSpentTime = "Total_spent_time"
  }

  // MARK: Properties
  public var rate: String?
  public var checkinTime: String?
  public var assignmentTime: String?
  public var userNotes: String?
  public var userNotesPhoto: String?
  public var created: String?
  public var teacherId: String?
  public var assignmentId: String?
  public var assignmentNotes: String?
  public var assignmentDate: String?
  public var rateComments: String?
  public var status: String?
  public var checkoutTime: String?
  public var userId: String?
  public var duration: String?
  public var totalSpentTime: String?

  // MARK: SwiftyJSON Initializers
  /// Initiates the instance based on the object.
  ///
  /// - parameter object: The object of either Dictionary or Array kind that was passed.
  /// - returns: An initialized instance of the class.
  public convenience init(object: Any) {
    self.init(json: JSON(object))
  }

  /// Initiates the instance based on the JSON that was passed.
  ///
  /// - parameter json: JSON object from SwiftyJSON.
  public required init(json: JSON) {
    rate = json[SerializationKeys.rate].string
    checkinTime = json[SerializationKeys.checkinTime].string
    assignmentTime = json[SerializationKeys.assignmentTime].string
    userNotes = json[SerializationKeys.userNotes].string
    userNotesPhoto = json[SerializationKeys.userNotesPhoto].string
    created = json[SerializationKeys.created].string
    teacherId = json[SerializationKeys.teacherId].string
    assignmentId = json[SerializationKeys.assignmentId].string
    assignmentNotes = json[SerializationKeys.assignmentNotes].string
    assignmentDate = json[SerializationKeys.assignmentDate].string
    rateComments = json[SerializationKeys.rateComments].string
    status = json[SerializationKeys.status].string
    checkoutTime = json[SerializationKeys.checkoutTime].string
    userId = json[SerializationKeys.userId].string
    duration = json[SerializationKeys.duration].string
    totalSpentTime = json[SerializationKeys.totalSpentTime].string
  }

  /// Generates description of the object in the form of a NSDictionary.
  ///
  /// - returns: A Key value pair containing all valid values in the object.
  public func dictionaryRepresentation() -> [String: Any] {
    var dictionary: [String: Any] = [:]
    if let value = rate { dictionary[SerializationKeys.rate] = value }
    if let value = checkinTime { dictionary[SerializationKeys.checkinTime] = value }
    if let value = assignmentTime { dictionary[SerializationKeys.assignmentTime] = value }
    if let value = userNotes { dictionary[SerializationKeys.userNotes] = value }
    if let value = userNotesPhoto { dictionary[SerializationKeys.userNotesPhoto] = value }
    if let value = created { dictionary[SerializationKeys.created] = value }
    if let value = teacherId { dictionary[SerializationKeys.teacherId] = value }
    if let value = assignmentId { dictionary[SerializationKeys.assignmentId] = value }
    if let value = assignmentNotes { dictionary[SerializationKeys.assignmentNotes] = value }
    if let value = assignmentDate { dictionary[SerializationKeys.assignmentDate] = value }
    if let value = rateComments { dictionary[SerializationKeys.rateComments] = value }
    if let value = status { dictionary[SerializationKeys.status] = value }
    if let value = checkoutTime { dictionary[SerializationKeys.checkoutTime] = value }
    if let value = userId { dictionary[SerializationKeys.userId] = value }
    if let value = duration { dictionary[SerializationKeys.duration] = value }
    if let value = totalSpentTime { dictionary[SerializationKeys.totalSpentTime] = value }
    return dictionary
  }

}

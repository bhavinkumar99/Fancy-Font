//
//  TeacherDetailClass.swift
//
//  Created by Setblue on 28/01/19
//  Copyright (c) . All rights reserved.
//

import Foundation
import SwiftyJSON

public final class TeacherDetailClass {

  // MARK: Declaration for string constants to be used to decode and also serialize.
  private struct SerializationKeys {
    static let email = "Email"
    static let grade = "Grade"
    static let latitude = "Latitude"
    static let classRoomNo = "Class_room_no"
    static let address = "Address"
    static let longitude = "Longitude"
    static let fullname = "Fullname"
    static let thumbnail = "Thumbnail"
    static let password = "Password"
    static let created = "Created"
    static let teacherId = "Teacher_id"
    static let radius = "Radius"
    static let totalAssignmentAssigned = "Total_assignment_assigned"
  }

  // MARK: Properties
  public var email: String?
  public var grade: String?
  public var latitude: String?
  public var classRoomNo: String?
  public var address: String?
  public var totalAssignmentAssigned: Int?
  public var longitude: String?
  public var fullname: String?
  public var thumbnail: String?
  public var password: String?
  public var created: String?
  public var teacherId: String?
  public var radius: String?

  // MARK: SwiftyJSON Initializers
  /// Initiates the instance based on the object.
  ///
  /// - parameter object: The object of either Dictionary or Array kind that was passed.
  /// - returns: An initialized instance of the class.
  public convenience init(object: Any) {
    self.init(json: JSON(object))
  }

  /// Initiates the instance based on the JSON that was passed.
  ///
  /// - parameter json: JSON object from SwiftyJSON.
  public required init(json: JSON) {
    email = json[SerializationKeys.email].string
    grade = json[SerializationKeys.grade].string
    latitude = json[SerializationKeys.latitude].string
    totalAssignmentAssigned = json[SerializationKeys.totalAssignmentAssigned].int
    classRoomNo = json[SerializationKeys.classRoomNo].string
    address = json[SerializationKeys.address].string
    longitude = json[SerializationKeys.longitude].string
    fullname = json[SerializationKeys.fullname].string
    thumbnail = json[SerializationKeys.thumbnail].string
    password = json[SerializationKeys.password].string
    created = json[SerializationKeys.created].string
    teacherId = json[SerializationKeys.teacherId].string
    radius = json[SerializationKeys.radius].string
  }

  /// Generates description of the object in the form of a NSDictionary.
  ///
  /// - returns: A Key value pair containing all valid values in the object.
  public func dictionaryRepresentation() -> [String: Any] {
    var dictionary: [String: Any] = [:]
    if let value = email { dictionary[SerializationKeys.email] = value }
    if let value = grade { dictionary[SerializationKeys.grade] = value }
    if let value = latitude { dictionary[SerializationKeys.latitude] = value }
    if let value = classRoomNo { dictionary[SerializationKeys.classRoomNo] = value }
    if let value = totalAssignmentAssigned { dictionary[SerializationKeys.totalAssignmentAssigned] = value }
    if let value = address { dictionary[SerializationKeys.address] = value }
    if let value = longitude { dictionary[SerializationKeys.longitude] = value }
    if let value = fullname { dictionary[SerializationKeys.fullname] = value }
    if let value = thumbnail { dictionary[SerializationKeys.thumbnail] = value }
    if let value = password { dictionary[SerializationKeys.password] = value }
    if let value = created { dictionary[SerializationKeys.created] = value }
    if let value = teacherId { dictionary[SerializationKeys.teacherId] = value }
    if let value = radius { dictionary[SerializationKeys.radius] = value }
    return dictionary
  }

}

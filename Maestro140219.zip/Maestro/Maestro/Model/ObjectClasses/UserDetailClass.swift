//
//  UserDetailClass.swift
//
//  Created by Setblue on 28/01/19
//  Copyright (c) . All rights reserved.
//

import Foundation
import SwiftyJSON

public final class UserDetailClass {

  // MARK: Declaration for string constants to be used to decode and also serialize.
  private struct SerializationKeys {
    static let online = "Online"
    static let email = "Email"
    static let latitude = "Latitude"
    static let totalAssignmentCompleted = "Total_assignment_completed"
    static let userRate = "User_rate"
    static let profile = "Profile"
    static let userId = "User_id"
    static let fullname = "Fullname"
    static let password = "Password"
    static let longitude = "Longitude"
    static let created = "Created"
    static let radius = "Radius"
  }

  // MARK: Properties
  public var online: String?
  public var email: String?
  public var latitude: String?
  public var totalAssignmentCompleted: Int?
  public var userRate: Float?
  public var profile: String?
  public var userId: String?
  public var fullname: String?
  public var password: String?
  public var longitude: String?
  public var created: String?
  public var radius: String?

  // MARK: SwiftyJSON Initializers
  /// Initiates the instance based on the object.
  ///
  /// - parameter object: The object of either Dictionary or Array kind that was passed.
  /// - returns: An initialized instance of the class.
  public convenience init(object: Any) {
    self.init(json: JSON(object))
  }

  /// Initiates the instance based on the JSON that was passed.
  ///
  /// - parameter json: JSON object from SwiftyJSON.
  public required init(json: JSON) {
    online = json[SerializationKeys.online].string
    email = json[SerializationKeys.email].string
    latitude = json[SerializationKeys.latitude].string
    totalAssignmentCompleted = json[SerializationKeys.totalAssignmentCompleted].int
    userRate = json[SerializationKeys.userRate].float
    profile = json[SerializationKeys.profile].string
    userId = json[SerializationKeys.userId].string
    fullname = json[SerializationKeys.fullname].string
    password = json[SerializationKeys.password].string
    longitude = json[SerializationKeys.longitude].string
    created = json[SerializationKeys.created].string
    radius = json[SerializationKeys.radius].string
  }

  /// Generates description of the object in the form of a NSDictionary.
  ///
  /// - returns: A Key value pair containing all valid values in the object.
  public func dictionaryRepresentation() -> [String: Any] {
    var dictionary: [String: Any] = [:]
    if let value = online { dictionary[SerializationKeys.online] = value }
    if let value = email { dictionary[SerializationKeys.email] = value }
    if let value = latitude { dictionary[SerializationKeys.latitude] = value }
    if let value = totalAssignmentCompleted { dictionary[SerializationKeys.totalAssignmentCompleted] = value }
    if let value = userRate { dictionary[SerializationKeys.userRate] = value }
    if let value = profile { dictionary[SerializationKeys.profile] = value }
    if let value = userId { dictionary[SerializationKeys.userId] = value }
    if let value = fullname { dictionary[SerializationKeys.fullname] = value }
    if let value = password { dictionary[SerializationKeys.password] = value }
    if let value = longitude { dictionary[SerializationKeys.longitude] = value }
    if let value = created { dictionary[SerializationKeys.created] = value }
    if let value = radius { dictionary[SerializationKeys.radius] = value }
    return dictionary
  }

}

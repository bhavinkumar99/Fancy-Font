//
//  CompletedAssignmentUserClass.swift
//
//  Created by Setblue on 28/01/19
//  Copyright (c) . All rights reserved.
//

import Foundation
import SwiftyJSON

public final class CompletedAssignmentUserClass {

  // MARK: Declaration for string constants to be used to decode and also serialize.
  private struct SerializationKeys {
    static let teacherFullname = "Teacher_fullname"
    static let address = "Address"
    static let userId = "User_id"
    static let userFullname = "User_fullname"
    static let teacherId = "Teacher_id"
    static let thumbnail = "Thumbnail"
    static let totalSpentTime = "Total_spent_time"
    static let assignmentNotes = "Assignment_notes"
    static let assignmentId = "Assignment_id"
    static let isExpanded = "IsExpanded"
  }

  // MARK: Properties
  public var teacherFullname: String?
  public var address: String?
  public var userId: String?
  public var userFullname: String?
  public var teacherId: String?
  public var thumbnail: String?
  public var totalSpentTime: String?
  public var assignmentNotes: String?
  public var assignmentId: String?
  public var isExpanded: String?


  // MARK: SwiftyJSON Initializers
  /// Initiates the instance based on the object.
  ///
  /// - parameter object: The object of either Dictionary or Array kind that was passed.
  /// - returns: An initialized instance of the class.
  public convenience init(object: Any) {
    self.init(json: JSON(object))
  }

  /// Initiates the instance based on the JSON that was passed.
  ///
  /// - parameter json: JSON object from SwiftyJSON.
  public required init(json: JSON) {
    teacherFullname = json[SerializationKeys.teacherFullname].string
    address = json[SerializationKeys.address].string
    userId = json[SerializationKeys.userId].string
    userFullname = json[SerializationKeys.userFullname].string
    teacherId = json[SerializationKeys.teacherId].string
    thumbnail = json[SerializationKeys.thumbnail].string
    isExpanded = json[SerializationKeys.isExpanded].string
    totalSpentTime = json[SerializationKeys.totalSpentTime].string
    assignmentNotes = json[SerializationKeys.assignmentNotes].string
    assignmentId = json[SerializationKeys.assignmentId].string
  }

  /// Generates description of the object in the form of a NSDictionary.
  ///
  /// - returns: A Key value pair containing all valid values in the object.
  public func dictionaryRepresentation() -> [String: Any] {
    var dictionary: [String: Any] = [:]
    if let value = teacherFullname { dictionary[SerializationKeys.teacherFullname] = value }
    if let value = address { dictionary[SerializationKeys.address] = value }
    if let value = isExpanded { dictionary[SerializationKeys.isExpanded] = value }
    if let value = userId { dictionary[SerializationKeys.userId] = value }
    if let value = userFullname { dictionary[SerializationKeys.userFullname] = value }
    if let value = teacherId { dictionary[SerializationKeys.teacherId] = value }
    if let value = thumbnail { dictionary[SerializationKeys.thumbnail] = value }
    if let value = totalSpentTime { dictionary[SerializationKeys.totalSpentTime] = value }
    if let value = assignmentNotes { dictionary[SerializationKeys.assignmentNotes] = value }
    if let value = assignmentId { dictionary[SerializationKeys.assignmentId] = value }
    return dictionary
  }

}

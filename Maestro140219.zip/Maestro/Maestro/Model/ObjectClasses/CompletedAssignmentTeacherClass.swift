//
//  CompletedAssignmentTeacherClass.swift
//
//  Created by Setblue on 30/01/19
//  Copyright (c) . All rights reserved.
//

import Foundation
import SwiftyJSON

public final class CompletedAssignmentTeacherClass {

  // MARK: Declaration for string constants to be used to decode and also serialize.
  private struct SerializationKeys {
    static let userRate = "User_rate"
    static let totalAssignmentCompleted = "Total_assignment_completed"
    static let userId = "User_id"
    static let userNotesPhoto = "User_notes_photo"
    static let isExpanded = "IsExpanded"
    static let userNotes = "User_notes"
    static let profile = "Profile"
    static let userFullname = "User_fullname"
    static let assignmentId = "Assignment_id"
    static let totalSpentTime = "Total_spent_time"
  }

  // MARK: Properties
  public var userRate: Float?
  public var totalAssignmentCompleted: Int?
  public var userId: String?
  public var userNotesPhoto: String?
  public var isExpanded: String?
  public var userNotes: String?
  public var profile: String?
  public var userFullname: String?
  public var assignmentId: String?
  public var totalSpentTime: String?

  // MARK: SwiftyJSON Initializers
  /// Initiates the instance based on the object.
  ///
  /// - parameter object: The object of either Dictionary or Array kind that was passed.
  /// - returns: An initialized instance of the class.
  public convenience init(object: Any) {
    self.init(json: JSON(object))
  }

  /// Initiates the instance based on the JSON that was passed.
  ///
  /// - parameter json: JSON object from SwiftyJSON.
  public required init(json: JSON) {
    userRate = json[SerializationKeys.userRate].float
    totalAssignmentCompleted = json[SerializationKeys.totalAssignmentCompleted].int
    userId = json[SerializationKeys.userId].string
    userNotesPhoto = json[SerializationKeys.userNotesPhoto].string
    isExpanded = json[SerializationKeys.isExpanded].string
    userNotes = json[SerializationKeys.userNotes].string
    profile = json[SerializationKeys.profile].string
    userFullname = json[SerializationKeys.userFullname].string
    assignmentId = json[SerializationKeys.assignmentId].string
    totalSpentTime = json[SerializationKeys.totalSpentTime].string
  }

  /// Generates description of the object in the form of a NSDictionary.
  ///
  /// - returns: A Key value pair containing all valid values in the object.
  public func dictionaryRepresentation() -> [String: Any] {
    var dictionary: [String: Any] = [:]
    if let value = userRate { dictionary[SerializationKeys.userRate] = value }
    if let value = totalAssignmentCompleted { dictionary[SerializationKeys.totalAssignmentCompleted] = value }
    if let value = userId { dictionary[SerializationKeys.userId] = value }
    if let value = userNotesPhoto { dictionary[SerializationKeys.userNotesPhoto] = value }
    if let value = isExpanded { dictionary[SerializationKeys.isExpanded] = value }
    if let value = userNotes { dictionary[SerializationKeys.userNotes] = value }
    if let value = profile { dictionary[SerializationKeys.profile] = value }
    if let value = userFullname { dictionary[SerializationKeys.userFullname] = value }
    if let value = assignmentId { dictionary[SerializationKeys.assignmentId] = value }
    if let value = totalSpentTime { dictionary[SerializationKeys.totalSpentTime] = value }
    return dictionary
  }

}

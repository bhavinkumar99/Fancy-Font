
//  JD_DatePopover.swift
//  Maestro
//
//  Created by Setblue on 21/12/18.
//  Copyright © 2018 Setblue. All rights reserved.
//

let JD_DATE_POPOVER_DURATION        = 0.3

import UIKit
protocol JD_DatePopoverDelegate {
    func jdDatePopoverSelectedDate(_ jdDate: Date, strDate: String, dateType: DATE_TYPE, dateFormat: DateFormatter)
    func jdDatePopoverClearDate(_ dateType: DATE_TYPE)
    func jdDatePopoverSelectedDate(_ jdDate: Date, strDate: String,dateType: DATE_TYPE)
}

class JD_DatePopover: UIView , UIGestureRecognizerDelegate{
    
    //MARK: CONSTANTS
    internal let TAG_SUPER:Int = 101
    internal let TAG_SUB:Int = 1101
    
    
    //MARK: VARIABLES
    var delegate: JD_DatePopoverDelegate! = nil
    
    var selDate:String = ""
    var minDate = ""
    var maxDate = ""
    var titleText = ""
    var datePicker: UIDatePicker = UIDatePicker()
    var _isOutSideClickHidden: Bool = false
    var stDateFormat = ""
    var contentView:UIView! = nil
    var _jdDateFormat = JD_DateFormat(rawValue: 0)
    var _pickerFormat = JD_PickerFormat(rawValue: 0)
    var _dateType = DATE_TYPE.DUMMY
    static let sharedInstance = JD_DatePopover()
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(frame: CGRect) { super.init(frame : frame) }
    
    init(_ selectedDate: String ,minimumDate: String , maximumDate: String , dateFormat: JD_DateFormat , dateType:DATE_TYPE, isOutSideClickedHidden: Bool,title : String) {
        super.init(frame: CGRect.zero)
        
        var frame:CGRect = UIScreen.main.bounds
        frame = CGRect.init(x: 0, y: 0, width:  frame.size.width, height: frame.size.height)
        self.frame = frame
        
        selDate = selectedDate
        minDate = minimumDate
        maxDate = maximumDate
        _isOutSideClickHidden = isOutSideClickedHidden
        _jdDateFormat = dateFormat
        _dateType = dateType
        titleText = title
        self.createDatePickerView()
    }
    
    init(_ selectedDate: String ,minimumDate: String , maximumDate: String , dateFormat: JD_DateFormat , dateType:DATE_TYPE, isOutSideClickedHidden: Bool, pickerFormat: JD_PickerFormat,title : String) {
        super.init(frame: CGRect.zero)
        
        var frame:CGRect = UIScreen.main.bounds
        frame = CGRect.init(x: 0, y: 0, width:  frame.size.width, height: frame.size.height)
        self.frame = frame
        
        selDate = selectedDate
        minDate = minimumDate
        maxDate = maximumDate
        _pickerFormat = pickerFormat
        titleText = title
        _isOutSideClickHidden = isOutSideClickedHidden
        _jdDateFormat = dateFormat
        _dateType = dateType
        if pickerFormat == .Picker_Date { self.createDatePickerView() }
        else if pickerFormat == .Picker_Time { self.createTimePickerView() }
        else { self.createDateTimePickerView() }
    }
    
    private func createDatePickerView() {
        
        self.backgroundColor = COLOR_CUSTOM(0, 0, 0, 0.5)
        
        if _isOutSideClickHidden {
            let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(cancelButtonAction))
            tapGesture.delegate = self
            self.tag = TAG_SUPER
            self.addGestureRecognizer(tapGesture)
            self.isMultipleTouchEnabled = true
            self.isUserInteractionEnabled = true
        }
        
        contentView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: self.frame.width, height: 250))
        contentView.backgroundColor = UIColor.white
        self.addSubview(contentView)
        
        //UIDatePicker
        datePicker = UIDatePicker.init(frame: CGRect.init(x: 0, y: 44, width: 0, height: 0))
        datePicker.datePickerMode = .date
        datePicker.date = NSDate() as Date
        
        switch _jdDateFormat! {
            
        case .DDMMMYYYY:
            stDateFormat = "dd/MMM/yyyy"
            break
            
        case .DDMMYYYY:
            stDateFormat = "dd/MM/yyyy"
            break
            
        case .YYYYMMDD:
            stDateFormat = "yyyy/MM/dd"
            break
            
        case .MMDDYYYY:
            stDateFormat = "MM-dd-yyyy"
            break
            
        case .DDMMYYYY_HH_MM:
            stDateFormat = "dd/MM/yyyy HH:mm:ss"
            
        case .YYYYMMDD_HH_MM:
            stDateFormat = "yyyy/MM/dd HH:mm:ss"
            break
            
        default:break
        }
        
        
        let df:DateFormatter = DateFormatter()
        df.dateFormat = stDateFormat
        
        if minDate != "" { datePicker.minimumDate = df.date(from: minDate) }
        
        if maxDate != "" { datePicker.maximumDate = df.date(from: maxDate) }
        
        if selDate != "" { datePicker.setDate(df.date(from: selDate)!, animated: true) }
        
        contentView.addSubview(datePicker)
        
        //ToolBar
        let toolBar:UIToolbar = UIToolbar.init(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 30))
        toolBar.isTranslucent = false
        toolBar.barTintColor = COLOR_NAV
        toolBar.tintColor = UIColor.white
        
        var barItems = [UIBarButtonItem]()
        let flexSpace:UIBarButtonItem = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
         barItems.append(flexSpace)
        
        if !titleText.isEmpty {
            let button =  UIButton(type: .custom)
            button.frame = CGRect(x: 10, y: 0, width: FRAME_SCREEN.width / 2, height: 30)
            let label = UILabel(frame: CGRect(x: 5, y: 5, width: FRAME_SCREEN.width / 2, height: 25))
            label.font = UIFont(name: FONT_SAN_FRANCISCO_MEDIUM, size: 16)
            label.text = titleText
            label.textAlignment = .left
            label.textColor = UIColor.white
            label.backgroundColor =  .clear
            button.addSubview(label)
            let titleButton = UIBarButtonItem(customView: button)
            barItems.append(titleButton)
        }
        let cancelButton:UIBarButtonItem = UIBarButtonItem.init(barButtonSystemItem: .cancel, target: self, action:#selector(JD_DatePopover.cancelButtonAction))
        
        let clearButton:UIBarButtonItem = UIBarButtonItem.init(title: "Clear", style: UIBarButtonItem.Style.plain, target: self, action:#selector(JD_DatePopover.clearButtonAction))
        
        let doneButton:UIBarButtonItem = UIBarButtonItem.init(barButtonSystemItem: .done, target: self, action: #selector(JD_DatePopover.DoneButtonAction))
        
        
       
        barItems.append(cancelButton)
        barItems.append(clearButton)
        barItems.append(doneButton)
        
        toolBar.setItems(barItems, animated: true)
        contentView.addSubview(toolBar)
        
        var cframe:CGRect =  contentView.frame
        cframe.origin.y = UIScreen.main.bounds.height
        contentView.frame = cframe
        
        //Animation
        UIView.animate(withDuration:JD_DATE_POPOVER_DURATION, animations: {
            var Frame:CGRect = self.contentView.frame
            Frame.origin.y = UIScreen.main.bounds.height - self.contentView.frame.height;
            self.contentView.frame = Frame;
        }, completion: nil)
    }
    
    private func createDateTimePickerView() {
        
        self.backgroundColor = COLOR_CUSTOM(0, 0, 0, 0.5)
        contentView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: self.frame.width, height: isPhoneNotched() ? 300 : 250))
        contentView.backgroundColor = UIColor.white
        self.addSubview(contentView)
        
        //UIDatePicker
        datePicker = UIDatePicker.init(frame: CGRect.init(x: 0, y: 30, width: 0, height: 0))
        datePicker.datePickerMode = .dateAndTime
        datePicker.date = NSDate() as Date
        
        if selDate.count != 0 {
            switch _pickerFormat! {
            case .Picker_DateAndTime:
                switch _jdDateFormat! {
                case .YYYYMMDD:
                    datePicker.setDate(self.getDate(selDate, format: "dd-MM-yyyy hh:mm:ss"), animated: true)
                    break
                case .DDMMYYYY:
                    datePicker.setDate(self.getDate(selDate, format: "dd-MM-yyyy hh:mm a"), animated: true)
                    break
                case .MMDDYYYY:
                    datePicker.setDate(self.getDate(selDate, format: "MM-dd-yyyy hh:mm a"), animated: true)
                    break
                case .HHMMAA:
                    datePicker.setDate(self.getDate(selDate, format: "hh:mm a"), animated: true)
                    break
                default:
                    break
                }
                break
                
            case .Picker_Date:
                switch _jdDateFormat! {
                case .YYYYMMDD:
                    datePicker.setDate(self.getDate(selDate, format: "yyyy-MM-dd hh:mm:ss"), animated: true)
                    break
                case .DDMMYYYY:
                    datePicker.setDate(self.getDate(selDate, format: "dd/MM/yyyy"), animated: true)
                    break
                case .MMDDYYYY:
                    datePicker.setDate(self.getDate(selDate, format: "MM-dd-yyyy"), animated: true)
                    break
                default:
                    break
                }
                break
                
            default:
                break
            }
        }
        
        if minDate.count != 0 {
            switch _jdDateFormat! {
            case .YYYYMMDD:
                datePicker.minimumDate = self.getDate(minDate, format: "yyyy-MM-dd hh:mm:ss")
                break
            case .DDMMYYYY:
                datePicker.minimumDate = self.getDate(minDate, format: "dd-MM-yyyy hh:mm a")
                break
            case .MMDDYYYY:
                datePicker.minimumDate = self.getDate(minDate, format: "MM-dd-yyyy hh:mm a")
                break
            default:
                break
            }
        }
        
        if maxDate.count != 0 {
            switch _jdDateFormat! {
            case .YYYYMMDD:
                datePicker.minimumDate = self.getDate(maxDate, format: "yyyy-MM-dd hh:mm:ss")
                break
            case .DDMMYYYY:
                datePicker.minimumDate = self.getDate(maxDate, format: "dd-MM-yyyy hh:mm a")
                break
            case .MMDDYYYY:
                datePicker.minimumDate = self.getDate(maxDate, format: "MM-dd-yyyy hh:mm a")
                break
            default:
                break
            }
        }
        contentView.addSubview(datePicker)
        
        //ToolBar
        let toolBar: UIToolbar = UIToolbar.init(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 35))
        toolBar.isTranslucent = false
        toolBar.barTintColor = COLOR_NAV
        toolBar.tintColor = UIColor.white
       
        var barItems = [UIBarButtonItem]()
        let flexSpace:UIBarButtonItem = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancelButton:UIBarButtonItem = UIBarButtonItem.init(barButtonSystemItem:.cancel, target: self, action:#selector(JD_DatePopover.cancelButtonAction))
        
        let doneButton:UIBarButtonItem = UIBarButtonItem.init(barButtonSystemItem: .done, target: self, action: #selector(JD_DatePopover.DoneAction))
        if !titleText.isEmpty {
            let button =  UIButton(type: .custom)
            button.frame = CGRect(x: 10, y: 0, width: FRAME_SCREEN.width / 2, height: 30)
            let label = UILabel(frame: CGRect(x: 5, y: 5, width: FRAME_SCREEN.width / 2, height: 25))
            label.font = UIFont(name: FONT_SAN_FRANCISCO_MEDIUM, size: 16)
            label.text = titleText
            label.textAlignment = .left
            label.textColor = UIColor.white
            label.backgroundColor =  .clear
            button.addSubview(label)
            let titleButton = UIBarButtonItem(customView: button)
            barItems.append(titleButton)
        }
        
        barItems.append(flexSpace)
        barItems.append(cancelButton)
//        barItems.append(clearButton)
        barItems.append(doneButton)
        
        toolBar.setItems(barItems, animated: true)
        contentView.addSubview(toolBar)
        
        var cframe:CGRect =  contentView.frame
        cframe.origin.y = UIScreen.main.bounds.height
        contentView.frame = cframe
        
        //Animation
        UIView.animate(withDuration:JD_DATE_POPOVER_DURATION, animations: {
            var Frame:CGRect = self.contentView.frame
            Frame.origin.y = UIScreen.main.bounds.height - self.contentView.frame.height;
            self.contentView.frame = Frame;
        }, completion: nil)
    }
    
    private func createTimePickerView() {
        
        self.backgroundColor = COLOR_CUSTOM(0, 0, 0, 0.5)
        contentView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: self.frame.width, height: isPhoneNotched() ? 300 : 250))
        contentView.backgroundColor = UIColor.white
        self.addSubview(contentView)
        
        //UIDatePicker
        datePicker = UIDatePicker.init(frame: CGRect.init(x: 0, y: 30, width: 0, height: 0))
//        datePicker.picker
        datePicker.datePickerMode = .time
        datePicker.date = NSDate() as Date
        
//        if selDate.count != 0 {
            switch _pickerFormat! {
            case .Picker_Time:
                switch _jdDateFormat! {
                case .HHMMAA:
                    datePicker.setDate(self.getDate(selDate, format: "HH:mm"), animated: true)
                    break
                default:
                    break
                }
            break
           
            default:
                break
                
            }
//        }
        contentView.addSubview(datePicker)
        
        //ToolBar
        let toolBar: UIToolbar = UIToolbar.init(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 35))
        toolBar.isTranslucent = false
        toolBar.barTintColor = COLOR_NAV
        toolBar.tintColor = UIColor.white
        
        var barItems = [UIBarButtonItem]()
        let flexSpace:UIBarButtonItem = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancelButton:UIBarButtonItem = UIBarButtonItem.init(barButtonSystemItem:.cancel, target: self, action:#selector(JD_DatePopover.cancelButtonAction))
        
        let doneButton:UIBarButtonItem = UIBarButtonItem.init(barButtonSystemItem: .done, target: self, action: #selector(JD_DatePopover.DoneAction))
        if !titleText.isEmpty {
            let button =  UIButton(type: .custom)
            button.frame = CGRect(x: 10, y: 0, width: FRAME_SCREEN.width / 2, height: 30)
            let label = UILabel(frame: CGRect(x: 5, y: 5, width: FRAME_SCREEN.width / 2, height: 25))
            label.font = UIFont(name: FONT_SAN_FRANCISCO_MEDIUM, size: 16)
            label.text = titleText
            label.textAlignment = .left
            label.textColor = UIColor.white
            label.backgroundColor =  .clear
            button.addSubview(label)
            let titleButton = UIBarButtonItem(customView: button)
            barItems.append(titleButton)
        }
        
        barItems.append(flexSpace)
        barItems.append(cancelButton)
        barItems.append(doneButton)
        
        toolBar.setItems(barItems, animated: true)
        contentView.addSubview(toolBar)
        
        var cframe:CGRect =  contentView.frame
        cframe.origin.y = UIScreen.main.bounds.height
        contentView.frame = cframe
        
        //Animation
        UIView.animate(withDuration:JD_DATE_POPOVER_DURATION, animations: {
            var Frame:CGRect = self.contentView.frame
            Frame.origin.y = UIScreen.main.bounds.height - self.contentView.frame.height;
            self.contentView.frame = Frame;
        }, completion: nil)
    }
    func getDate(_ strDate: String, format: String) -> Date {
        let dateFormat = DateFormatter()
        dateFormat.dateFormat = format
        return dateFormat.date(from: strDate)!
    }
    
    @objc private func cancelButtonAction() {
        UIView.animate(withDuration: JD_DATE_POPOVER_DURATION, animations: {
            var Frame:CGRect = self.contentView.frame
            Frame.origin.y = UIScreen.main.bounds.height
            self.contentView.frame = Frame
        }) { (finished) in
            UIView.transition(with: self.superview!, duration: JD_DATE_POPOVER_DURATION, options: .transitionCrossDissolve, animations: {
                self.removeFromSuperview()
            }, completion: nil)
        }
    }
    
    @objc private func DoneButtonAction() {
        self.cancelButtonAction()
        let df:DateFormatter = DateFormatter()
        df.dateFormat = stDateFormat
        let stSelectedDate = df.string(from: datePicker.date)
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(JD_DATE_POPOVER_DURATION * Double(NSEC_PER_SEC)) / Double(NSEC_PER_SEC), execute: {() -> Void in
            self.delegate.jdDatePopoverSelectedDate(self.datePicker.date , strDate: stSelectedDate, dateType: self._dateType , dateFormat: df)
        })
    }
    
    @objc private func clearButtonAction() {
        self.cancelButtonAction()
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(JD_DATE_POPOVER_DURATION * Double(NSEC_PER_SEC)) / Double(NSEC_PER_SEC), execute: {() -> Void in
            self.delegate.jdDatePopoverClearDate(self._dateType)
        })
    }
    
    @objc private func DoneAction() {
        let df = DateFormatter()
        
        switch _pickerFormat! {
        case .Picker_DateAndTime:
            switch _jdDateFormat! {
            case .YYYYMMDD:
                df.dateFormat = "dd/MM/yyyy hh:mm:ss"
                break
            case .DDMMYYYY:
                df.dateFormat = "dd-MM-yyyy hh:mm a"
                break
            case .MMDDYYYY:
                df.dateFormat = "MM/dd/yyyy hh:mm a"
                break
            case .HHMMAA:
                df.dateFormat = "HH:mm:ss"
                break
            default:
                break
            }
            break
            
        case .Picker_Date:
            switch _jdDateFormat! {
            case .YYYYMMDD:
                df.dateFormat = "yyyy/MM/dd"
                break
            case .DDMMYYYY:
                df.dateFormat = "dd/MM/yyyy"
                break
            case .MMDDYYYY:
                df.dateFormat = "MM-dd-yyyy"
                break
            default:
                break
            }
            break
            
        default:
            break
        }
        
        self.cancelButtonAction()
        let selectedDate: String = df.string(from: datePicker.date)
        perform(#selector(self.callJDDatePopoverDelegateMethod), with: selectedDate, afterDelay: JD_DATE_POPOVER_DURATION)
    }
    
    @objc func callJDDatePopoverDelegateMethod(_ selectedDate: String) { self.delegate.jdDatePopoverSelectedDate(datePicker.date, strDate: selectedDate, dateType: self._dateType) }
    
    //MARK:- GestureRecognizer Delegate
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        let view = touch.view
        if view!.tag != TAG_SUPER { return false }
        return true
    }
    
    private func getDate(_JDdateFormat: JD_DateFormat, date:NSDate) -> String {
        var format:String = ""
        switch _JDdateFormat {
            
        case .DDMMMYYYY:
            format = "dd/MMM/yyyy"
            break
            
        case .DDMMYYYY:
            format = "dd/MM/yyyy"
            break
            
        case .YYYYMMDD:
            format = "yyyy/MM/dd"
            break
            
        case .MMDDYYYY:
            format = "MM-dd-yyyy"
            break
            
        case .DDMMYYYY_HH_MM:
            format = "dd/MM/yyyy HH:mm:ss"
            break
            
        case .YYYYMMDD_HH_MM:
            format = "yyyy/MM/dd HH:mm:ss"
            
        default: break
        }
        
        let dateFormat:DateFormatter = DateFormatter()
        dateFormat.dateFormat = format
        return dateFormat.string(from: date as Date)
    }
}

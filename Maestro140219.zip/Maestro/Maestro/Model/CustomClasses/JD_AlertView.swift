
//  JD_DatePopover.swift
//  Maestro
//
//  Created by Setblue on 12/02/19.
//  Copyright © 2018 Setblue. All rights reserved.
//

import UIKit

protocol JDAlertViewDelegate {
    func jdAlertViewAction(_ alertType: ALERT_TYPE, buttonIndex: Int, buttonTitle: String, object: String)
    func jdActionSheetAction(_ actionSheetType: ACTION_SHEET_TYPE, buttonIndex: Int, buttonTitle: String, object: String)
}

class JD_AlertView: NSObject {
    
    //MARK: PROPERTIES
    var delegate: JDAlertViewDelegate! = nil
    
    //MARK: VARIABLES
    let obj_AppDelegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
    fileprivate var _ALERT_TYPE: ALERT_TYPE = ALERT_TYPE.DUMMY
    fileprivate var _string: String = ""
    fileprivate var _ACTION_SHEET_TYPE: ACTION_SHEET_TYPE!
    
    internal func showYesNoAlertView(_ message: String, alertType: ALERT_TYPE, object: String) {
        _ALERT_TYPE = alertType
        _string = object
        let alertController = UIAlertController.init(title: APP_NAME, message: message, preferredStyle: UIAlertController.Style.alert)
        
        alertController.addAction(UIAlertAction.init(title: "Yes", style: UIAlertAction.Style.default) { (action) in
            self.delegate.jdAlertViewAction(self._ALERT_TYPE, buttonIndex: 0, buttonTitle: "Yes", object: self._string)
        })
        
        alertController.addAction(UIAlertAction.init(title: "No", style: UIAlertAction.Style.destructive) { (action) in
            self.delegate.jdAlertViewAction(self._ALERT_TYPE, buttonIndex: 1, buttonTitle: "No", object: self._string)
        })
        obj_AppDelegate.navigationController.present(alertController, animated: true, completion: nil)
    }
    
    internal func showOkAlertView(_ message: String, alertType: ALERT_TYPE, object: String, isCallDelegate: Bool) {
        _ALERT_TYPE = alertType
        _string = object
        let alertController = UIAlertController.init(title: APP_NAME, message: message, preferredStyle: UIAlertController.Style.alert)
        
        alertController.addAction(UIAlertAction.init(title: "OK", style: UIAlertAction.Style.default) { (action) in
            if isCallDelegate {
                self.delegate.jdAlertViewAction(self._ALERT_TYPE, buttonIndex: 0, buttonTitle: "Ok", object: self._string)
            }
        })
        APP_DELEGATE.navigationController.present(alertController, animated: true, completion: nil)
    }
    
    internal func showAlertView(_ arrTitle: [String], message: String, isIncludeCancelButton : Bool, alertType: ALERT_TYPE, object: String)
    {
        var arrTitle = arrTitle
        _ALERT_TYPE = alertType
        _string = object
        
        let alertController = UIAlertController.init(title: APP_NAME, message: message, preferredStyle: UIAlertController.Style.alert)
        
        for i in 0..<arrTitle.count {
            alertController.addAction(UIAlertAction.init(title: arrTitle[i], style: UIAlertAction.Style.default) { (action) in
                self.delegate.jdAlertViewAction(self._ALERT_TYPE, buttonIndex: i, buttonTitle: arrTitle[i], object: self._string)
            })
        }
        
        if isIncludeCancelButton {
            alertController.addAction(UIAlertAction.init(title: "Cancel", style: UIAlertAction.Style.destructive) { (action) in
                self.delegate.jdAlertViewAction(self._ALERT_TYPE, buttonIndex: arrTitle.count, buttonTitle: "Cancel", object: self._string)
            })
        }
        APP_DELEGATE.navigationController.present(alertController, animated: true, completion: nil)
    }
    
    internal func showActionSheet(_ arrTitle: [String], message: String, isIncludeCancelButton : Bool, actionSheetType: ACTION_SHEET_TYPE, object: String) {
        var arrTitle = arrTitle
        _ACTION_SHEET_TYPE = actionSheetType
        _string = object
        
        let alertController = UIAlertController.init(title: APP_NAME, message: message, preferredStyle: UIAlertController.Style.actionSheet)
        
        if isIncludeCancelButton { arrTitle.append("Cancel") }
        for i in 0..<arrTitle.count {
            alertController.addAction(UIAlertAction(title: arrTitle[i], style: .default, handler: {(_ action: UIAlertAction) -> Void in
                self.delegate.jdActionSheetAction(self._ACTION_SHEET_TYPE, buttonIndex: i, buttonTitle: arrTitle[i], object: self._string)
            }))
        }
        obj_AppDelegate.navigationController.present(alertController, animated: true, completion: nil)
    }
}

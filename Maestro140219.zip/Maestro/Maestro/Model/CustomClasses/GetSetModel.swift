//  GetSetModel.swift
//  CalcVault
//
//  Created by Setblue on 20/07/18.
//  Copyright © 2018 Setblue. All rights reserved.
//

import UIKit

// STATIC KEY
let UD_SERVICE_URL                              = "UD_SERVICE_URL"
let UD_UDID                                     = "UD_UDID"
let UD_KEY_UDID                                 = "UD_Device_Unique_Key"
let UD_KEY_ACCESSTOKEN                          = "Access TokenKey"
let UD_KEY_APPUSER_INFO                         = "App_User_Info"
let UD_APP_USER_TEACHER                         = "UD_APP_USER_TEACHER"
let UD_STATUS_CURRENT_VIEW                      = "UD_STATUS_CURRENT_VIEW"

class GetSetModel: NSObject {

    class func setStringValueToUserDefaults(strValue: String, ForKey: String) {
        UserDefaults.standard.setValue(strValue, forKey:ForKey)
        UserDefaults.standard.synchronize()
    }
    
    class func getStringValueFromUserDefaults(_ ForKey: String) -> String {
        return UserDefaults.standard.value(forKey: ForKey) as! String
    }
    
    class func setIntegerValueToUserDefaults(intValue: Int, ForKey: String) {
        UserDefaults.standard.setValue(intValue, forKey: ForKey)
        UserDefaults.standard.synchronize()
    }
    
    class func getIntegerValueFromUserDefaults(_ forKey: String) -> Int {
        return (UserDefaults.standard.value(forKey: forKey) as! Int)
    }
    
    class func setBoolValueToUserDefaults(boolValue: Bool, ForKey: String) {
        UserDefaults.standard.setValue(boolValue, forKey: ForKey)
        UserDefaults.standard.synchronize()
    }
    
    class func getBooleanValueFromUserDefaults(_ ForKey: String) -> Bool {
        return (UserDefaults.standard.value(forKey: ForKey) as! Bool)
    }
    
    class func setObjectToUserDefaults(objValue: typeAliasDictionary, ForKey: String) {
        UserDefaults.standard.setValue(objValue, forKey: ForKey)
        UserDefaults.standard.synchronize()
    }
    
    class func getObjectFromUserDefaults(_ ForKey: String) -> typeAliasDictionary {
        return UserDefaults.standard.object(forKey: ForKey) as! typeAliasDictionary
    }
    
    class func setArrayToUserDefaults(arrayData: [typeAliasDictionary], ForKey: String) {
        UserDefaults.standard.setValue(arrayData, forKey: ForKey)
        UserDefaults.standard.synchronize()
    }
    class func getArrayFromUserDefaults(_ ForKey: String) -> [typeAliasDictionary] {
        return UserDefaults.standard.object(forKey: ForKey) as! [typeAliasDictionary]
    }
    
    class func removeObjectForKey(objectKey: String) {
        UserDefaults.standard.removeObject(forKey: objectKey)
        UserDefaults.standard.setValue(nil, forKey: objectKey)
        UserDefaults.standard.synchronize()
    }
    
    class func removeAllKeyFromDefault(){
        UserDefaults.standard.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
        if let bundle = Bundle.main.bundleIdentifier { UserDefaults.standard.removePersistentDomain(forName: bundle) }
        UserDefaults.standard.synchronize()
    }
    
    class func iskeyAlreadyExist(key: String) -> Bool {
        return UserDefaults.standard.object(forKey: key) != nil
        
    }
}

//
//  App_Constants.swift
//
//  Created by Devang Tandel on 22/03/17.
//  Copyright © 2017 Setblue. All rights reserved.
//

import Foundation
import UIKit
import CoreLocation
import SystemConfiguration
import FCAlertView
import AVFoundation

//MARK:- APPLICATION VARIABLES

let APP_DELEGATE                         = UIApplication.shared.delegate as! AppDelegate
let APP_NAME                             = Bundle.main.infoDictionary!["CFBundleName"] as! String
let APP_VERSION                          = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! String
let FRAME_SCREEN                         = UIScreen.main.bounds
let KEYCHAIN_KEY                         = ""
let APP_STOREID: String                  = ""
let APP_SHARE_LINK                       = "https://itunes.apple.com/us/app/fancy-stylish-fonts/id\(APP_STOREID)?ls=1&mt=8"
let BASE_URL = "http://maestro.jodhaa.co.in/api/"
//let BASE_URL = "http://192.168.1.32/members/sandip/worksuit/index.php/api/"

let adLoadTime                                  = 30
let adRemoveTime                                = 60

typealias typeAliasDictionary               = [String: AnyObject]
typealias typeAliasStringDictionary         = [String: String]

// MARK: STATIC KEYS
let KEY_USERNAME                                = "USERNAME"
let KEY_PASSWORD                                = "PASSWORD"
let KEY_SOURCE                                  = "iphone"
let KEY_IS_FONT_FREE                            = "IS_FONT_FREE"

//MARK: -  VIEW CONTROLLER ID
let SB_MAIN                                     = "Main"
let VC_HOME                                     = "idHomeVC"
let VC_LOGIN                                    = "idLoginVC"
let VC_STATUS                                   = "idStatusVC"
let VC_PROFILE                                  = "idProfileVC"
let VC_FORGOTPASSWORD                           = "idForgotPasswordVC"
let VC_CONGRATULATION                           = "idCongratulationVC"
let VC_NOTES                                    = "idNotesVC"
let VC_RATES                                    = "idRatesVC"

let TAB_MAIN                                    = "idTabBarMain"
let NC_Home                                     = "navHome"
let NC_LOGIN                                    = "navLogin"

//MARK: - NOTIFICATION CONSTANT
let NOTIFICATION_RESTORE                        = "menuRestorePurchase"
let NOTIFICATION_GO_PREMIUM                     = "menuGoPremium"

//MARK: - IMAGES
let ICON_MENU = "icon_Menu"
let ICON_BACK = "icon_back"

let DateFormatList: [[String]] = [
    ["dd/MM/yy", "dd/MM/yy HH:mm", "dd/MM/yy h:mm a", "dd/MM/yy h:mm:ss a","dd/MM/yyyy","dd/MM/yyyy HH:mm","dd/MM/yyyy h:mm a","dd/MM/yyyy h:mm:ss a"]
]

//MARK: APP ENUM
public enum POPOVER_ANIMATION: Int {
    case popover_ANIMATION_CROSS_DISSOLVE
    case popover_ANIMATION_RIGHT_TO_LEFT
    case popover_ANIMATION_BOTTOM_TO_TOP
    case popover_ANIMATION_FADE_IN_OUT
    case popover_ANIMATION_BLUR
}

public enum MEDIA_PAGE_TYPE: Int {
    case IMAGE
    case VIDEO
    case CAMERA
}

public enum LIST_PAGE_TYPE: Int {
    case NOTE
    case CREDENTIAL
}

public enum JD_DateFormat: Int {
    case DDMMYYYY
    case DDMMMYYYY
    case MMDDYYYY
    case YYYYMMDD
    case HHMMAA
    case DDMMYYYY_HH_MM
    case YYYYMMDD_HH_MM
}

public enum JD_PickerFormat: Int {
    case Picker_Date
    case Picker_DateAndTime
    case Picker_Time
}

public enum DATE_TYPE:Int {
    case DUMMY
    case DATE_TO
    case DATE_FROM
    case DUARTION
}

public enum FCALERT_TYPE: Int {
    case UPDATE_PASSCODE
    case UPDATE_QUESTION
    case MOVE_TO_PHONE
    case DUMMY
}
public enum AttachmentType: String {
    case camera
    case videoCamera
    case video
    case photoLibrary
}

public enum STATUS_PAGE_VIEW_TYPE: String {
    case DUMMY //
    case I_AM_AVAILABLE //0
    case REQ_SUBSTITUTE //0
    case SEARCH_ASSIGNMENT //1
    case SEARCH_SUBSTITUTE //1
    case CURRENT_ASS_CHECKIN //2
    case CURRENT_ASS_CHECKOUT //3
    case CURRENT_ASS_FOLLOWUP_DISABLE //2
    case CURRENT_ASS_FOLLOWUP_ENABLE //3
    case CANCEL_VIEW //4
    case USER_RESPONCE_PENDING//5
}

public enum ALERT_TYPE: Int {
    case DUMMY
    case LOGOUT
    case EDIT_CARD
    case DELETE_CARD
    case CANCEL_ASSIGNMENT
    case CHECKOUT
    case CANCEL_SUBSTITUTE
    case SKIP_ASSIGNMENT
}

public enum ACTION_SHEET_TYPE :Int {
    case ACTION_SHEET_DUMMY
    case ACTION_SHEET_MORE
}

struct App_Constants {
    static let actionFileTypeHeading = "Add a File"
    static let actionFileTypeDescription = "Choose a filetype to add..."
    static let camera = "Camera"
    static let phoneLibrary = "Phone Library"
    static let video = "Video"
    static let file = "File"
    static let alertForPhotoLibraryMessage = "App does not have access to your photos. To enable access, tap settings and turn on Photo Library Access."
    static let alertForCameraAccessMessage = "App does not have access to your camera. To enable access, tap settings and turn on Camera."
    static let alertForVideoLibraryMessage = "App does not have access to your video. To enable access, tap settings and turn on Video Library Access."
    static let settingsBtnTitle = "Settings"
    static let cancelBtnTitle = "Cancel"
    struct MixpanelConstants { static let activeScreen = "Active Screen" }
    struct CrashlyticsConstants { static let userType = "User Type" }
}

//MARK: -  CONSTANT METHODS
func getStoryboard(_ storyboardName: String) -> UIStoryboard {
    return UIStoryboard(name: "\(storyboardName)", bundle: nil)
}

func loadVC(_ strStoryboardId: String, strVCId: String) -> UIViewController {
    return  getStoryboard(strStoryboardId).instantiateViewController(withIdentifier: strVCId)
}

let isSimulator: Bool = {
    var isSim = false
    #if arch(i386) || arch(x86_64)
        isSim = true
    #endif
    return isSim
}()

func IOS_VERSION() -> String {
    return UIDevice.current.systemVersion
}

func IOS_EQUAL_TO(_ xx: Float) -> Bool {
    return IOS_VERSION().compare(String(xx), options: .numeric) == .orderedSame
}

func SCREENWIDTH() -> CGFloat{
    return UIScreen.main.bounds.width
}

func SCREENHEIGHT() -> CGFloat{
    return UIScreen.main.bounds.height
}

func ShowNetworkIndicator(_ xx :Bool){
    runOnMainThread {
         UIApplication.shared.isNetworkActivityIndicatorVisible = xx
    }
}

//MARK: - Log trace
public func DLog<T>(_ message:T,  file: String = #file, function: String = #function, lineNumber: Int = #line ) {
    #if DEBUG
        if let text = message as? String {
            print("\((file as NSString).lastPathComponent) -> \(function) line: \(lineNumber): \(text)")
        }
    #endif
}

public var CurrentTimeStamp: String {
    return "\(Date().timeIntervalSince1970 * 1000)"
}

func NULL_TO_NIL(_ value : AnyObject?) -> AnyObject? {
    if value is NSNull || value == nil { return "" as AnyObject? } else { return value }
}

func removeNullFromDictionary(_ dictParam: typeAliasDictionary) -> typeAliasDictionary {
    var dictionaryNew: typeAliasDictionary = dictParam
    for pKey in dictionaryNew.keys {
        if dictionaryNew[pKey] is [typeAliasDictionary] {
            var array: [typeAliasDictionary] = dictionaryNew[pKey] as! [typeAliasDictionary]
            for i in 0..<array.count {
                let dictArray: typeAliasDictionary = array[i]
                var dict: typeAliasDictionary = dictArray
                dict = removeNullFromDictionary(dict)
                array[i] = dict
            }
            dictionaryNew[pKey] = array as AnyObject?
        }
        if dictionaryNew[pKey] is typeAliasDictionary {
            var dict: typeAliasDictionary = dictionaryNew[pKey] as! typeAliasDictionary
            dict = removeNullFromDictionary(dict)
            dictionaryNew[pKey] = dict as AnyObject?
        }
        if dictionaryNew[pKey] is NSNull {
            dictionaryNew[pKey] = "" as AnyObject?
        }
    }
    return dictionaryNew
}

func randomString(length: Int) -> String {
    
    let letters : NSString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    let len = UInt32(letters.length)
    var randomString = ""
    
    for _ in 0 ..< length {
        let rand = arc4random_uniform(len)
        var nextChar = letters.character(at: Int(rand))
        randomString += NSString(characters: &nextChar, length: 1) as String
    }
    return randomString
}

func isConnectedToNetwork() -> Bool {
    
    var zeroAddress = sockaddr_in()
    zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
    zeroAddress.sin_family = sa_family_t(AF_INET)
    let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
        $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
            SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
        }
    }
    var flags = SCNetworkReachabilityFlags()
    if !SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) {
        return false
    }
    let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
    let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
    return (isReachable && !needsConnection)
}

func isiPad()->Bool { return UIDevice.current.userInterfaceIdiom == .pad ? true :  false }

func isIphoneX() -> Bool {
    if UIDevice().userInterfaceIdiom == .phone && UIScreen.main.nativeBounds.height == 2436 { return true }
    return false
}
func isPhoneNotched() -> Bool {
    if UIDevice().userInterfaceIdiom == .phone {
        switch UIScreen.main.nativeBounds.height {
        case 1136:
            return false
//            print("iPhone 5 or 5S or 5C")
        case 1334:
//            print("iPhone 6/6S/7/8")
            return false
        case 1920, 2208:
//            print("iPhone 6+/6S+/7+/8+")
            return false
        case 2436:
//            print("iPhone X, Xs")
            return true
        case 2688:
//            print("iPhone Xs Max")
            return true
        case 1792:
            return true
//            print("iPhone Xr")
        default:
            return false
//            print("unknown")
        }
    }
    return false
}

func getUDID() -> String {
    var UDID = ""
    if GetSetModel.iskeyAlreadyExist(key: UD_KEY_UDID){
        UDID = GetSetModel.getStringValueFromUserDefaults(UD_KEY_UDID)
    }else{
        let theUUID : CFUUID = CFUUIDCreate(nil);
        let string : CFString = CFUUIDCreateString(nil, theUUID);
        UDID =  string as String
        GetSetModel.setStringValueToUserDefaults(strValue: UDID, ForKey: UD_KEY_UDID)
    }
    return UDID
}

func getAccessToken() -> String {
    var accessToken = ""
    if GetSetModel.iskeyAlreadyExist(key: UD_KEY_ACCESSTOKEN){
        accessToken = GetSetModel.getStringValueFromUserDefaults(UD_KEY_ACCESSTOKEN)
    }
    return accessToken
}

func printFonts(){
    for family in UIFont.familyNames {
        print(family)
        for name in UIFont.fontNames(forFamilyName: family) {
            print(" \(family) :  \(name)")
        }
    }
}

func FONT_HEADER_REGULAR(_ size: CGFloat) -> UIFont {
    return UIFont(name: "TrebuchetMS-Bold", size: size)!
}

func FONT_REGULAR(_ size: CGFloat) -> UIFont {
    return UIFont(name: "TrebuchetMS", size: size)!
}

func runOnMainThread(block: @escaping () -> ()) {
    DispatchQueue.main.async { block() }
}

func runInBackground(block: @escaping () -> ()) {
    DispatchQueue.global(qos: .background).async { block() }
}

func runAfterTime(time: Double ,block : @escaping() -> ()){
    DispatchQueue.main.asyncAfter(deadline: .now() + time) { block() }
}

func hideKeyboard(){
    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to:nil, from:nil, for:nil)
}

//MARK: - SHOW ALERT
func showAlertWithTitleWithMessage(message:String)  {
    
    let _JD_AlertView = JD_AlertView()
    _JD_AlertView.showOkAlertView(message, alertType: .DUMMY, object: "", isCallDelegate: false)
//    _JD_AlertView.delegate = self

//    let alert : FCAlertView = FCAlertView()
//    alert.avoidCustomImageTint =  true
//    alert.detachButtons = true
//    alert.titleColor = COLOR_NAV
//    alert.titleFont = UIFont.init(name: FONT_SAN_FRANCISCO_REGULAR, size: 20)
//    alert.colorScheme = COLOR_NAV
//    alert.showAlert(in: APP_DELEGATE.window, withTitle: "MAESTRO", withSubtitle: message, withCustomImage: nil   , withDoneButtonTitle: "OK", andButtons: nil)
}
func showAlertWithTitleWithMessageAndButtons(message:String, alert : FCAlertView,buttons : [String],withDoneTitle : String)  {
    alert.avoidCustomImageTint =  true
    alert.detachButtons = true
    alert.colorScheme = APP_THEME_COLOR
    alert.titleColor = COLOR_NAV
    alert.titleFont = UIFont.init(name: FONT_SAN_FRANCISCO_REGULAR, size: 20)
    alert.colorScheme = APP_THEME_COLOR
    
    alert.showAlert(in: APP_DELEGATE.window, withTitle: "MAESTRO", withSubtitle: message, withCustomImage: nil, withDoneButtonTitle: withDoneTitle, andButtons: buttons)
    
}

func showNoInternetAlert()  {
    let _JD_AlertView = JD_AlertView()
    _JD_AlertView.showOkAlertView("No internet connection available. Please try again!", alertType: .DUMMY, object: "", isCallDelegate: false)
    
//    let alert : FCAlertView = FCAlertView()
//    alert.detachButtons = true
//    alert.titleColor = COLOR_NAV
//    alert.titleFont = UIFont.init(name: FONT_SAN_FRANCISCO_REGULAR, size: 20)
//    alert.colorScheme = APP_THEME_COLOR
//
//    alert.showAlert(in: APP_DELEGATE.window, withTitle: "MAESTRO", withSubtitle: "No internet connection available. Please try again!", withCustomImage: nil , withDoneButtonTitle: "Dismiss", andButtons: nil)
}

func saveImageDocumentDirectoryWithDate(tempImage:UIImage, block : @escaping (_ url: URL?) -> Void ){
    let documentsDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
    let random : String =  randomString(length: 5)
    let fileURL = documentsDirectoryURL.appendingPathComponent(String(format:"CPImage%@.png",random))
    do { try tempImage.pngData()?.write(to: fileURL) }
    catch { block(nil) }
    block(fileURL)
}

func saveImageAtPath(fileName : String,img: UIImage, path : String)-> Bool {
    let fileManager = FileManager.default
    print(path)
    let imageData = UIImage.jpegData(img)(compressionQuality: 1)
    return fileManager.createFile(atPath: "\(path)/\(fileName)", contents: imageData, attributes: nil)
}

func getDirectoryPath() -> String {
    let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
    let documentsDirectory = paths[0]
    return documentsDirectory
}

func getImageFromDirectory(_ path : String) -> [UIImage] {
    let fileManager = FileManager.default
    let arrStrImages : [String] = getListFromDirectory(path)
    var arrImages = [UIImage]()
    if arrStrImages.count != 0 {
        for str in arrStrImages {
        let imagePAth = (path.stringByAppendingPathComponent(path: str))
            if fileManager.fileExists(atPath: imagePAth) {
                arrImages.append(UIImage(contentsOfFile: imagePAth)!)
//                print("images : \(String(describing: UIImage(contentsOfFile: imagePAth)!))")
            }
        }
    }
    return arrImages
}

func getVideoFromDirectory(_ path : String) -> [UIImage] {
    let fileManager = FileManager.default
    let arrStrImages : [String] = getListFromDirectory(path)
    var arrImages = [UIImage]()
    if arrStrImages.count != 0 {
        for str in arrStrImages {
            let imagePAth = (path.stringByAppendingPathComponent(path: str))
            if fileManager.fileExists(atPath: imagePAth) {
                let fileUrl = NSURL(fileURLWithPath: imagePAth)
                    let img : UIImage = getThumbnailFrom(path: fileUrl as URL)!
                    arrImages.append(img)
            }
        }
    }
    return arrImages
}

func getThumbnailFrom(path: URL) -> UIImage? {
    do {
        let asset = AVURLAsset(url: path , options: nil)
        let imgGenerator = AVAssetImageGenerator(asset: asset)
        imgGenerator.appliesPreferredTrackTransform = true
        let cgImage = try imgGenerator.copyCGImage(at: CMTimeMake(value: 0, timescale: 1), actualTime: nil)
        let thumbnail = UIImage(cgImage: cgImage)
        return thumbnail
    } catch let error {
        print("*** Error generating thumbnail: \(error.localizedDescription)")
        return nil
    }
}

func deleteDirectory(path : String) {
    let fileManager = FileManager.default
    if fileManager.fileExists(atPath: path) { try! fileManager.removeItem(atPath: path) }
    else{ print("Something wronge.") }
}

func createDirectoryWithName( _ folderName : String, _ response:( _ isCreated : Bool) -> Void){
    let fileManager = FileManager.default
    if let tDocumentDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first {
        let filePath =  tDocumentDirectory.appendingPathComponent("\(folderName)")
        if !fileManager.fileExists(atPath: filePath.path) {
            do {
                try fileManager.createDirectory(atPath: filePath.path, withIntermediateDirectories: true, attributes: nil)
            } catch { response(false) }
        }
        response(true)
    }
}

func getListFromDirectory(_ folderPath : String) -> [String]  {
    let fm = FileManager.default
    do {
        if fm.fileExists(atPath: folderPath) {
            let items = try fm.contentsOfDirectory(atPath: folderPath)
            var arrStr = [String]()
            for item in items {
//                print("Found \(item)")
                if item != ".DS_Store" { arrStr.append(item) }
            }
            return arrStr
        }
    }
    catch { }
    return [String]()
}

func showNoInternetMAlert()  {
    let alert : FCAlertView = FCAlertView()
    alert.avoidCustomImageTint =  true
    alert.titleColor = APP_THEME_COLOR
    alert.firstButtonTitleColor = UIColor.red
    alert.firstButtonTitleColor = UIColor.white
    alert.showAlert(in: APP_DELEGATE.window, withTitle: APP_NAME, withSubtitle: "No internet connection available. Please try again!", withCustomImage: nil , withDoneButtonTitle: "Dismiss", andButtons: nil)
}

func timeAgoSinceDate(_ date:Date, numericDates:Bool = false) -> String {
    let calendar = NSCalendar.current
    let unitFlags: Set<Calendar.Component> = [.minute, .hour, .day, .weekOfYear, .month, .year, .second]
    let now = Date()
    let earliest = now < date ? now : date
    let latest = (earliest == now) ? date : now
    let components = calendar.dateComponents(unitFlags, from: earliest,  to: latest)
    if (components.year! >= 2) { return "\(components.year!) years ago" }
    else if (components.year! >= 1) {
        if (numericDates) { return "1 year ago" }
        else { return "Last year" }
    }
    else if (components.month! >= 2) { return "\(components.month!) months ago" }
    else if (components.month! >= 1){
        if (numericDates){ return "1 month ago" }
        else { return "Last month" }
    }
    else if (components.weekOfYear! >= 2) { return "\(components.weekOfYear!) weeks ago" }
    else if (components.weekOfYear! >= 1){
        if (numericDates){ return "1 week ago" }
        else { return "Last week" }
    }
    else if (components.day! >= 2) { return "\(components.day!) days ago" }
    else if (components.day! >= 1){
        if (numericDates) { return "1 day ago" }
        else { return "Yesterday" }
    }
    else if (components.hour! >= 2) { return "\(components.hour!) hours ago" }
    else if (components.hour! >= 1){
        if (numericDates) { return "1 hour ago" }
        else { return "An hour ago" }
    } else if (components.minute! >= 2) { return "\(components.minute!) minutes ago" }
    else if (components.minute! >= 1){
        if (numericDates) { return "1 minute ago" }
        else { return "A minute ago" }
    } else if (components.second! >= 3) { return "\(components.second!) seconds ago" }
    else { return "Just now" }
}

/************************** REQUEST PARAMETER **********************/

let KEY_Product_Id                              = "Product_Id"
let KEY_Content                                 = "Content"

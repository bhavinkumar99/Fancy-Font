//
//  ServicePrefix.swift
//  Shelvinza
//
//  Created by Setblue on 10/11/16.
//  Copyright © 2016 Setblue. All rights reserved.
//

import Foundation

//REQUEST PARAMETER
//LOGIN
let REQ_email                           = "email"
let REQ_password                        = "password"
let REQ_device_token                    = "device_token"

//USER PROFILE
let REQ_user_id                         = "user_id"
let REQ_teacher_id                      = "teacher_id"
let REQ_radius                          = "radius"
let REQ_notes                           = "notes"
let REQ_rate                            = "rate"
let REQ_rate_comments                   = "rate_comments"


//EDIT PROFILE
let REQ_profile                         = "profile"
let REQ_retype_new_password             = "retype_new_password"
let REQ_new_password                    = "new_password"
let REQ_current_password                = "current_password"

//CREATE ASSIGNMENT
let REQ_start_datetime                  = "start_datetime"
let REQ_duration                        = "duration"

//I AM AVAILABLE
let REQ_latitude                        = "latitude"
let REQ_longitude                       = "longitude"
let REQ_notes_photo                     = "notes_photo"

//RESPONSE PARAMETER
let RES_Screen_name                     = "Screen_name"
let RES_Search                          = "Search"
let RES_Data                            = "Data"

// CONGO SCREEN
let RES_Assignment_id                   = "Assignment_id"
let RES_Completed                       = "Completed"
let RES_Fullname                        = "Fullname"
let RES_Profile                         = "Profile"
let RES_Total_assignment_completed      = "Total_assignment_completed"
let RES_User_rate                       = "User_rate"
let RES_Message                         = "Message"
let RES_Thumbnail                       = "Thumbnail"
let RES_Address                         = "Address"
let RES_Assignment_notes                = "Assignment_notes"
let RES_Total_spent_time                = "Total_spent_time"
let RES_Cancel_button                   = "Cancel_button"

//CHECK OUT
let RES_Class_room_no                   = "Class_room_no"
let RES_Grade                           = "Grade"
let RES_Assignment_time                 = "Assignment_time"
//let RES_
//let RES_
//let RES_
//let RES_


public enum WSRequestType : Int {
    case PostLogin
    case PostForGotPassword
    case PostEditProfile
    case PostUserProfile
    case PostUserDetail
    case PostTeacherDetail
    case PostSetRadius
    case PostUserPastAssignment
    case PostTeacherPastAssignment
    case PostEditTeacherProfile

    case PostCreateAssignment
    case PostIAmAvailable
    case PostTeacherCurrentStatus
    case PostUserCurrentStatus
    case PostGoUserOffline
    case PostCloseAssignment
    case PostTeacherCancelUser
    case PostUserClaim
    case PostTeacherAssignmentComplete
    case PostTeacherCompleteOk
    case PostRateToUser
    case PostSkipAssignment
    case PostUserCompleteOk
    case PostUserCheckIn
    case PostUserCheckOut
    case postUserAssignmentcomplete
}


public enum RESPONSE_STATUS : NSInteger {
    case VALID
    case INVALID
    case SUCCESS
}

struct WebServicePrefix {
    
    static func GetWSUrl(_ serviceType :WSRequestType) -> String {

        var serviceURl: String?
        switch serviceType {
        case .PostLogin:
            serviceURl = "login"
            break
        case .PostEditProfile:
            serviceURl = "user/edit_profile"
            break
        case .PostForGotPassword :
            serviceURl = "forgot_password"
            break
        case .PostUserProfile:
            serviceURl = "user/profile"
            break
        case .PostUserDetail:
            serviceURl = "user/Profile"
            break
        case .PostTeacherDetail:
            serviceURl = "teacher/Profile"
            break
        case .PostSetRadius:
            serviceURl = "user/set_radius"
            break
        case .PostUserPastAssignment:
            serviceURl = "user/assignments/completed"
            break
        case .PostTeacherPastAssignment:
            serviceURl = "teacher/assignments/completed"
            break
        case .PostEditTeacherProfile:
            serviceURl = "teacher/edit_profile"
            break
        case .PostCreateAssignment:
            serviceURl = "teacher/assignments/create"
            break
        case .PostIAmAvailable:
            serviceURl = "user/set_lat_long"
            break
        case .PostTeacherCurrentStatus:
            serviceURl = "teacher/status"
            break
        case .PostUserCurrentStatus:
            serviceURl = "user/status"
            break
        case .PostGoUserOffline:
            serviceURl = "user/offline"
            break
        case .PostCloseAssignment:
            serviceURl = "teacher/stop_searching"
        case .PostTeacherCancelUser:
            serviceURl = "teacher/cancel_user"
        case .PostUserClaim:
            serviceURl = "user/claim"
        case .PostTeacherAssignmentComplete:
            serviceURl = "teacher/complete"
        case .PostTeacherCompleteOk:
            serviceURl = "teacher/cancel_complete"
        case .PostRateToUser:
            serviceURl = "teacher/rate_of_user"
        case .PostSkipAssignment:
            serviceURl = "user/skip_assignment"
        case .PostUserCompleteOk:
            serviceURl = "user/cancel_complete"
        case .PostUserCheckIn:
            serviceURl = "user/checkin"
        case .PostUserCheckOut:
            serviceURl = "user/checkout"
        case .postUserAssignmentcomplete:
            serviceURl = "user/complete"
        }
        return "\(BASE_URL)\(serviceURl!)"
    }
}

 //
//  ServiceManager.swift
//  Shelvinza
//
//  Created by Setblue on 10/11/16.
//  Copyright © 2016 Setblue. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

class ServiceManager {
    
    static let sharedInstance = ServiceManager()
    
    var URLString : String!
    var Message : String!
    var resObjects:Any!
    
    // METHODS
    init() {}
    
    //MARK:- GET Request
    func getRequest(_ endpointurl:String, parameters:typeAliasDictionary,responseData:@escaping (_ data: Any?, _ error: NSError?, _ message: String?, _ rstatus : Int ) -> Void) {
        
        ShowNetworkIndicator(true)
        URLCache.shared.removeAllCachedResponses()
        URLCache.shared = URLCache(memoryCapacity: 0, diskCapacity: 0, diskPath: nil)
        Alamofire.request(endpointurl, method: .get , parameters: parameters )
            .responseJSON { response in
                
                print("--------------******------------")
                print(response.request ?? "")
                print(response.result.value ?? "")
                print("--------------******------------")
                
                ShowNetworkIndicator(false)
                if let _ = response.result.error {
                    responseData(nil,  response.result.error as NSError?, "Unable to connect to server, please check your internet connection or try switching your network", 0)
                }else {
                    switch response.result {
                    case .success(_):
                        
                        guard let responseJSON:typeAliasDictionary = response.result.value as? typeAliasDictionary else {
                            print("Invalid tag information received from the service")
                            responseData(nil, nil, SOMETHING_WRONG, 0)
                            return
                        }
                        self.Message = (responseJSON["Message"] as! String)
                        guard let status : Int = responseJSON["Status"] as? Int else{
                            responseData(nil, nil, SOMETHING_WRONG, 0)
                            return
                        }
                        
                        if let accessToken:String = responseJSON["AccessToken"] as? String {
                            GetSetModel.setStringValueToUserDefaults(strValue: accessToken, ForKey: UD_KEY_ACCESSTOKEN)
                        }
                        
                        switch status {
                        case RESPONSE_STATUS.VALID.rawValue :
                            self.resObjects  = responseJSON["Data"]
                            break
                        case RESPONSE_STATUS.INVALID.rawValue :
                            self.resObjects  = responseJSON["Data"]
                            break
                        default:
                            break
                        }
                        responseData(self.resObjects, nil, self.Message, status)
                        
                    case .failure(let error):
                        responseData(nil, error as NSError, SOMETHING_WRONG, 0)
                    }
                }
        }
    }
    
    //MARK:- GET Request
    func getRequestWithheaders(_ endpointurl:String, parameters:typeAliasDictionary,responseData:@escaping (_ data: Any?, _ error: NSError?, _ message: String?, _ rstatus : Int ) -> Void) {
        
        ShowNetworkIndicator(true)
        URLCache.shared.removeAllCachedResponses()
        URLCache.shared = URLCache(memoryCapacity: 0, diskCapacity: 0, diskPath: nil)
       
        Alamofire.request(endpointurl, method: .get , parameters: parameters, headers : getHeaders())
            .responseJSON { response in
                
                print("--------------******------------")
                print(response.request ?? "")
                print(response.result.value ?? "")
                print("--------------******------------")
                
                ShowNetworkIndicator(false)
                if let _ = response.result.error {
                    responseData(nil,  response.result.error as NSError?, "Unable to connect to server, please check your internet connection or try switching your network", 0)
                }else {
                    switch response.result {
                    case .success(_):
                        
                        guard let responseJSON:typeAliasDictionary = response.result.value as? typeAliasDictionary else {
                            print("Invalid tag information received from the service")
                            responseData(nil, nil, SOMETHING_WRONG, 0)
                            return
                        }
                        
                        self.Message = responseJSON["Message"] as? String
                        let status : Int = responseJSON["Status"] as! Int
                        let aToken : Int = responseJSON["AccessTokenStatus"] as! Int
                        
                     if aToken == 0 {
                             responseData(nil, nil, self.Message, status)
                            return
                        }
                        switch status {
                        case RESPONSE_STATUS.VALID.rawValue :
                            self.resObjects  = responseJSON["Data"]
                            break
                        case RESPONSE_STATUS.INVALID.rawValue :
                            self.resObjects  = responseJSON["Data"]
                            break
                        default:
                            break
                        }
                        responseData(self.resObjects, nil, self.Message, status)
                        
                    case .failure(let error):
                        responseData(nil, error as NSError, SOMETHING_WRONG, 0)
                    }
                }
        }
    }
    //MARK:- POST REQUEST
    func postRequest(_ endpointurl:String, parameters:typeAliasDictionary,responseData:@escaping (_ data: Any?, _ error: NSError?, _ message: String?, _ rstatus : Int ) -> Void) {
        
        ShowNetworkIndicator(true)
        URLCache.shared.removeAllCachedResponses()
        URLCache.shared = URLCache(memoryCapacity: 0, diskCapacity: 0, diskPath: nil)
        Alamofire.request(endpointurl, method: .post , parameters: parameters)
            .responseJSON { response in
                
                print("--------------******------------")
                print(response )
                print(response.request ?? "")
                print(response.result.value ?? "")
                print("--------------******------------")
                
                ShowNetworkIndicator(false)
                if let _ = response.result.error {
                    responseData(nil,  response.result.error as NSError?, "Unable to connect to server, please check your internet connection or try switching your network", 0)
                }else {
                    switch response.result {
                    case .success(_):
                        
                        guard let responseJSON:typeAliasDictionary = response.result.value as? typeAliasDictionary else {
                            responseData(nil, nil, SOMETHING_WRONG, 0)
                            return
                        }
                        
                        if let accessToken:String = responseJSON["AccessToken"] as? String {
                            GetSetModel.setStringValueToUserDefaults(strValue: accessToken, ForKey: UD_KEY_ACCESSTOKEN)
                        }
                        
                        self.Message = (responseJSON["Message"] as! String)
                        let status : Int = responseJSON["Status"] as! Int
                        
                        switch status {
                        case RESPONSE_STATUS.VALID.rawValue :
                            self.resObjects  = responseJSON["Data"]
                            break
                        case RESPONSE_STATUS.INVALID.rawValue :
                            self.resObjects  = responseJSON["Data"]
                            break
                        default:
                            break
                        }
                        responseData(self.resObjects, nil, self.Message, status)
                        
                    case .failure(let error):
                        responseData(nil, error as NSError, SOMETHING_WRONG, 0)
                    }
                }
        }
    }
    //MARK:- POST REQUEST FOR REGISTRATION
    func postRequestHandler(_ endpointurl:String, parameters:typeAliasDictionary,responseData:@escaping (_ data: Any?, _ error: NSError?, _ message: String?, _ rstatus : Int ) -> Void) {
        
        ShowNetworkIndicator(true)
        URLCache.shared.removeAllCachedResponses()
        URLCache.shared = URLCache(memoryCapacity: 0, diskCapacity: 0, diskPath: nil)
        Alamofire.request(endpointurl, method: .post , parameters: parameters)
            .responseJSON { response in
                
                print("--------------******------------")
                print(response )
                print(response.request ?? "")
                print(response.result.value ?? "")
                print("--------------******------------")
                
                ShowNetworkIndicator(false)
                if let _ = response.result.error {
                    responseData(nil,  response.result.error as NSError?, "Unable to connect to server, please check your internet connection or try switching your network", 0)
                }else {
                    switch response.result {
                    case .success(_):
                        
                        guard let responseJSON:typeAliasDictionary = (response.result.value as? typeAliasDictionary) else {
                            responseData(nil, nil, SOMETHING_WRONG, 0)
                            return
                        }
                        self.Message = (responseJSON["Message"] as! String)
                        let status : Int = responseJSON["Status"] as! Int
                        
                        switch status {
                        case RESPONSE_STATUS.VALID.rawValue :
                            self.resObjects  = responseJSON["Data"]
                            break
                        case RESPONSE_STATUS.INVALID.rawValue :
                            self.resObjects  = responseJSON["Data"]
                            break
                        default:
                            break
                        }
                        responseData(self.resObjects, nil, self.Message, status)
                        
                    case .failure(let error):
                        responseData(nil, error as NSError, SOMETHING_WRONG, 0)
                    }
                }
        }
    }
    //MARK: CURRENT STATUS
    func postRequestStatusHandler(_ endpointurl:String, parameters:typeAliasDictionary,responseData:@escaping (_ data: Any?, _ error: NSError?, _ message: String?, _ rstatus : Int ) -> Void) {
        
        ShowNetworkIndicator(true)
        URLCache.shared.removeAllCachedResponses()
        URLCache.shared = URLCache(memoryCapacity: 0, diskCapacity: 0, diskPath: nil)
        Alamofire.request(endpointurl, method: .post , parameters: parameters)
            .responseJSON { response in
                
                print("--------------******------------")
                print(response )
                print(response.request ?? "")
                print(response.result.value ?? "")
                print("--------------******------------")
                
                ShowNetworkIndicator(false)
                if let _ = response.result.error {
                    responseData(nil,  response.result.error as NSError?, "Unable to connect to server, please check your internet connection or try switching your network", 0)
                }else {
                    switch response.result {
                    case .success(_):
                        
                        guard let responseJSON:typeAliasDictionary = (response.result.value as? typeAliasDictionary) else {
                            responseData(nil, nil, SOMETHING_WRONG, 0)
                            return
                        }
                        self.Message = (responseJSON["Message"] as! String)
                        let status : Int = responseJSON["Status"] as! Int
                        
                        self.resObjects  = responseJSON
                        responseData(self.resObjects, nil, self.Message, status)
                        
                    case .failure(let error):
                        responseData(nil, error as NSError, SOMETHING_WRONG, 0)
                    }
                }
        }
    }
    //MARK:- POST REQUEST FOR REGISTRATION WITH HEADER
    func postRequestForInquiryWIthHeader(_ endpointurl:String, parameters:typeAliasDictionary,responseData:@escaping (_ data: Any?, _ error: NSError?, _ message: String?, _ rstatus : Int ) -> Void) {
        
        ShowNetworkIndicator(true)
        URLCache.shared.removeAllCachedResponses()
        URLCache.shared = URLCache(memoryCapacity: 0, diskCapacity: 0, diskPath: nil)
        Alamofire.request(endpointurl, method: .post , parameters: parameters, headers : getHeaders())
            .responseJSON { response in
                
                print("--------------******------------")
                print(response )
                print(response.request ?? "")
                print(response.result.value ?? "")
                print("--------------******------------")
                
                ShowNetworkIndicator(false)
                if let _ = response.result.error {
                    responseData(nil,  response.result.error as NSError?, "Unable to connect to server, please check your internet connection or try switching your network", 0)
                }else {
                    switch response.result {
                    case .success(_):
                        
                        guard let responseJSON:typeAliasDictionary = response.result.value as? typeAliasDictionary else {
                            responseData(nil, nil, SOMETHING_WRONG, 0)
                            return
                        }
                        
                        if let accessToken:String = responseJSON["AccessToken"] as? String {
                            GetSetModel.setStringValueToUserDefaults(strValue: accessToken, ForKey: UD_KEY_ACCESSTOKEN)
                        }
                        
                        self.Message = (responseJSON["Message"] as! String)
                        let status : Int = responseJSON["Status"] as! Int
                        
                        switch status {
                        case RESPONSE_STATUS.VALID.rawValue :
                            self.resObjects  = responseJSON["Data"]
                            break
                        case RESPONSE_STATUS.INVALID.rawValue :
                            self.resObjects  = responseJSON["Data"]
                            break
                        default:
                            break
                        }
                        responseData(self.resObjects, nil, self.Message, status)
                        
                    case .failure(let error):
                        responseData(nil, error as NSError, SOMETHING_WRONG, 0)
                    }
                }
        }
    }
    //MARK:- GET Request
    func CustomPostRequest(_ endpointurl:String, parameters:typeAliasDictionary,responseData:@escaping (_ data: Any?, _ error: NSError?, _ message: String?, _ rstatus : Int ) -> Void) {
        
        ShowNetworkIndicator(true)
        URLCache.shared.removeAllCachedResponses()
        URLCache.shared = URLCache(memoryCapacity: 0, diskCapacity: 0, diskPath: nil)
        Alamofire.request(endpointurl, method: .post , parameters: parameters)
            .responseJSON { response in
                
                print("--------------******------------")
                print(response )
                print(response.request ?? "")
                print(response.result.value ?? "")
                print("--------------******------------")
                
                ShowNetworkIndicator(false)
                if let _ = response.result.error {
                    responseData(nil,  response.result.error as NSError?, "Unable to connect to server, please check your internet connection or try switching your network", 0)
                }else {
                    switch response.result {
                    case .success(_):
                        
                        guard let responseJSON:typeAliasDictionary = response.result.value as? typeAliasDictionary else {
                            responseData(nil, nil, SOMETHING_WRONG, 0)
                            return
                        }
                        responseData(responseJSON, nil, "", 1)
                        
                    case .failure(let error):
                        responseData(nil, error as NSError, SOMETHING_WRONG, 0)
                    }
                }
        }
    }
    
    //MARK:- POST Request
    func postParameterRequestWithHeader(_ endpointurl:String, parameters:typeAliasDictionary, responseData:@escaping (_ data: Any?, _ error: NSError?, _ message: String?, _ rstatus : Int) -> Void) {
        
        ShowNetworkIndicator(true)
        URLCache.shared.removeAllCachedResponses()
        URLCache.shared = URLCache(memoryCapacity: 0, diskCapacity: 0, diskPath: nil)
        Alamofire.request(endpointurl, method: .post , parameters: parameters, encoding: URLEncoding.queryString, headers : getHeaders())
            .responseJSON { response in
                
                ShowNetworkIndicator(false)
                print("--------------******------------")
                print(response.request ?? "")
                print(response.result.value ?? "")
                print("--------------******------------")
                if let _ = response.result.error {
                    responseData(nil,  response.result.error as NSError?, "Unable to connect to server, please check your internet connection or try switching your network", 0)
                }else {
                    switch response.result {
                    case .success(_):
                        
                        guard let responseJSON:typeAliasDictionary = response.result.value as? typeAliasDictionary else {
                            responseData(nil, nil, SOMETHING_WRONG, 0)
                            return
                        }
                        
                        self.Message = (responseJSON["Message"] as! String)
                        guard let status : Int = responseJSON["Status"] as? Int else{
                            responseData(nil, nil, SOMETHING_WRONG, 0)
                            return
                        }
                        
                        switch status {
                        case RESPONSE_STATUS.VALID.rawValue :
                            self.resObjects  = responseJSON["Data"]
                            break
                        case RESPONSE_STATUS.INVALID.rawValue :
                            self.resObjects  = responseJSON["Data"]
                            break
                        default:
                            break
                        }
                        responseData(self.resObjects, nil, self.Message, status)
                        
                    case .failure(let error):
                        responseData(nil, error as NSError, SOMETHING_WRONG, 0)
                    }
                }
        }
    }
    
    //MARK:- Post Request Without Header
    func postRequestWithHeader(_ endpointurl:String, parameters:typeAliasDictionary,responseData:@escaping (_ data: Any?, _ error: NSError?, _ message: String?, _ rstatus : Int ) -> Void) {
        
        ShowNetworkIndicator(true)
        URLCache.shared.removeAllCachedResponses()
        URLCache.shared = URLCache(memoryCapacity: 0, diskCapacity: 0, diskPath: nil)
        Alamofire.request(endpointurl, method: .post , parameters: parameters , headers : getHeaders())
            .responseJSON { response in
                
                print("--------------******------------")
                print(response.request ?? "")
                print(parameters)
                print(response.result.value ?? "")
                print("--------------******------------")
                
                ShowNetworkIndicator(false)
                if let _ = response.result.error {
                    responseData(nil,  response.result.error as NSError?, "Unable to connect to server, please check your internet connection or try switching your network", 0)
                }else {
                    switch response.result {
                    case .success(_):
                        
                        guard let responseJSON:typeAliasDictionary = response.result.value as? typeAliasDictionary else {
                            responseData(nil, nil, SOMETHING_WRONG, 0)
                            return
                        }
                        self.Message = (responseJSON["Message"] as! String)
                        guard let status : Int = responseJSON["Status"] as? Int else{
                            responseData(nil, nil, SOMETHING_WRONG, 0)
                            return
                        }
                        switch status {
                        case RESPONSE_STATUS.VALID.rawValue :
                            self.resObjects  = responseJSON["Data"]
                            break
                        case RESPONSE_STATUS.INVALID.rawValue :
                            self.resObjects  = responseJSON["Data"]
                            break
                        default:
                            break
                        }
                        responseData(self.resObjects, nil, self.Message, status)
                        
                    case .failure(let error):
                        responseData(nil, error as NSError, SOMETHING_WRONG, 0)
                    }
                }
        }
    }
    func updateUserWithImage(endpointurl:String, withHeader : Bool,imageTagName: String, parameters:typeAliasDictionary, filePath:NSArray, responseData:@escaping ( _ responseDict: Any?, _ error: NSError?, _ message: String?, _ rstaus:Int) -> Void)  {
        
        print(parameters)
        let URL = try! URLRequest(url: endpointurl, method: .post, headers: withHeader ? getHeaders() : nil)
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key, value)in parameters{
                
                var valueStr:String = ""
                if let intVlaue:Int   = value as? Int{
                    valueStr = String(format:"%d",intVlaue)
                }else{
                    valueStr = value as! String
                }
                multipartFormData.append(valueStr.data(using: String.Encoding.utf8)!, withName: key )
            }
            if filePath.count > 0 {
                for obj in filePath {
                    
                    let url : URL = obj as! URL
                    multipartFormData.append( url, withName: imageTagName)
                }
            }else{
                multipartFormData.append( "".data(using: String.Encoding.utf8)!, withName: imageTagName)
            }
            
        }, with: URL, encodingCompletion: { (result) in
            
            switch result {
                
            case .success(let upload, _, _):
                
                upload.uploadProgress(closure: { (Progress) in
                    print("Upload Progress: \(Progress.fractionCompleted)")
                })
                
                upload.responseJSON { response in
                    print(response)
                    if let JSON:typeAliasDictionary = response.result.value as? typeAliasDictionary {
                        print("JSON: \(JSON)")
                        let st: Int = JSON["Status"] as! Int
                        if let accessToken:String = JSON["AccessToken"] as? String {
                            GetSetModel.setStringValueToUserDefaults(strValue: accessToken, ForKey: UD_KEY_ACCESSTOKEN)
                        }
                        responseData(JSON["Data"] ,nil, JSON["Message"] as? String, st)
                    }else{
                        responseData(nil, nil, "Something went wrong",0)
                    }
                }
                
            case .failure(let encodingError):
                print(encodingError)
                responseData(nil ,encodingError as NSError?, "Something went wrong", 0)
            }
        })
    }
    
    func uploadImagesWithArray(endpointurl:String, parameters:typeAliasDictionary, filePath:NSArray, responseData:@escaping ( _ responseDict: Any?, _ error: NSError?, _ message: String?, _ rstaus:Int) -> Void)  {
        
        let URL = try! URLRequest(url: endpointurl, method: .post, headers: nil)
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key, value)in parameters{
                
                var valueStr:String = ""
                if let intVlaue:Int   = value as? Int{
                    valueStr = String(format:"%d",intVlaue)
                }else{
                    valueStr = value as! String
                }
                multipartFormData.append(valueStr.data(using: String.Encoding.utf8)!, withName: key )
            }
            if filePath.count > 0 {
                for obj in filePath {
                    
                    let url : URL = obj as! URL
                    multipartFormData.append( url, withName: "ProfilePicture")
                }
            }else{
                multipartFormData.append( "".data(using: String.Encoding.utf8)!, withName: "ProfilePicture")
            }  
            
            
        }, with: URL, encodingCompletion: { (result) in
            
            switch result {
                
            case .success(let upload, _, _):
                
                upload.uploadProgress(closure: { (Progress) in
                    print("Upload Progress: \(Progress.fractionCompleted)")
                })
                
                upload.responseJSON { response in
                    print(response)
                    if let JSON:typeAliasDictionary = response.result.value as? typeAliasDictionary {
                        print("JSON: \(JSON)")
                        let st: Int = JSON["Status"] as! Int
                        responseData(JSON["Data"] ,nil, JSON["Message"] as? String, st)
                    }else{
                        responseData(nil, nil, "Something went wrong",0)
                    }
                }
                
            case .failure(let encodingError):
                print(encodingError)
                responseData(nil ,encodingError as NSError?, "Something went wrong", 0)
            }
        })
    }
    
    func uploadImages(endpointurl:String, parameters:typeAliasDictionary, imageKey : String, filePath:NSArray, responseData:@escaping ( _ responseDict: Any?, _ error: NSError?, _ message: String?, _ rstaus:Int) -> Void)  {
        
        let URL = try! URLRequest(url: endpointurl, method: .post, headers: getHeaders())
        
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForResource = 3600
        configuration.timeoutIntervalForRequest = 3600
        
        let alamoFireManager = Alamofire.SessionManager.default
        alamoFireManager.upload(multipartFormData: { (multipartFormData) in
            
            for (key, value)in parameters{
                
                var valueStr:String = ""
                if let intVlaue:Int   = value as? Int{
                    valueStr = String(format:"%d",intVlaue)
                }else{
                    valueStr = value as! String
                }
                multipartFormData.append(valueStr.data(using: String.Encoding.utf8)!, withName: key )
            }
            if filePath.count > 0 {
                for obj in filePath {
                    
                    let url : URL = obj as! URL
                    multipartFormData.append( url, withName: imageKey)
                }
            }else{
                multipartFormData.append( "".data(using: String.Encoding.utf8)!, withName: imageKey)
            }
            
        }, with: URL, encodingCompletion: { (result) in
            
            switch result {
                
            case .success(let upload, _, _):
                
                upload.uploadProgress(closure: { (Progress) in
                    print("Upload Progress: \(Progress.fractionCompleted)")
                })
                
                upload.responseJSON { response in
                    print(response)
                    if let JSON:typeAliasDictionary = response.result.value as? typeAliasDictionary {
                        print("JSON: \(JSON)")
                        let st: Int = JSON["Status"] as! Int
                        responseData(JSON["Data"] ,nil, JSON["Message"] as? String, st)
                    }else{
                        responseData(nil, nil, "Something went wrong",0)
                    }
                }
                
            case .failure(let encodingError):
                print(encodingError)
                responseData(nil ,encodingError as NSError?, "Something went wrong", 0)
            }
        })
    }
    
    //MARK:- GET Request
    func getRequestWithheadersForHelp(_ endpointurl:String, parameters:typeAliasDictionary,responseData:@escaping (_ data: Any?, _ error: NSError?, _ message: String?, _ rstatus : Int ) -> Void) {
        
        ShowNetworkIndicator(true)
        URLCache.shared.removeAllCachedResponses()
        URLCache.shared = URLCache(memoryCapacity: 0, diskCapacity: 0, diskPath: nil)
        
        Alamofire.request(endpointurl, method: .get , parameters: parameters , headers : getHeaders())
            .responseJSON { response in
                
                print("--------------******------------")
                print(response.request ?? "")
                print(response.result.value ?? "")
                print("--------------******------------")
                
                ShowNetworkIndicator(false)
                if let _ = response.result.error {
                    responseData(nil,  response.result.error as NSError?, "Unable to connect to server, please check your internet connection or try switching your network", 0)
                }else {
                    switch response.result {
                    case .success(_):
                        
                        guard let responseJSON:typeAliasDictionary = response.result.value as? typeAliasDictionary else {
                            print("Invalid tag information received from the service")
                            responseData(nil, nil, SOMETHING_WRONG, 0)
                            return
                        }
                        
                        self.Message = responseJSON["Message"] as? String
                        let status : Int = responseJSON["Status"] as! Int
                        let aToken : Int = responseJSON["AccessTokenStatus"] as! Int
                        
                        if aToken == 0 {
                            responseData(nil, nil, self.Message, status)
                            return
                        }
                        self.resObjects = responseJSON
                        responseData(self.resObjects, nil, self.Message, status)
                        
                    case .failure(let error):
                        responseData(nil, error as NSError, SOMETHING_WRONG, 0)
                    }
                }
        }
    }
    
    func getHeaders() -> HTTPHeaders {
        var param : HTTPHeaders = [:]
        param = ["Authorization" : String(format: "Bearer %@", getAccessToken())]
        return param
    }
    
    func cancellAllTask(){
        Alamofire.SessionManager.default.session.getTasksWithCompletionHandler { (sessionDataTask, uploadData, downloadData) in
            sessionDataTask.forEach { $0.cancel() }
            uploadData.forEach { $0.cancel() }
            downloadData.forEach { $0.cancel() }
        }
    }
}

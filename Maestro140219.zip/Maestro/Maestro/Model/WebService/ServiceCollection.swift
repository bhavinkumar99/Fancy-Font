//
//  ServiceCollection.swift
//  Shelvinza
//
//  Created by Setblue on 10/11/16.
//  Copyright © 2016 Setblue. All rights reserved.
//

import Foundation
import SwiftyJSON
//import Alamofire

class ServiceCollection {

    static let sharedInstance = ServiceCollection()
    init() {}
    
    //LOGIN
    func postLogin(param : typeAliasDictionary,response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.PostLogin)
        ServiceManager.sharedInstance.postRequestHandler(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil { response(typeAliasDictionary(), 0, message!) }
            else{
                if rstatus == 1 { response(data as! typeAliasDictionary, rstatus, message!) }
                else { response(typeAliasDictionary(), rstatus, message!) }
            }
        }
    }
    func postUserDetail(param : typeAliasDictionary,response : @escaping( _ data : NSDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.PostUserDetail)
        ServiceManager.sharedInstance.postRequestHandler(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil { response(NSDictionary() , 0, message!) }
            else{
                if rstatus == 1 {
                    response(data as! NSDictionary, rstatus, message!)
                }else{
                    response(NSDictionary(), rstatus, message!)
                }
            }
        }
    }
    func postTeacherDetail(param : typeAliasDictionary,response : @escaping( _ data : NSDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.PostTeacherDetail)
        ServiceManager.sharedInstance.postRequestHandler(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil { response(NSDictionary() , 0, message!) }
            else{
                if rstatus == 1 {
                    response(data as! NSDictionary, rstatus, message!)
                }else{
                    response(NSDictionary(), rstatus, message!)
                }
            }
        }
    }
    func postSetRadiusData(param : typeAliasDictionary,response : @escaping( _ data : NSDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.PostSetRadius)
        ServiceManager.sharedInstance.postRequestHandler(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil { response(NSDictionary() , 0, message!) }
            else{
                response(NSDictionary(), rstatus, message!)
            }
        }
    }
    func PostUserPastAssignmentData(param : typeAliasDictionary,response : @escaping( _ data : NSArray , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.PostUserPastAssignment)
        ServiceManager.sharedInstance.postRequestHandler(url, parameters: param) { (data, error, message, rstatus ) in
            if rstatus == 1 {
                guard let resDic : NSArray = data as? NSArray else {
                    response([], 0, SOMETHING_WRONG)
                    return
                }
                let arrJSON : NSMutableArray = NSMutableArray()
                for ( _ ,object) in resDic.enumerated() {
                    let objJson  =  JSON(object)
                    arrJSON.add(CompletedAssignmentUserClass.init(json : objJson))
                }
                response(arrJSON, rstatus, message!)
                
            }else{
                response([], rstatus, message!)
            }
        }
    }
    func PostTeacherPastAssignmentData(param : typeAliasDictionary,response : @escaping( _ data : NSArray , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.PostTeacherPastAssignment)
        ServiceManager.sharedInstance.postRequestHandler(url, parameters: param) { (data, error, message, rstatus ) in
            if rstatus == 1 {
                guard let resDic : NSArray = data as? NSArray else {
                    response([], 0, SOMETHING_WRONG)
                    return
                }
                let arrJSON : NSMutableArray = NSMutableArray()
                for ( _ ,object) in resDic.enumerated() {
                    let objJson  =  JSON(object)
                    arrJSON.add(CompletedAssignmentTeacherClass.init(json : objJson))
                }
                response(arrJSON, rstatus, message!)
                
            }else{
                response([], rstatus, message!)
            }
        }
    }
    
    func postForgotPassword(param : typeAliasDictionary,response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.PostForGotPassword)
        ServiceManager.sharedInstance.postRequestHandler(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil { response(typeAliasDictionary(), 0, message!) }
            else{
                if rstatus == 1 { response(data != nil ? data as! typeAliasDictionary : typeAliasDictionary(), rstatus, message!) }
                else { response(typeAliasDictionary(), rstatus, message!) }
            }
        }
    }
    func editUserDetail(param : typeAliasDictionary,imageURL : NSArray,isTeacher : Bool,response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void )
        {
            let url : String = WebServicePrefix.GetWSUrl(isTeacher ? .PostEditTeacherProfile : .PostEditProfile)
            ServiceManager.sharedInstance.updateUserWithImage(endpointurl: url, withHeader: false, imageTagName: REQ_profile, parameters: param, filePath: imageURL) { (data, error, message, rstatus) in
            if error != nil { response(typeAliasDictionary(), 0, message!) }
            else{
                if rstatus == 1 { response(data != nil ? data as! typeAliasDictionary : typeAliasDictionary(), rstatus, message!) }
                else { response(typeAliasDictionary(), rstatus, message!) }
            }
        }
    }
    
    func postCreateAssignment(param : typeAliasDictionary,response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        let url : String = WebServicePrefix.GetWSUrl(.PostCreateAssignment)
        ServiceManager.sharedInstance.postRequestHandler(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil { response(typeAliasDictionary(), 0, message!) }
            else{
                if rstatus == 1 { response(data as! typeAliasDictionary, rstatus, message!) }
                else { response(typeAliasDictionary(), rstatus, message!) }
            }
        }
    }
    func postTeacherCancelUser(param : typeAliasDictionary,response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        let url : String = WebServicePrefix.GetWSUrl(.PostTeacherCancelUser)
        ServiceManager.sharedInstance.postRequestHandler(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil { response(typeAliasDictionary(), 0, message!) }
            else{
                if rstatus == 1 { response(typeAliasDictionary(), rstatus, message!) }
                else { response(typeAliasDictionary(), rstatus, message!) }
            }
        }
    }
    func postTeacherAssignmentComplete(param : typeAliasDictionary,response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        let url : String = WebServicePrefix.GetWSUrl(.PostTeacherAssignmentComplete)
        ServiceManager.sharedInstance.postRequestHandler(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil { response(typeAliasDictionary(), 0, message!) }
            else{
                if rstatus == 1 { response(typeAliasDictionary(), rstatus, message!) }
                else { response(typeAliasDictionary(), rstatus, message!) }
            }
        }
    }
    func postGetCurrentStatus(param : typeAliasDictionary,isTeacher : Bool,response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        let url : String = WebServicePrefix.GetWSUrl(isTeacher ? .PostTeacherCurrentStatus : .PostUserCurrentStatus)
        ServiceManager.sharedInstance.postRequestStatusHandler(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil { response(typeAliasDictionary(), 0, message!) }
            else{
                if rstatus == 1 { response(data as! typeAliasDictionary, rstatus, message!) }
                else { response(typeAliasDictionary(), rstatus, message!) }
            }
        }
    }
    func postIAmAvailable(param : typeAliasDictionary,response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        let url : String = WebServicePrefix.GetWSUrl(.PostIAmAvailable)
        ServiceManager.sharedInstance.postRequestHandler(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil { response(typeAliasDictionary(), 0, message!) }
            else{
                if rstatus == 1 { response(typeAliasDictionary(), rstatus, message!) }
                else { response(typeAliasDictionary(), rstatus, message!) }
            }
        }
    }
    func postGoOffline(param : typeAliasDictionary,isTeacher : Bool,response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        let url : String = WebServicePrefix.GetWSUrl(isTeacher ? .PostCloseAssignment : .PostGoUserOffline)
        ServiceManager.sharedInstance.postRequestStatusHandler(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil { response(typeAliasDictionary(), 0, message!) }
            else{
                if rstatus == 1 { response(data as! typeAliasDictionary, rstatus, message!) }
                else { response(typeAliasDictionary(), rstatus, message!) }
            }
        }
    }
    func postClaimAssignment(param : typeAliasDictionary,isCliam : Bool,response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        let url : String = WebServicePrefix.GetWSUrl(isCliam ? .PostUserClaim : .PostSkipAssignment)
        ServiceManager.sharedInstance.postRequestHandler(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil { response(typeAliasDictionary(), 0, message!) }
            else{
                if rstatus == 1 { response(typeAliasDictionary(), rstatus, message!) }
                else { response(typeAliasDictionary(), rstatus, message!) }
            }
        }
    }
    func postCancelComplateOK(param : typeAliasDictionary,isTeacher : Bool,response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        let url : String = WebServicePrefix.GetWSUrl(isTeacher ? .PostTeacherCompleteOk : .PostUserCompleteOk)
        ServiceManager.sharedInstance.postRequestHandler(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil { response(typeAliasDictionary(), 0, message!) }
            else{
                if rstatus == 1 { response(typeAliasDictionary(), rstatus, message!) }
                else { response(typeAliasDictionary(), rstatus, message!) }
            }
        }
    }
    
    func postCheckInOutAssignment(param : typeAliasDictionary,isCheckIn : Bool,response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        let url : String = WebServicePrefix.GetWSUrl(isCheckIn ? .PostUserCheckIn : .PostUserCheckOut)
        ServiceManager.sharedInstance.postRequestHandler(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil { response(typeAliasDictionary(), 0, message!) }
            else{
                if rstatus == 1 { response(typeAliasDictionary(), rstatus, message!) }
                else { response(typeAliasDictionary(), rstatus, message!) }
            }
        }
    }
    func postTeacherGiveRates(param : typeAliasDictionary,response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        let url : String = WebServicePrefix.GetWSUrl(.PostRateToUser)
        ServiceManager.sharedInstance.postRequestHandler(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil { response(typeAliasDictionary(), 0, message!) }
            else{
                if rstatus == 1 { response(typeAliasDictionary(), rstatus, message!) }
                else { response(typeAliasDictionary(), rstatus, message!) }
            }
        }
    }
    func userCompleteAssignmentWithNotes(param : typeAliasDictionary,imageURL : NSArray,isTeacher : Bool,response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void )
    {
        let url : String = WebServicePrefix.GetWSUrl(.postUserAssignmentcomplete)
        ServiceManager.sharedInstance.updateUserWithImage(endpointurl: url, withHeader: false, imageTagName: REQ_notes_photo, parameters: param, filePath: imageURL) { (data, error, message, rstatus) in
            if error != nil { response(typeAliasDictionary(), 0, message!) }
            else{
                if rstatus == 1 { response(data != nil ? data as! typeAliasDictionary : typeAliasDictionary(), rstatus, message!) }
                else { response(typeAliasDictionary(), rstatus, message!) }
            }
        }
    }
    
 /*
    //MARK: - REGISTRATION
    func PostRegistration (param : typeAliasDictionary,response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.PostRegistration)
        ServiceManager.sharedInstance.postRequestForRegistration(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil {
                response(typeAliasDictionary(), 0, message!)
            }else{
                if rstatus == 1 {
                    response(data as! typeAliasDictionary, rstatus, message!)
                }else{
                    response(typeAliasDictionary(), rstatus, message!)
                }
            }
        }
    }
    
    //MARK: - UPDATE PROFILE
    func PostUpdateProfile(param : typeAliasDictionary,response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        let url : String = WebServicePrefix.GetWSUrl(.UpdateUserProfile)
        ServiceManager.sharedInstance.postRequestForInquiryWIthHeader(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil {
                response(typeAliasDictionary(), 0, message!)
            }else{
                if rstatus == 1 {
                    response(data as! typeAliasDictionary, rstatus, message!)
                }else{
                    response(typeAliasDictionary(), rstatus, message!)
                }
            }
        }
    }
    //MARK: - LOGIN
    func postLogin (param : typeAliasDictionary,response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.PostLogin)
        ServiceManager.sharedInstance.postRequestForRegistration(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil {
                response(typeAliasDictionary(), 0, message!)
            }else{
                if rstatus == 1 {
                    response(data as! typeAliasDictionary, rstatus, message!)
                }else{
                    response(typeAliasDictionary(), rstatus, message!)
                }
            }
        }
    }
    //MARK: - CONTACT US
    func postSendInquiry(param : typeAliasDictionary,response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.SendInquiry)
        ServiceManager.sharedInstance.postRequestForInquiryWIthHeader(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil {
                response(typeAliasDictionary(), 0, message!)
            }else{
                if rstatus == 1 {
                    response(data as! typeAliasDictionary, rstatus, message!)
                }else{
                    response(typeAliasDictionary(), rstatus, message!)
                }
            }
        }
    }
    //MARK: -  GET CATEGORY LIST
    func GetCategoryList (param : typeAliasDictionary,response : @escaping( _ data : NSArray , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.GetCategoryList)
        ServiceManager.sharedInstance.getRequestWithheaders(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil {
                response([], 0, message!)
            }else{
                
                if rstatus == 1 {
                    guard let resDic : NSArray = data as? NSArray else {
                        response([], 0, SOMETHING_WRONG)
                        return
                    }
                    let arrJSON : NSMutableArray = NSMutableArray()
                    for ( _ ,object) in resDic.enumerated() {
                        let objJson  =  JSON(object)
                        arrJSON.add(CategoryListClass.init(json : objJson))
                    }
                    response(arrJSON, rstatus, message!)
                    
                }else{
                    response([], rstatus, message!)
                }
            }
        }
    }

    //MARK: -  GET QUESTION LIST
    func GetQuestionList (param : typeAliasDictionary,response : @escaping( _ data : NSArray , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.GetQuestionList)
        ServiceManager.sharedInstance.getRequestWithheaders(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil {
                response([], 0, message!)
            }else{
                if rstatus == 1 {
                    guard let resDic : NSArray = data as? NSArray else {
                        response([], 0, SOMETHING_WRONG)
                        return
                    }
                    let arrJSON : NSMutableArray = NSMutableArray()
                    for ( _ ,object) in resDic.enumerated() {
                        let objJson  =  JSON(object)
                        arrJSON.add(QuestionListClass.init(json : objJson))
                    }
                    response(arrJSON, rstatus, message!)
                    
                }else{
                    response([], rstatus, message!)
                }
            }
        }
    }
    
    //MARK: -  ON OFF NOTIFICATION
    func OnOffNotification(param : typeAliasDictionary,response : @escaping( _ data : Int , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.PushNotificationOnOff)
        ServiceManager.sharedInstance.getRequestWithheaders(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil {
                response(0, 0, message!)
            }else{
                if rstatus == 1 {
                    guard let resDic : Int = data as? Int else {
                        response(0, 0, SOMETHING_WRONG)
                        return
                    }
                    response(resDic, rstatus, message!)
                    
                }else{
                    response(0, rstatus, message!)
                }
            }
        }
    }
 
    //MARK: -  GET INFORMATION
    func GetInformation(param : typeAliasDictionary,response : @escaping( _ data : NSArray , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.GetInformation)
        ServiceManager.sharedInstance.getRequestWithheaders(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil {
                response([], 0, message!)
            }else{
                if rstatus == 1 {
                    guard let resDic : NSArray = data as? NSArray else {
                        response([], 0, SOMETHING_WRONG)
                        return
                    }
                    let arrJSON : NSMutableArray = NSMutableArray()
                    for ( _ ,object) in resDic.enumerated() {
                        let objJson = JSON(object)
                        arrJSON.add(InformationListClass.init(json : objJson))
                    }
                    response(arrJSON, rstatus, message!)
                    
                }else{
                    response([], rstatus, message!)
                }
            }
        }
    }
  //MARK: -  GET UPDATE USER LOCATION
    func GetUpdateUserLocation(param : typeAliasDictionary,response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.UpdateUserLocation)
        ServiceManager.sharedInstance.getRequestWithheaders(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil {
                response([:], 0, message!)
            }else{
                if rstatus == 1 {
                    response([:], rstatus, message!)
                }else{
                    response([:], rstatus, message!)
                }
            }
        }
    }
    //MARK: - POST SEND NOTIFICATION
    func PostSendNotification ( _ param : typeAliasDictionary , response : @escaping( _ data : NSArray , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.SendNotification)
        
        ServiceManager.sharedInstance.postParameterRequestWithHeader(url, parameters: param) { (data, error, message, rstatus ) in
            if error != nil {
                response([], 0, message!)
            }else{
                
                if rstatus == 1 {
                    
                    response([], rstatus, message!)
                }else{
                    response([], rstatus, message!)
                }
            }
        }
    }
    
    //MARK: -  GET LANGUAGE LIST
    func GetLanguageList (response : @escaping( _ data : NSArray , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.GetLanguageList)
        ServiceManager.sharedInstance.getRequestWithheaders(url, parameters: typeAliasDictionary()) { (data, error, message, rstatus ) in
            if error != nil {
                response([], 0, message!)
            }else{
                if rstatus == 1 {
                    guard let resDic : NSArray = data as? NSArray else {
                        response([], 0, SOMETHING_WRONG)
                        return
                    }
                    let arrJSON : NSMutableArray = NSMutableArray()
                    for ( _ ,object) in resDic.enumerated() {
                        let objJson  =  JSON(object)
                        arrJSON.add(LanguageListClass.init(json : objJson))
                    }
                    response(arrJSON, rstatus, message!)
                    
                }else{
                    response([], rstatus, message!)
                }
            }
        }
    }
 
    //MARK: - GET NOTIFICATION STATUS
    func GetNotificationStatus(response : @escaping( _ data : Int , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.IsNotificationOn)
        ServiceManager.sharedInstance.getRequestWithheaders(url, parameters: typeAliasDictionary()) { (data, error, message, rstatus ) in
            if error != nil {
                response(0, 0, message!)
            }else{
                if rstatus == 1 {
                    guard let resDic : Int = data as? Int else {
                        response(0, 0, SOMETHING_WRONG)
                        return
                    }
                    response(resDic , rstatus, message!)
                }else{
                    response(0, rstatus, message!)
                }
            }
        }
    }
    
    //MARK: -  GET EVENTS DETAILS
    func GetCountryList(response : @escaping( _ data : NSArray , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.GetCountryList)
        ServiceManager.sharedInstance.getRequestWithheaders(url, parameters: typeAliasDictionary()) { (data, error, message, rstatus ) in
            if error != nil {
                response([], 0, message!)
            }else{
                if rstatus == 1 {
                    guard let resDic : NSArray = data as? NSArray else {
                        response([], 0, SOMETHING_WRONG)
                        return
                    }
                    let arrJSON : NSMutableArray = NSMutableArray()
                    for ( _ ,object) in resDic.enumerated() {
                        let objJson  =  JSON(object)
                        arrJSON.add(CountryListClass.init(json : objJson))
                    }
                    response(arrJSON, rstatus, message!)
                    
                }else{
                    response([], rstatus, message!)
                }
            }
        }
    }
    //MARK: -  GET EMERGENCY NUMBER
    func GetEmergencyNumber(parameter : typeAliasDictionary, response : @escaping( _ data : NSArray , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.GetEmergencyNumber)
        ServiceManager.sharedInstance.getRequestWithheaders(url, parameters: parameter) { (data, error, message, rstatus ) in
            if error != nil {
                response([], 0, message!)
            }else{
                if rstatus == 1 {
                    guard let resDic : NSArray = data as? NSArray else {
                        response([], 0, SOMETHING_WRONG)
                        return
                    }
                    let arrJSON : NSMutableArray = NSMutableArray()
                    for ( _ ,object) in resDic.enumerated() {
                        let objJson  =  JSON(object)
                        arrJSON.add(EmergencyListClass.init(json : objJson))
                    }
                    response(arrJSON, rstatus, message!)
                    
                }else{
                    response([], rstatus, message!)
                }
            }
        }
    }
    //MARK: -  GET NOTIFICATION LIST
    func GetNotificationList(parameter : typeAliasDictionary, _ serviceType :WSRequestType, response : @escaping( _ data : NSArray , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(serviceType)
        ServiceManager.sharedInstance.getRequestWithheaders(url, parameters: parameter) { (data, error, message, rstatus ) in
            if error != nil {
                response([], 0, message!)
            }else{
                if rstatus == 1 {
                    guard let resDic : NSArray = data as? NSArray else {
                        response([], 0, SOMETHING_WRONG)
                        return
                    }
                    let arrJSON : NSMutableArray = NSMutableArray()
                    for ( _ ,object) in resDic.enumerated() {
                        let objJson  =  JSON(object)
                        arrJSON.add(NotificationListClass.init(json : objJson))
                    }
                    response(arrJSON, rstatus, message!)
                    
                }else{
                    response([], rstatus, message!)
                }
            }
        }
    }
    
    //MARK: -  GET HELP
    func GetHelp(parameter : typeAliasDictionary, response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.GetHelp)
        ServiceManager.sharedInstance.getRequestWithheadersForHelp(url, parameters: parameter) { (data, error, message, rstatus ) in
            if error != nil {
                response([:], 0, message!)
            }else{
                if rstatus == 1 {
                    
                    guard let resDic : typeAliasDictionary = data as? typeAliasDictionary else {
                        response([:], 0, SOMETHING_WRONG)
                        return
                    }
                    response(resDic , rstatus, message!)
                    
                }else{
                    response([:], rstatus, message!)
                }
            }
        }
    }
    //MARK: -  CLOSE HELP REQUEST
    func CloseHelpRequest(parameter : typeAliasDictionary, response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.CloseHelpRequest)
        ServiceManager.sharedInstance.getRequestWithheadersForHelp(url, parameters: parameter) { (data, error, message, rstatus ) in
            if error != nil {
                response([:], 0, message!)
            }else{
                if rstatus == 1 {
                    
                    guard let resDic : typeAliasDictionary = data as? typeAliasDictionary else {
                        response([:], 0, SOMETHING_WRONG)
                        return
                    }
                    response(resDic , rstatus, message!)
                    
                }else{
                    response([:], rstatus, message!)
                }
            }
        }
    }
    //MARK: -  GET HELP RESPONSE
    func GetHelpResponse(parameter : typeAliasDictionary, response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.GetNotificationResponse)
        ServiceManager.sharedInstance.getRequestWithheaders(url, parameters: parameter) { (data, error, message, rstatus ) in
            if error != nil {
                response([:], 0, message!)
            }else{
                if rstatus == 1 {
                    guard let resDic : typeAliasDictionary = data as? typeAliasDictionary else {
                        response([:], 0, SOMETHING_WRONG)
                        return
                    }
                    response(resDic, rstatus, message!)
                    
                }else{
                    response([:], rstatus, message!)
                }
            }
        }
    }
    //MARK: -  GET FISRT AID RESPONSE
    func GetFirstAidListResponse(parameter : typeAliasDictionary, response : @escaping( _ data : Any , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.GetFirstAidList)
        ServiceManager.sharedInstance.getRequestWithheaders(url, parameters: parameter) { (data, error, message, rstatus ) in
            if error != nil {
                response([:], 0, message!)
            }else{
                if rstatus == 1 {
                    guard let resArray : NSArray = data as? NSArray else {
                        response([:], 0, SOMETHING_WRONG)
                        return
                    }
                    let arrJSON : NSMutableArray = NSMutableArray()
                    for ( _ ,object) in resArray.enumerated() {
                        let objJson  =  JSON(object)
                        arrJSON.add(FirstAidListClass.init(json : objJson))
                    }
                    response(arrJSON, rstatus, message!)
                    
                }else{
                    response([:], rstatus, message!)
                }
            }
        }
    }
    
    //MARK: -  GET ABOUT US DATA RESPONSE
    func GetContentListResponse(parameter : typeAliasDictionary, response : @escaping( _ data : Any , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.GetContentList)
        ServiceManager.sharedInstance.getRequestWithheaders(url, parameters: parameter) { (data, error, message, rstatus ) in
            if error != nil {
                response([:], 0, message!)
            }else{
                if rstatus == 1 {
                    guard let resDic : typeAliasDictionary = data as? typeAliasDictionary else {
                        response([:], 0, SOMETHING_WRONG)
                        return
                    }
                    response(resDic, rstatus, message!)
                }else{
                    response([:], rstatus, message!)
                }
            }
        }
    }
    
    //MARK: -  CHECK HELP CALL STATUS RESPONSE
    func GetCheckHelpCallStatusResponse(parameter : typeAliasDictionary, response : @escaping( _ data : typeAliasDictionary , _ rstatus : Int, _ message : String) -> Void ) {
        
        let url : String = WebServicePrefix.GetWSUrl(.CheckHelpCallStatus)
        ServiceManager.sharedInstance.getRequestWithheaders(url, parameters: parameter) { (data, error, message, rstatus ) in
            if error != nil {
                response([:], 0, message!)
            }else{
                if rstatus == 1 {
                    guard let resDic : typeAliasDictionary = data as? typeAliasDictionary else {
                        response([:], 0, SOMETHING_WRONG)
                        return
                    }
                    response(resDic, rstatus, message!)
                    
                }else{
                    response([:], rstatus, message!)
                }
            }
        }
    }
    
    func cancellAllTask(){
        ServiceManager.sharedInstance.cancellAllTask()
    }
 */
}
